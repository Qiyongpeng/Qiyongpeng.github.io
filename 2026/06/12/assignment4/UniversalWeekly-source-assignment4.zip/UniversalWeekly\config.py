﻿"""Runtime configuration for external AI services.

For local demos, you can either:
1. Set the environment variable DEEPSEEK_API_KEY, or
2. Paste your key into DEEPSEEK_API_KEY below.

Do not upload a real API key to public repositories or shared submissions.
"""

from __future__ import annotations

import os


DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "").strip()

# Recommended default for the embedded weekly-report chat assistant.
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-v4-pro").strip()

DEEPSEEK_BASE_URL = os.getenv(
    "DEEPSEEK_BASE_URL",
    "https://api.deepseek.com/chat/completions",
).strip()

DEEPSEEK_TIMEOUT_SECONDS = int(os.getenv("DEEPSEEK_TIMEOUT_SECONDS", "60"))


