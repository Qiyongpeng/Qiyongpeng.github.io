"""Student main window - report management, history, and feedback."""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QSplitter, QTabWidget,
    QTextEdit, QGroupBox,
    QFrame, QFileDialog, QMenu, QToolBar, QStatusBar,
    QDialog, QFormLayout, QLineEdit, QToolButton,
    QGridLayout, QProgressBar, QScrollArea, QSizePolicy, QStackedWidget,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QSize, pyqtSignal
from PyQt6.QtGui import QAction, QFont, QColor

from datetime import datetime
from typing import Optional
import os

from database.db_manager import DatabaseManager
from business.auth_service import AuthService
from business.report_service import ReportService
from business.comment_service import CommentService
from business.export_service import ExportService
from ui.common_widgets import (
    StyledButton, SectionLabel, CardFrame, StatusBadge,
    ReadOnlyTable, IconButton
)
from ui.statistics_widget import StatisticsWidget
from ui.weekly_report_dialog import WeeklyReportDialog
from ui.reference_converter_dialog import ReferenceConverterDialog
from ui.file_converter_dialog import FileConverterDialog
from ui.translation_dialog import TranslationDialog
from ui.paper_card_dialog import PaperCardDialog
from ui.presentation_report_dialog import PresentationReportDialog
from ui.memo_dialog import MemoDialog
from ui.weather_time_dialog import WeatherTimeDialog
from ui.ai_call_history_dialog import AICallHistoryDialog
from ui.ai_assistant_dialog import AIAssistantDialog
from ui.ai_analysis_dialog import AIAnalysisDialog
from ui.notification_center_dialog import NotificationCenterDialog
from ui.version_history_dialog import VersionHistoryDialog


class StudentMainWindow(QMainWindow):
    """Main interface for student users."""

    logout_requested = pyqtSignal()

    def __init__(self, db: DatabaseManager, auth: AuthService):
        super().__init__()
        self.db = db
        self.auth = auth
        self.current_user = auth.current_user
        self.report_service = ReportService(db)
        self.comment_service = CommentService(db)
        self.export_service = ExportService(db)
        self._init_ui()
        self._load_reports()

    def _init_ui_legacy_top_tabs(self):
        self.setWindowTitle(f"UniversalWeekly - Student Panel [{self.current_user.display_name}]")
        self.setMinimumSize(1100, 750)
        self.setStyleSheet("""
            QMainWindow { background-color: #F8FAFC; }
            QMenuBar { background: #0F172A; color: white; padding: 4px; }
            QMenuBar::item:selected { background: #2563EB; }
            QStatusBar { background: #F8FAFC; color: #64748B; }
        """)

        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(12)

        # Top bar
        top_bar = QWidget()
        top_bar.setObjectName("TopBar")
        top_bar.setStyleSheet("""
            QWidget#TopBar {
                background: white;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
            }
        """)
        top_layout = QHBoxLayout()
        top_layout.setContentsMargins(24, 14, 24, 14)
        top_layout.setSpacing(12)

        brand_block = QWidget()
        brand_layout = QVBoxLayout(brand_block)
        brand_layout.setContentsMargins(0, 0, 0, 0)
        brand_layout.setSpacing(2)
        title = QLabel("UniversalWeekly")
        title.setStyleSheet("font-size: 21px; font-weight: bold; color: #0F172A; border: none;")
        subtitle = QLabel(
            f"AI Weekly Report Assistant  |  Class: {self.current_user.class_name or 'N/A'}"
            f"  |  ID: {self.current_user.student_id or 'N/A'}"
        )
        subtitle.setStyleSheet("font-size: 12px; color: #64748B; border: none;")
        brand_layout.addWidget(title)
        brand_layout.addWidget(subtitle)

        top_layout.addWidget(brand_block)
        top_layout.addStretch()

        # Unread comments badge
        unread = self.comment_service.get_unread_count(self.current_user.id)
        self.unread_label = QPushButton(f"Notifications {unread}")
        self.unread_label.setMinimumHeight(36)
        self.unread_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.unread_label.clicked.connect(self._open_notification_center)
        self.unread_label.setStyleSheet(
            f"""
            QPushButton {{
                color: {'#EF4444' if unread > 0 else '#16A34A'};
                background: {'#FEE2E2' if unread > 0 else '#EAF7EE'};
                border: 1px solid {'#FECACA' if unread > 0 else '#BBF7D0'};
                border-radius: 8px;
                font-weight: bold;
                padding: 0px 16px;
            }}
            QPushButton:hover {{ background: {'#FECACA' if unread > 0 else '#DCFCE7'}; }}
            """
        )
        top_layout.addWidget(self.unread_label)

        new_report_btn = StyledButton("+ New Report", "primary")
        new_report_btn.clicked.connect(self._new_report)
        top_layout.addWidget(new_report_btn)

        ai_btn = StyledButton("AI Assistant", "ai")
        ai_btn.clicked.connect(self._open_ai_assistant)
        top_layout.addWidget(ai_btn)

        tools_btn = StyledButton("Tools Center", "info")
        tools_btn.clicked.connect(self._open_tools_center)
        top_layout.addWidget(tools_btn)

        user_btn = QToolButton()
        user_btn.setText(f"{self.current_user.display_name} ▼")
        user_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        user_btn.setMinimumHeight(44)
        user_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        user_btn.setStyleSheet("""
            QToolButton {
                background-color: #FFFFFF;
                color: #0F172A;
                border: 1px solid #E5E7EB;
                border-radius: 8px;
                padding: 9px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QToolButton::menu-indicator { image: none; width: 0px; }
            QToolButton:hover { background-color: #F8FAFC; border-color: #CBD5E1; }
        """)
        user_menu = QMenu(user_btn)
        user_menu.addAction("Profile", lambda: self.tabs.setCurrentWidget(self.settings_tab))
        user_menu.addAction("Settings", lambda: self.tabs.setCurrentWidget(self.settings_tab))
        user_menu.addSeparator()
        user_menu.addAction("Logout", self.logout_requested.emit)
        user_btn.setMenu(user_menu)
        top_layout.addWidget(user_btn)

        top_bar.setLayout(top_layout)
        main_layout.addWidget(top_bar)

        # Main content tabs
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
                top: -1px;
            }
            QTabBar::tab {
                background: #F8FAFC;
                color: #334155;
                border: none;
                min-height: 30px;
                padding: 9px 22px;
                font-size: 14px;
                font-weight: 600;
            }
            QTabBar::tab:hover {
                color: #2563EB;
                background: #EEF6FF;
            }
            QTabBar::tab:selected {
                background: #FFFFFF;
                color: #2563EB;
                border-bottom: 3px solid #2563EB;
            }
        """)

        # Tab 1: Dashboard
        self.dashboard_tab = self._create_dashboard_tab()
        self.tabs.addTab(self.dashboard_tab, "Dashboard")

        # Tab 2: My Reports
        self.report_tab = self._create_report_tab()
        self.tabs.addTab(self.report_tab, "My Reports")

        # Tab 3: Comments & Feedback
        self.feedback_tab = self._create_feedback_tab()
        self.tabs.addTab(self.feedback_tab, "Feedback Center")

        # Tab 4: Analytics
        self.analytics_widget = StatisticsWidget(self.db, is_teacher=False)
        self.tabs.addTab(self.analytics_widget, "Analytics")

        # Tab 5: Tools
        self.tools_tab = self._create_tools_tab()
        self.tabs.addTab(self.tools_tab, "Tools")

        # Tab 6: Settings
        self.settings_tab = self._create_settings_tab()
        self.tabs.addTab(self.settings_tab, "Settings")

        main_layout.addWidget(self.tabs, 1)
        self.setCentralWidget(central)

        self.statusBar().showMessage("Ready")

        # Connect tab change
        self.tabs.currentChanged.connect(self._on_tab_changed)

    def _init_ui(self):
        """Build a SaaS-style student workspace with a fixed left sidebar."""
        self.setWindowTitle(f"UniversalWeekly - Student Panel [{self.current_user.display_name}]")
        self.setMinimumSize(1220, 780)
        self.setStyleSheet("""
            QMainWindow { background-color: #F6F8FC; }
            QMenuBar { background: #0F172A; color: white; padding: 4px; }
            QMenuBar::item:selected { background: #2563EB; }
            QStatusBar { background: #F6F8FC; color: #64748B; }
        """)

        central = QWidget()
        shell_layout = QHBoxLayout(central)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)

        self.nav_buttons = {}
        self.page_widgets = {}
        self.nav_titles = {}
        self.nav_subtitles = {}

        sidebar = self._create_student_sidebar()
        shell_layout.addWidget(sidebar)

        main_area = QWidget()
        main_area.setObjectName("MainArea")
        main_area.setStyleSheet("QWidget#MainArea { background: #F6F8FC; }")
        main_layout = QVBoxLayout(main_area)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        main_layout.addWidget(self._create_student_header())

        self.tabs = QStackedWidget()
        self.tabs.setObjectName("ContentStack")
        self.tabs.setStyleSheet("""
            QStackedWidget#ContentStack {
                background: transparent;
                border: none;
            }
        """)

        self.dashboard_tab = self._create_dashboard_tab()
        self.report_tab = self._create_report_tab()
        self.feedback_tab = self._create_feedback_tab()
        self.analytics_widget = StatisticsWidget(self.db, is_teacher=False)
        self.tools_tab = self._create_tools_tab()
        self.settings_tab = self._create_settings_tab()

        self._add_sidebar_page(
            "dashboard", "Dashboard", self.dashboard_tab,
            "Dashboard",
            "Here is your overview for this week."
        )
        self._add_sidebar_page(
            "reports", "My Reports", self.report_tab,
            "My Reports",
            "Create, edit, submit, export, and review your weekly reports."
        )
        self._add_sidebar_page(
            "feedback", "Feedback", self.feedback_tab,
            "Reviews & Feedback",
            "Read teacher comments and follow up on revision suggestions."
        )
        self._add_sidebar_page(
            "analytics", "Analytics", self.analytics_widget,
            "Analytics",
            "Review report completion, submission history, and progress trends."
        )
        self._add_sidebar_page(
            "tools", "Tools Center", self.tools_tab,
            "Tools Center",
            "Use academic, writing, conversion, and daily planning tools."
        )
        self._add_sidebar_page(
            "settings", "Settings", self.settings_tab,
            "Settings",
            "Manage profile, preferences, and system options."
        )

        self.tabs.currentChanged.connect(self._on_tab_changed)

        content_shell = QWidget()
        content_shell.setObjectName("ContentShell")
        content_shell.setStyleSheet("QWidget#ContentShell { background: #F6F8FC; }")
        content_layout = QVBoxLayout(content_shell)
        content_layout.setContentsMargins(28, 24, 28, 18)
        content_layout.setSpacing(0)
        content_layout.addWidget(self.tabs, 1)
        main_layout.addWidget(content_shell, 1)
        shell_layout.addWidget(main_area, 1)

        self.setCentralWidget(central)
        self.statusBar().showMessage("Ready")
        self._switch_page("dashboard")

    def _create_student_sidebar(self) -> QWidget:
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(220)
        sidebar.setStyleSheet("""
            QWidget#Sidebar {
                background: #061B49;
                border-right: 1px solid #0B2A66;
            }
            QLabel#SidebarLogo {
                color: #FFFFFF;
                font-size: 18px;
                font-weight: 800;
            }
            QLabel#SidebarSub {
                color: #93A4C7;
                font-size: 11px;
            }
            QLabel#SidebarSection {
                color: #93A4C7;
                font-size: 11px;
                font-weight: 700;
                padding: 12px 0 4px 2px;
            }
            QLabel#SidebarMeta {
                color: #CBD5E1;
                font-size: 12px;
            }
        """)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(14, 22, 14, 18)
        layout.setSpacing(8)

        brand = QWidget()
        brand_layout = QHBoxLayout(brand)
        brand_layout.setContentsMargins(0, 0, 0, 0)
        brand_layout.setSpacing(10)

        logo_mark = QLabel("UW")
        logo_mark.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_mark.setFixedSize(42, 42)
        logo_mark.setStyleSheet("""
            QLabel {
                background: #2563EB;
                color: #FFFFFF;
                border: none;
                border-radius: 14px;
                font-size: 14px;
                font-weight: 900;
            }
        """)

        logo_text = QWidget()
        logo_text_layout = QVBoxLayout(logo_text)
        logo_text_layout.setContentsMargins(0, 0, 0, 0)
        logo_text_layout.setSpacing(2)
        logo = QLabel("UniversalWeekly")
        logo.setObjectName("SidebarLogo")
        subtitle = QLabel("AI Weekly Workspace")
        subtitle.setObjectName("SidebarSub")
        logo_text_layout.addWidget(logo)
        logo_text_layout.addWidget(subtitle)

        brand_layout.addWidget(logo_mark)
        brand_layout.addWidget(logo_text, 1)
        layout.addWidget(brand)
        layout.addSpacing(18)

        self._add_sidebar_nav(layout, "dashboard", "Dashboard")
        self._add_sidebar_nav(layout, "reports", "My Reports")
        self._add_sidebar_nav(layout, "feedback", "Feedback")
        self._add_sidebar_nav(layout, "analytics", "Analytics")
        self._add_sidebar_action(layout, "AI Assistant", self._open_ai_assistant)
        self._add_sidebar_nav(layout, "tools", "Tools Center")
        self._add_sidebar_nav(layout, "settings", "Settings")

        layout.addStretch()
        role_label = QLabel("ROLE")
        role_label.setObjectName("SidebarSection")
        role_value = QLabel("Student")
        role_value.setObjectName("SidebarMeta")
        user_label = QLabel(self.current_user.display_name)
        user_label.setObjectName("SidebarMeta")
        version = QLabel("v1.0.0")
        version.setObjectName("SidebarMeta")
        layout.addWidget(role_label)
        layout.addWidget(role_value)
        layout.addWidget(user_label)
        layout.addSpacing(6)
        switch_btn = QPushButton("Switch Role")
        switch_btn.setMinimumHeight(40)
        switch_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        switch_btn.clicked.connect(self.logout_requested.emit)
        switch_btn.setStyleSheet(self._nav_button_style(False))
        layout.addWidget(switch_btn)
        layout.addWidget(version)
        return sidebar

    def _sidebar_section(self, text: str) -> QLabel:
        label = QLabel(text.upper())
        label.setObjectName("SidebarSection")
        return label

    def _add_sidebar_nav(self, layout: QVBoxLayout, key: str, title: str):
        btn = QPushButton(title)
        btn.setMinimumHeight(46)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.clicked.connect(lambda _, k=key: self._switch_page(k))
        btn.setStyleSheet(self._nav_button_style(False))
        self.nav_buttons[key] = btn
        layout.addWidget(btn)

    def _add_sidebar_action(self, layout: QVBoxLayout, title: str, callback):
        btn = QPushButton(title)
        btn.setMinimumHeight(46)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.clicked.connect(callback)
        btn.setStyleSheet(self._nav_button_style(False))
        layout.addWidget(btn)

    def _create_student_header(self) -> QWidget:
        header = QFrame()
        header.setObjectName("TopBar")
        header.setFixedHeight(72)
        header.setStyleSheet("""
            QFrame#TopBar {
                background: #FFFFFF;
                border-bottom: 1px solid #E5E7EB;
            }
        """)
        layout = QHBoxLayout(header)
        layout.setContentsMargins(28, 0, 28, 0)
        layout.setSpacing(14)

        title_block = QWidget()
        title_layout = QVBoxLayout(title_block)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(3)
        self.page_title_label = QLabel("Dashboard")
        self.page_title_label.setStyleSheet("font-size: 20px; font-weight: 800; color: #0F172A; border: none;")
        self.page_subtitle_label = QLabel("Here is what is happening with your weekly reports.")
        self.page_subtitle_label.setWordWrap(True)
        self.page_subtitle_label.setStyleSheet("font-size: 12px; color: #64748B; border: none;")
        title_layout.addWidget(self.page_title_label)
        title_layout.addWidget(self.page_subtitle_label)
        layout.addWidget(title_block, 1)

        unread = self.comment_service.get_unread_count(self.current_user.id)
        self.unread_label = QPushButton(f"Feedback {unread}")
        self.unread_label.setFixedHeight(36)
        self.unread_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.unread_label.clicked.connect(self._open_notification_center)
        self._style_notification_badge(unread)
        layout.addWidget(self.unread_label)

        user_btn = QToolButton()
        user_btn.setText(f"{self.current_user.display_name} v")
        user_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        user_btn.setFixedHeight(36)
        user_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        user_btn.setStyleSheet("""
            QToolButton {
                background-color: #FFFFFF;
                color: #0F172A;
                border: 1px solid #E5E7EB;
                border-radius: 10px;
                padding: 7px 14px;
                font-size: 13px;
                font-weight: 700;
            }
            QToolButton::menu-indicator { image: none; width: 0px; }
            QToolButton:hover { background-color: #F8FAFC; border-color: #CBD5E1; }
        """)
        user_menu = QMenu(user_btn)
        user_menu.addAction("Profile", lambda: self._switch_page("settings"))
        user_menu.addAction("Settings", lambda: self._switch_page("settings"))
        user_menu.addSeparator()
        user_menu.addAction("Logout", self.logout_requested.emit)
        self._style_action_menu(user_menu)
        user_btn.setMenu(user_menu)
        layout.addWidget(user_btn)
        return header

    def _style_notification_badge(self, unread: int):
        self.unread_label.setStyleSheet(
            f"""
            QPushButton {{
                color: {'#EF4444' if unread > 0 else '#16A34A'};
                background: {'#FEE2E2' if unread > 0 else '#EAF7EE'};
                border: 1px solid {'#FECACA' if unread > 0 else '#BBF7D0'};
                border-radius: 10px;
                font-weight: 700;
                padding: 0px 16px;
            }}
            QPushButton:hover {{ background: {'#FECACA' if unread > 0 else '#DCFCE7'}; }}
            """
        )

    def _add_sidebar_page(self, key: str, title: str, widget: QWidget, header: str, subtitle: str):
        self.tabs.addWidget(widget)
        self.page_widgets[key] = widget
        self.nav_titles[key] = header
        self.nav_subtitles[key] = subtitle

    def _switch_page(self, key: str):
        widget = self.page_widgets.get(key)
        if widget is None:
            return
        self.tabs.setCurrentWidget(widget)
        self._set_active_nav(key)
        self.page_title_label.setText(self.nav_titles.get(key, key.title()))
        self.page_subtitle_label.setText(self.nav_subtitles.get(key, ""))

    def _set_active_nav(self, active_key: str):
        for key, btn in self.nav_buttons.items():
            btn.setStyleSheet(self._nav_button_style(key == active_key))

    def _key_for_widget(self, widget: QWidget) -> str:
        for key, page in self.page_widgets.items():
            if page == widget:
                return key
        return ""

    def _nav_button_style(self, active: bool) -> str:
        if active:
            return """
                QPushButton {
                    background: #2563EB;
                    color: #FFFFFF;
                    border: none;
                    border-radius: 12px;
                    padding: 0px 16px;
                    text-align: left;
                    font-size: 14px;
                    font-weight: 800;
                }
            """
        return """
            QPushButton {
                background: transparent;
                color: #CBD5E1;
                border: none;
                border-radius: 12px;
                padding: 0px 16px;
                text-align: left;
                font-size: 14px;
                font-weight: 650;
            }
            QPushButton:hover {
                background: #0B2A66;
                color: #FFFFFF;
            }
        """

    def _on_tab_changed(self, index: int):
        current_widget = self.tabs.widget(index)
        key = self._key_for_widget(current_widget) if hasattr(self, "page_widgets") else ""
        if key:
            self._set_active_nav(key)
            self.page_title_label.setText(self.nav_titles.get(key, key.title()))
            self.page_subtitle_label.setText(self.nav_subtitles.get(key, ""))
        if current_widget == self.feedback_tab:
            self._load_feedback()
        elif current_widget == self.analytics_widget:
            self.analytics_widget.load_student_data(self.current_user.id)
        elif current_widget == self.dashboard_tab:
            self._refresh_dashboard()

    def _apply_card_shadow(self, widget: QWidget, blur: int = 16, y_offset: int = 4):
        shadow = QGraphicsDropShadowEffect(widget)
        shadow.setBlurRadius(blur)
        shadow.setOffset(0, y_offset)
        shadow.setColor(QColor(15, 23, 42, 16))
        widget.setGraphicsEffect(shadow)

    def _create_dashboard_tab(self) -> QWidget:
        widget = QWidget()
        widget.setStyleSheet("QWidget { background: #F6F8FC; }")
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        welcome_title = QLabel(f"Welcome back, {self.current_user.display_name}")
        welcome_title.setStyleSheet("font-size: 24px; font-weight: 900; color: #0F172A; border: none;")
        welcome_subtitle = QLabel("Here's your overview for this week.")
        welcome_subtitle.setStyleSheet("font-size: 13px; color: #64748B; border: none;")
        layout.addWidget(welcome_title)
        layout.addWidget(welcome_subtitle)

        card_row = QHBoxLayout()
        card_row.setSpacing(16)
        self.dashboard_total_value = self._create_kpi_card(card_row, "Total Reports", "0", "#2563EB")
        self.dashboard_submitted_value = self._create_kpi_card(card_row, "Submitted", "0", "#16A34A")
        self.dashboard_feedback_value = self._create_kpi_card(card_row, "Unread Feedback", "0", "#F59E0B")
        self.dashboard_complete_value = self._create_kpi_card(card_row, "Completeness", "0%", "#7C3AED")
        layout.addLayout(card_row)

        mid_row = QHBoxLayout()
        mid_row.setSpacing(16)
        mid_row.addWidget(self._create_dashboard_progress_card(), 3)
        mid_row.addWidget(self._create_dashboard_quick_actions(), 2)
        layout.addLayout(mid_row)

        recent_card = QFrame()
        recent_card.setObjectName("DashboardRecentCard")
        recent_card.setStyleSheet("""
            QFrame#DashboardRecentCard {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 16px;
            }
            QLabel {
                border: none;
                background: transparent;
            }
        """)
        self._apply_card_shadow(recent_card)
        recent_layout = QVBoxLayout(recent_card)
        recent_layout.setContentsMargins(18, 16, 18, 18)
        recent_layout.setSpacing(12)

        recent_head = QHBoxLayout()
        recent_title = QLabel("Recent Reports")
        recent_title.setStyleSheet("font-size: 16px; font-weight: 900; color: #0F172A;")
        view_all_btn = QPushButton("Go to My Reports")
        view_all_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        view_all_btn.clicked.connect(lambda: self._switch_page("reports"))
        view_all_btn.setStyleSheet("""
            QPushButton {
                background: #EAF2FF;
                color: #2563EB;
                border: none;
                border-radius: 10px;
                padding: 8px 14px;
                font-size: 12px;
                font-weight: 800;
            }
            QPushButton:hover {
                background: #DBEAFE;
            }
        """)
        recent_head.addWidget(recent_title)
        recent_head.addStretch()
        recent_head.addWidget(view_all_btn)
        recent_layout.addLayout(recent_head)

        self.dashboard_recent_table = QTableWidget()
        self.dashboard_recent_table.setColumnCount(5)
        self.dashboard_recent_table.setHorizontalHeaderLabels(
            ["Week", "Date Range", "Status", "Completeness", "Feedback"]
        )
        recent_header = self.dashboard_recent_table.horizontalHeader()
        recent_header.setStretchLastSection(True)
        recent_header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        recent_header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        recent_header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        recent_header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        self.dashboard_recent_table.setColumnWidth(0, 90)
        self.dashboard_recent_table.setColumnWidth(1, 180)
        self.dashboard_recent_table.setColumnWidth(2, 110)
        self.dashboard_recent_table.setColumnWidth(3, 120)
        self.dashboard_recent_table.verticalHeader().setVisible(False)
        self.dashboard_recent_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.dashboard_recent_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.dashboard_recent_table.setAlternatingRowColors(True)
        self.dashboard_recent_table.setStyleSheet(self._table_style())
        recent_layout.addWidget(self.dashboard_recent_table, 1)
        layout.addWidget(recent_card, 1)

        return widget

    def _create_kpi_card(self, parent_layout: QHBoxLayout, title: str, value: str, color: str) -> QLabel:
        card = QFrame()
        card.setObjectName("DashboardKpiCard")
        card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        card.setMinimumHeight(122)
        card.setStyleSheet("""
            QFrame#DashboardKpiCard {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 16px;
            }
        """)
        self._apply_card_shadow(card)

        layout = QHBoxLayout(card)
        layout.setContentsMargins(18, 18, 18, 16)
        layout.setSpacing(14)

        icon_map = {
            "Total Reports": "R",
            "Submitted": "S",
            "Unread Feedback": "F",
            "Completeness": "%",
        }
        icon_bg_map = {
            "Total Reports": "#EAF2FF",
            "Submitted": "#DCFCE7",
            "Unread Feedback": "#FEF3C7",
            "Completeness": "#F3E8FF",
        }
        subtitle_map = {
            "Total Reports": "All created reports",
            "Submitted": "Reports submitted",
            "Unread Feedback": "Comments waiting",
            "Completeness": "Average completion",
        }

        icon = QLabel(icon_map.get(title, ""))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setFixedSize(48, 48)
        icon.setStyleSheet(f"""
            QLabel {{
                background: {icon_bg_map.get(title, "#EAF2FF")};
                color: {color};
                border: none;
                border-radius: 24px;
                font-size: 17px;
                font-weight: 900;
            }}
        """)

        text_layout = QVBoxLayout()
        text_layout.setSpacing(3)
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #64748B; font-size: 12px; font-weight: 800; border: none;")
        value_label = QLabel(value)
        value_label.setStyleSheet("color: #0F172A; font-size: 30px; font-weight: 900; border: none;")
        subtitle_label = QLabel(subtitle_map.get(title, ""))
        subtitle_label.setStyleSheet("color: #94A3B8; font-size: 12px; border: none;")
        text_layout.addWidget(title_label)
        text_layout.addWidget(value_label)
        text_layout.addWidget(subtitle_label)

        layout.addWidget(icon)
        layout.addLayout(text_layout, 1)
        parent_layout.addWidget(card)
        return value_label

    def _create_metric_card(self, parent_layout: QHBoxLayout, title: str, value: str, color: str) -> QLabel:
        card = QFrame()
        card.setObjectName("DashboardMetricCard")
        card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        card.setMinimumHeight(132)
        card.setStyleSheet(f"""
            QFrame#DashboardMetricCard {{
                background: white;
                border: 1px solid #EEF2F7;
                border-radius: 14px;
            }}
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(20, 18, 20, 16)
        layout.setSpacing(8)

        icon_map = {
            "Total Reports": "📄",
            "Submitted": "✓",
            "Unread Feedback": "💬",
            "Completeness": "📊",
        }
        icon_bg_map = {
            "Total Reports": "#EFF6FF",
            "Submitted": "#ECFDF5",
            "Unread Feedback": "#FFF7ED",
            "Completeness": "#F5F3FF",
        }
        subtitle_map = {
            "Total Reports": "All created weekly reports",
            "Submitted": "Reports submitted",
            "Unread Feedback": "No pending review",
            "Completeness": "Average completion",
        }
        title_row = QHBoxLayout()
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #64748B; font-size: 12px; font-weight: bold; border: none;")
        icon_label = QLabel(icon_map.get(title, "•"))
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setFixedSize(30, 30)
        icon_label.setStyleSheet(f"""
            QLabel {{
                color: {color};
                background: {icon_bg_map.get(title, "#F8FAFC")};
                border: none;
                border-radius: 15px;
                font-size: 15px;
                font-weight: bold;
            }}
        """)
        title_row.addWidget(title_label)
        title_row.addStretch()
        title_row.addWidget(icon_label)
        value_label = QLabel(value)
        value_label.setStyleSheet(f"color: {color}; font-size: 34px; font-weight: bold; border: none;")
        subtitle_label = QLabel(subtitle_map.get(title, ""))
        subtitle_label.setStyleSheet("color: #94A3B8; font-size: 12px; border: none;")
        layout.addLayout(title_row)
        layout.addWidget(value_label)
        layout.addStretch()
        layout.addWidget(subtitle_label)
        parent_layout.addWidget(card)
        return value_label

    def _create_dashboard_progress_card(self) -> QFrame:
        card = QFrame()
        card.setObjectName("DashboardProgressCard")
        card.setStyleSheet("""
            QFrame#DashboardProgressCard {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 16px;
            }
        """)
        self._apply_card_shadow(card)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(22, 18, 22, 18)
        layout.setSpacing(10)

        title = QLabel("Weekly Progress")
        title.setStyleSheet("font-size: 16px; font-weight: 900; color: #0F172A; border: none;")
        self.dashboard_progress_week = QLabel("Current weekly report completion")
        self.dashboard_progress_week.setStyleSheet("font-size: 12px; color: #64748B; border: none;")
        self.dashboard_progress_percent = QLabel("0%")
        self.dashboard_progress_percent.setStyleSheet("font-size: 36px; font-weight: 900; color: #2563EB; border: none;")

        head = QHBoxLayout()
        title_block = QVBoxLayout()
        title_block.addWidget(title)
        title_block.addWidget(self.dashboard_progress_week)
        head.addLayout(title_block)
        head.addStretch()
        head.addWidget(self.dashboard_progress_percent)
        layout.addLayout(head)

        status_label = QLabel("Report Status")
        status_label.setStyleSheet("font-size: 12px; font-weight: 800; color: #334155; border: none;")
        layout.addWidget(status_label)

        self.dashboard_progress_bar = QProgressBar()
        self.dashboard_progress_bar.setRange(0, 100)
        self.dashboard_progress_bar.setValue(0)
        self.dashboard_progress_bar.setTextVisible(False)
        self.dashboard_progress_bar.setFixedHeight(12)
        self.dashboard_progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                border-radius: 6px;
                background: #E5E7EB;
            }
            QProgressBar::chunk {
                background: #2563EB;
                border-radius: 6px;
            }
        """)
        layout.addWidget(self.dashboard_progress_bar)

        self.dashboard_section_labels = {}
        for key, text in [
            ("tasks", "Tasks"),
            ("problems", "Problems & Reflection"),
            ("plans", "Next Week Plan"),
            ("summary", "Summary"),
        ]:
            label = QLabel(f"○ {text}")
            label.setText(f"[ ] {text}")
            label.setStyleSheet("font-size: 12px; color: #64748B; border: none; padding: 2px 0px;")
            self.dashboard_section_labels[key] = label
            layout.addWidget(label)

        self.dashboard_progress_tip = QLabel("Use AI Assistant to generate missing sections from keywords.")
        self.dashboard_progress_tip.setWordWrap(True)
        self.dashboard_progress_tip.setStyleSheet("""
            QLabel {
                color: #64748B;
                background: #F8FAFC;
                border: none;
                border-radius: 8px;
                padding: 8px 10px;
            }
        """)
        layout.addWidget(self.dashboard_progress_tip)
        return card

    def _create_dashboard_quick_actions(self) -> QFrame:
        card = QFrame()
        card.setObjectName("DashboardQuickActions")
        card.setStyleSheet("""
            QFrame#DashboardQuickActions {
                background: #F3E8FF;
                border: 1px solid #E9D5FF;
                border-radius: 16px;
            }
        """)
        self._apply_card_shadow(card)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)
        title = QLabel("AI Assistant")
        title.setStyleSheet("font-size: 17px; font-weight: 900; color: #0F172A; border: none;")
        hint = QLabel(f"Hi {self.current_user.display_name}. I can help you improve your weekly report.")
        hint.setWordWrap(True)
        hint.setStyleSheet("""
            QLabel {
                background: #FFFFFF;
                color: #334155;
                border: none;
                border-radius: 12px;
                padding: 12px 14px;
                font-size: 12px;
            }
        """)
        layout.addWidget(title)
        layout.addWidget(hint)

        actions = [
            ("Improve clarity and structure", self._open_ai_assistant),
            ("Check grammar and tone", self._open_ai_assistant),
            ("Suggest references", self._open_ai_assistant),
        ]
        for text, callback in actions:
            btn = QPushButton(text)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(callback)
            btn.setStyleSheet("""
                QPushButton {
                    background: #FFFFFF;
                    color: #0F172A;
                    border: 1px solid #E9D5FF;
                    border-radius: 10px;
                    padding: 10px 12px;
                    text-align: left;
                    font-size: 12px;
                    font-weight: 700;
                }
                QPushButton:hover {
                    background: #EAF2FF;
                    border-color: #BFDBFE;
                    color: #2563EB;
                }
            """)
            layout.addWidget(btn)

        layout.addStretch()
        ask_row = QHBoxLayout()
        ask_row.setSpacing(8)
        ask_input = QLineEdit()
        ask_input.setPlaceholderText("Ask me anything...")
        ask_input.setStyleSheet("""
            QLineEdit {
                background: #FFFFFF;
                border: 1px solid #E9D5FF;
                border-radius: 10px;
                padding: 10px 12px;
                color: #0F172A;
            }
            QLineEdit:focus {
                border-color: #7C3AED;
            }
        """)
        send_btn = QPushButton("Send")
        send_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        send_btn.clicked.connect(self._open_ai_assistant)
        send_btn.setStyleSheet("""
            QPushButton {
                background: #7C3AED;
                color: #FFFFFF;
                border: none;
                border-radius: 10px;
                padding: 10px 14px;
                font-weight: 800;
            }
            QPushButton:hover {
                background: #6D28D9;
            }
        """)
        ask_row.addWidget(ask_input, 1)
        ask_row.addWidget(send_btn)
        layout.addLayout(ask_row)
        return card

    def _create_tools_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)

        title = QLabel("Tools Center")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #1F2D3D;")
        layout.addWidget(title)

        layout.addWidget(self._create_tool_section("Academic Tools", [
            ("Reference Converter", "Convert references to APA, IEEE, MLA, or GB/T style.", self._open_reference_converter),
            ("Paper Card", "Generate a structured reading card from a title and abstract.", self._open_paper_card),
            ("Presentation", "Create presentation scripts from selected weekly reports.", self._open_presentation_report),
        ]))
        layout.addWidget(self._create_tool_section("Writing Tools", [
            ("Translation Tool", "Translate literature, weekly reports, comments, and words.", self._open_translation_tool),
            ("Memo Board", "Save polished temporary notes and research ideas.", self._open_memo_board),
            ("AI Calls", "View local model and AI assistant call history.", self._open_ai_call_history),
        ]))
        layout.addWidget(self._create_tool_section("Utility Tools", [
            ("File Converter", "Convert TXT, Markdown, Word, PDF, and PPT files.", self._open_file_converter),
            ("Weather & Time", "Show date, time, weather, and deadline reminders.", self._open_weather_time),
        ]))
        layout.addStretch()
        scroll.setWidget(widget)
        return scroll

    def _create_tool_section(self, title: str, tools: list[tuple[str, str, object]]) -> QGroupBox:
        group = QGroupBox(title)
        grid = QGridLayout(group)
        grid.setSpacing(12)
        for index, (name, desc, callback) in enumerate(tools):
            card = self._create_tool_card(name, desc, callback)
            grid.addWidget(card, index // 3, index % 3)
        return group

    def _create_tool_card(self, name: str, desc: str, callback) -> QFrame:
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background: #FFFFFF;
                border: 1px solid #E5EAF0;
                border-radius: 8px;
            }
        """)
        card.setMinimumHeight(120)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 12)
        label = QLabel(name)
        label.setStyleSheet("font-size: 15px; font-weight: bold; color: #1F2D3D;")
        text = QLabel(desc)
        text.setWordWrap(True)
        text.setStyleSheet("color: #6B7280;")
        open_btn = StyledButton("Open", "info")
        open_btn.clicked.connect(callback)
        layout.addWidget(label)
        layout.addWidget(text)
        layout.addStretch()
        layout.addWidget(open_btn)
        return card

    def _open_tools_center(self):
        dialog = ToolsCenterDialog(self)
        dialog.exec()

    def _open_notification_center(self):
        dialog = NotificationCenterDialog(self.db, self.current_user.id, self)
        dialog.exec()
        self._update_unread_count()

    def _open_ai_assistant(self):
        report_id = self._selected_report_id() if hasattr(self, "report_table") else None
        dialog = AIAssistantDialog(
            self.db,
            self.current_user.id,
            self.current_user.username,
            report_id,
            self,
        )
        dialog.exec()

    def _show_ai_actions(self, report_id: int):
        dialog = QDialog(self)
        dialog.setWindowTitle("AI Assistant")
        dialog.setMinimumSize(420, 360)
        layout = QVBoxLayout(dialog)
        title = QLabel("AI Assistant")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #1F2D3D;")
        hint = QLabel("Choose an AI action for the selected weekly report.")
        hint.setStyleSheet("color: #6B7280;")
        layout.addWidget(title)
        layout.addWidget(hint)

        actions = [
            ("Generate Weekly Report", "generate"),
            ("AI Analysis Center", "analysis"),
            ("Polish Language", "polish"),
            ("Check Completeness", "check"),
            ("Rewrite Based on Feedback", "rewrite"),
            ("Generate Presentation Script", "presentation"),
        ]
        for text, action in actions:
            btn = StyledButton(text, "ai" if action != "check" else "info")
            btn.clicked.connect(lambda checked=False, a=action: (dialog.accept(), self._run_ai_action(report_id, a)))
            layout.addWidget(btn)

        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(dialog.accept)
        layout.addStretch()
        layout.addWidget(close_btn)
        dialog.exec()

    def _open_reference_converter(self):
        dialog = ReferenceConverterDialog(self)
        dialog.exec()

    def _open_file_converter(self):
        dialog = FileConverterDialog(self)
        dialog.exec()

    def _open_translation_tool(self):
        dialog = TranslationDialog(self)
        dialog.exec()

    def _open_paper_card(self):
        dialog = PaperCardDialog(self)
        dialog.exec()

    def _open_presentation_report(self):
        dialog = PresentationReportDialog(self.db, self.current_user.id, self)
        dialog.exec()

    def _open_memo_board(self):
        dialog = MemoDialog(self.db, self.current_user.id, self)
        dialog.exec()

    def _open_weather_time(self):
        dialog = WeatherTimeDialog(self)
        dialog.exec()

    def _open_ai_call_history(self):
        dialog = AICallHistoryDialog(self.db, self.current_user.id, self)
        dialog.exec()

    def _open_ai_analysis(self, report_id: int):
        dialog = AIAnalysisDialog(self.db, report_id, self)
        dialog.exec()

    def _open_version_history(self, report_id: int):
        dialog = VersionHistoryDialog(self.db, self.current_user.id, report_id, self)
        dialog.exec()

    def _on_theme_changed(self, theme: str):
        self._apply_dark_mode(theme == "Dark")

    def _apply_dark_mode(self, enabled: bool):
        if enabled:
            self.setStyleSheet("""
                QMainWindow { background-color: #0F172A; }
                QWidget { color: #E5E7EB; }
                QMenuBar { background: #020617; color: #E5E7EB; padding: 4px; }
                QMenuBar::item:selected { background: #2563EB; }
                QStatusBar { background: #0F172A; color: #94A3B8; }
                QTabWidget::pane {
                    background: #111827;
                    border: 1px solid #334155;
                    border-radius: 12px;
                    top: -1px;
                }
                QTabBar::tab {
                    background: #0F172A;
                    color: #CBD5E1;
                    border: none;
                    min-height: 30px;
                    padding: 9px 22px;
                    font-size: 14px;
                    font-weight: 600;
                }
                QTabBar::tab:selected {
                    background: #111827;
                    color: #60A5FA;
                    border-bottom: 3px solid #60A5FA;
                }
            """)
        else:
            self.setStyleSheet("""
                QMainWindow { background-color: #F8FAFC; }
                QMenuBar { background: #0F172A; color: white; padding: 4px; }
                QMenuBar::item:selected { background: #2563EB; }
                QStatusBar { background: #F8FAFC; color: #64748B; }
            """)

    def _create_report_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setStyleSheet("QScrollArea { background: #F6F8FC; border: none; }")

        widget = QWidget()
        widget.setStyleSheet("QWidget { background: #F6F8FC; }")
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        # Toolbar
        filter_bar = QFrame()
        filter_bar.setObjectName("ReportToolbar")
        filter_bar.setFixedHeight(64)
        filter_bar.setStyleSheet("""
            QFrame#ReportToolbar {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
            }
            QLabel {
                color: #334155;
                font-size: 13px;
                font-weight: 700;
                border: none;
                background: transparent;
            }
            QComboBox, QLineEdit {
                background: #FFFFFF;
                border: 1px solid #D9E2EC;
                border-radius: 8px;
                padding: 7px 10px;
                color: #0F172A;
                min-height: 20px;
            }
            QComboBox:focus, QLineEdit:focus {
                border: 1px solid #2563EB;
            }
        """)
        f_layout = QHBoxLayout(filter_bar)
        f_layout.setContentsMargins(16, 10, 16, 10)
        f_layout.setSpacing(10)

        f_layout.addWidget(QLabel("Status:"))
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["All", "Draft", "Submitted", "Reviewed", "Approved", "Rejected"])
        self.filter_combo.setFixedWidth(132)
        self.filter_combo.currentTextChanged.connect(self._filter_reports)
        f_layout.addWidget(self.filter_combo)

        f_layout.addWidget(QLabel("Week:"))
        self.filter_week = QComboBox()
        self.filter_week.addItems(["All"] + [str(w) for w in range(1, 54)])
        self.filter_week.setFixedWidth(100)
        self.filter_week.currentTextChanged.connect(self._filter_reports)
        f_layout.addWidget(self.filter_week)

        f_layout.addWidget(QLabel("Search:"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search reports...")
        self.search_edit.setMinimumWidth(220)
        self.search_edit.textChanged.connect(self._filter_reports)
        f_layout.addWidget(self.search_edit, 1)

        reset_btn = StyledButton("Reset", "default")
        reset_btn.setFixedSize(76, 34)
        reset_btn.clicked.connect(self._reset_report_filters)
        f_layout.addWidget(reset_btn)

        f_layout.addStretch()
        new_report_btn = StyledButton("+ New Report", "primary")
        new_report_btn.setFixedHeight(36)
        new_report_btn.clicked.connect(self._new_report)
        f_layout.addWidget(new_report_btn)
        layout.addWidget(filter_bar)

        # Report table card
        table_card = QFrame()
        table_card.setObjectName("ReportTableCard")
        table_card.setFixedHeight(292)
        table_card.setStyleSheet("""
            QFrame#ReportTableCard {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 14px;
            }
        """)
        table_shadow = QGraphicsDropShadowEffect(table_card)
        table_shadow.setBlurRadius(18)
        table_shadow.setOffset(0, 4)
        table_shadow.setColor(QColor(15, 23, 42, 18))
        table_card.setGraphicsEffect(table_shadow)
        table_layout = QVBoxLayout(table_card)
        table_layout.setContentsMargins(0, 0, 0, 0)
        table_layout.setSpacing(0)

        self.report_table = QTableWidget()
        self.report_table.setFixedHeight(290)
        self.report_table.setColumnCount(8)
        self.report_table.setHorizontalHeaderLabels(
            ["Week", "Date Range", "Status", "Completeness", "Feedback", "Last Updated", "Actions", "Report ID"]
        )
        self.report_table.setColumnHidden(7, True)
        report_header = self.report_table.horizontalHeader()
        report_header.setStretchLastSection(False)
        report_header.setMinimumSectionSize(70)
        for col in (0, 1, 2, 4, 5):
            report_header.setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        report_header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        report_header.setSectionResizeMode(6, QHeaderView.ResizeMode.Fixed)
        self.report_table.setColumnWidth(0, 110)
        self.report_table.setColumnWidth(1, 200)
        self.report_table.setColumnWidth(2, 150)
        self.report_table.setColumnWidth(3, 120)
        self.report_table.setColumnWidth(4, 180)
        self.report_table.setColumnWidth(5, 200)
        self.report_table.setColumnWidth(6, 280)
        self.report_table.verticalHeader().setVisible(False)
        self.report_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.report_table.setAlternatingRowColors(True)
        self.report_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.report_table.setStyleSheet(self._table_style())
        self.report_table.itemDoubleClicked.connect(self._edit_report)
        self.report_table.currentCellChanged.connect(lambda *_: self._refresh_report_preview())
        table_layout.addWidget(self.report_table)
        layout.addWidget(table_card)

        bottom_cards = QHBoxLayout()
        bottom_cards.setSpacing(14)

        self.report_stats_label = QLabel("Total Reports: 0   Submitted: 0   Unread Feedback: 0   Average Completeness: 0%")
        self.report_stats_label.setStyleSheet("font-size: 12px; font-weight: 700; color: #64748B;")

        self.preview_frame = QFrame()
        self.preview_frame.setObjectName("ReportPreviewCard")
        self.preview_frame.setFixedHeight(280)
        self.preview_frame.setStyleSheet("""
            QFrame#ReportPreviewCard {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 14px;
            }
        """)
        preview_layout = QVBoxLayout(self.preview_frame)
        preview_layout.setContentsMargins(18, 16, 18, 16)
        preview_layout.setSpacing(8)
        preview_title = QLabel("Selected Report Preview")
        preview_title.setStyleSheet("font-size: 16px; font-weight: 800; color: #0F172A; border: none;")
        self.preview_meta = QLabel("Select a report to preview its status, completeness, feedback, and summary.")
        self.preview_meta.setStyleSheet("color: #64748B; border: none;")
        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setMinimumHeight(88)
        self.preview_text.setStyleSheet("""
            QTextEdit {
                background: #FFFFFF;
                color: #334155;
                border: 1px solid #E5E7EB;
                border-radius: 8px;
                padding: 8px;
                font-size: 12px;
                line-height: 1.35;
            }
            QScrollBar:vertical {
                background: #F8FAFC;
                width: 8px;
                margin: 2px 0px 2px 0px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #CBD5E1;
                border-radius: 4px;
                min-height: 22px;
            }
            QScrollBar::add-line:vertical,
            QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)
        preview_actions = QHBoxLayout()
        preview_actions.setSpacing(8)
        open_btn = StyledButton("Open Full Report", "primary")
        open_btn.setFixedHeight(34)
        open_btn.clicked.connect(self._view_details)
        polish_btn = StyledButton("AI Polish", "ai")
        polish_btn.setFixedHeight(34)
        polish_btn.clicked.connect(lambda: self._run_selected_ai_action("polish"))
        export_btn = StyledButton("Export", "success")
        export_btn.setFixedHeight(34)
        export_btn.clicked.connect(self._export_report)
        preview_actions.addWidget(open_btn)
        preview_actions.addWidget(polish_btn)
        preview_actions.addWidget(export_btn)
        preview_actions.addStretch()
        preview_layout.addWidget(preview_title)
        preview_layout.addWidget(self.report_stats_label)
        preview_layout.addWidget(self.preview_meta)
        preview_layout.addWidget(self.preview_text, 1)
        preview_layout.addLayout(preview_actions)

        workflow_card = self._create_workflow_guide_card()
        bottom_cards.addWidget(self.preview_frame, 2)
        bottom_cards.addWidget(workflow_card, 1)
        layout.addLayout(bottom_cards)

        summary_cards = QHBoxLayout()
        summary_cards.setSpacing(14)
        self.report_insights_card = self._create_bottom_summary_card(
            "Report Insights",
            ["Total Reports", "Submitted Reports", "Average Completeness", "Unread Feedback"],
        )
        self.ai_suggestions_card = self._create_bottom_summary_card(
            "AI Suggestions",
            ["Reports needing polish", "Drafts ready to submit", "Feedback needing review"],
        )
        self.recent_activity_card = self._create_bottom_summary_card(
            "Recent Activity",
            ["Last updated report", "Last AI action", "Last export action"],
        )
        summary_cards.addWidget(self.report_insights_card, 1)
        summary_cards.addWidget(self.ai_suggestions_card, 1)
        summary_cards.addWidget(self.recent_activity_card, 1)
        layout.addLayout(summary_cards, 1)

        widget.setLayout(layout)
        scroll.setWidget(widget)
        return scroll

    def _create_workflow_guide_card(self) -> QFrame:
        card = QFrame()
        card.setObjectName("WorkflowGuideCard")
        card.setFixedHeight(280)
        card.setStyleSheet("""
            QFrame#WorkflowGuideCard {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 14px;
            }
            QLabel {
                border: none;
                background: transparent;
            }
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(8)

        title = QLabel("Workflow Guide")
        title.setStyleSheet("font-size: 16px; font-weight: 800; color: #0F172A;")
        layout.addWidget(title)

        steps = [
            ("01", "Create Report"),
            ("02", "AI Polish / Check"),
            ("03", "Submit Report"),
            ("04", "Receive Feedback"),
            ("05", "Export Report"),
        ]
        for number, text in steps:
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(10)

            badge = QLabel(number)
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            badge.setFixedSize(30, 24)
            badge.setStyleSheet("""
                QLabel {
                    background: #EAF2FF;
                    color: #2563EB;
                    border-radius: 12px;
                    font-size: 11px;
                    font-weight: 800;
                }
            """)
            label = QLabel(text)
            label.setStyleSheet("font-size: 13px; font-weight: 700; color: #334155;")
            row_layout.addWidget(badge)
            row_layout.addWidget(label, 1)
            layout.addWidget(row)
        layout.addStretch(1)
        return card

    def _create_bottom_summary_card(self, title: str, item_names: list[str]) -> QFrame:
        card = QFrame()
        card.setObjectName("BottomSummaryCard")
        card.setMinimumHeight(165)
        card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        card.setStyleSheet("""
            QFrame#BottomSummaryCard {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 14px;
            }
            QLabel {
                border: none;
                background: transparent;
            }
        """)
        shadow = QGraphicsDropShadowEffect(card)
        shadow.setBlurRadius(14)
        shadow.setOffset(0, 3)
        shadow.setColor(QColor(15, 23, 42, 14))
        card.setGraphicsEffect(shadow)

        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(8)
        title_label = QLabel(title)
        title_label.setStyleSheet("font-size: 14px; font-weight: 800; color: #0F172A;")
        layout.addWidget(title_label)

        labels = {}
        for name in item_names:
            label = QLabel(f"{name}: --")
            label.setWordWrap(True)
            label.setStyleSheet("font-size: 12px; color: #64748B; font-weight: 600;")
            labels[name] = label
            layout.addWidget(label)
        layout.addStretch(1)
        card.summary_labels = labels
        return card

    def _create_feedback_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()

        layout.addWidget(SectionLabel("Teacher Feedback"))

        self.feedback_table = QTableWidget()
        self.feedback_table.setColumnCount(6)
        self.feedback_table.setHorizontalHeaderLabels(
            ["Week", "Teacher", "Comment", "Status", "Reply", "Comment ID"]
        )
        self.feedback_table.setColumnHidden(5, True)
        self.feedback_table.horizontalHeader().setStretchLastSection(True)
        self.feedback_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.feedback_table.setAlternatingRowColors(True)
        self.feedback_table.setStyleSheet(self._table_style())
        layout.addWidget(self.feedback_table)

        btn_row = QHBoxLayout()
        mark_read_btn = StyledButton("Mark as Read", "info")
        mark_read_btn.clicked.connect(self._mark_feedback_read)
        reply_btn = StyledButton("Reply", "primary")
        reply_btn.clicked.connect(self._reply_feedback)
        refresh_fb_btn = StyledButton("Refresh", "default")
        refresh_fb_btn.clicked.connect(self._load_feedback)

        btn_row.addWidget(mark_read_btn)
        btn_row.addWidget(reply_btn)
        btn_row.addStretch()
        btn_row.addWidget(refresh_fb_btn)
        layout.addLayout(btn_row)

        widget.setLayout(layout)
        return widget

    def _create_settings_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(SectionLabel("Account Settings"))

        form = QFormLayout()
        form.addRow("Username:", QLabel(self.current_user.username))

        self.settings_name = QLineEdit(self.current_user.display_name)
        form.addRow("Display Name:", self.settings_name)

        self.settings_class = QLineEdit(self.current_user.class_name)
        form.addRow("Class:", self.settings_class)

        self.settings_id = QLineEdit(self.current_user.student_id)
        form.addRow("Student ID:", self.settings_id)

        self.settings_email = QLineEdit(self.current_user.email)
        form.addRow("Email:", self.settings_email)

        layout.addLayout(form)

        save_settings_btn = StyledButton("Save Settings", "primary")
        save_settings_btn.clicked.connect(self._save_settings)
        layout.addWidget(save_settings_btn)

        layout.addWidget(SectionLabel("Workspace Preferences"))
        pref_form = QFormLayout()
        self.language_combo = QComboBox()
        self.language_combo.addItems(["English", "Chinese"])
        pref_form.addRow("Language:", self.language_combo)

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Light", "Dark"])
        self.theme_combo.currentTextChanged.connect(self._on_theme_changed)
        pref_form.addRow("Theme:", self.theme_combo)

        self.template_combo = QComboBox()
        self.template_combo.addItems(["Standard Weekly Report", "Project Progress Report", "Research Report"])
        pref_form.addRow("Default Report Template:", self.template_combo)

        self.ai_model_combo = QComboBox()
        self.ai_model_combo.addItems(["Ollama / qwen2.5:7b", "OpenAI-compatible", "Offline Template"])
        pref_form.addRow("AI Model:", self.ai_model_combo)

        self.export_format_combo = QComboBox()
        self.export_format_combo.addItems(["PDF", "Markdown", "Word", "Text"])
        pref_form.addRow("Default Export Format:", self.export_format_combo)
        layout.addLayout(pref_form)

        # Data management
        layout.addWidget(SectionLabel("Data Management"))
        data_layout = QHBoxLayout()

        backup_btn = StyledButton("Backup Data", "primary")
        backup_btn.clicked.connect(self._backup_data)
        data_layout.addWidget(backup_btn)

        export_all_btn = StyledButton("Export All Reports", "info")
        export_all_btn.clicked.connect(self._export_all)
        data_layout.addWidget(export_all_btn)

        layout.addLayout(data_layout)
        layout.addStretch()

        widget.setLayout(layout)
        return widget

    def _table_style(self) -> str:
        return """
            QTableWidget {
                border: 1px solid #E0E7EF;
                border-radius: 6px;
                gridline-color: #F0F3F7;
                background: white;
                alternate-background-color: #F8FAFC;
            }
            QHeaderView::section {
                background: #F8FAFC;
                color: #334155;
                padding: 8px;
                border: none;
                border-bottom: 1px solid #E5E7EB;
                font-weight: 800;
            }
            QTableWidget::item {
                padding: 6px;
                color: #2C3E50;
            }
            QTableWidget::item:hover {
                background: #F0F7FF;
            }
            QTableWidget::item:selected {
                background: #E8F2FF;
                color: #2C3E50;
            }
        """

    def _format_date_range(self, start_date: str, end_date: str) -> str:
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
            return f"{start.strftime('%b')} {start.day} - {end.strftime('%b')} {end.day}, {end.year}"
        except Exception:
            return f"{start_date} - {end_date}"

    def _format_datetime(self, value: str) -> str:
        if not value:
            return "N/A"
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
            try:
                parsed = datetime.strptime(value[:19], fmt)
                return parsed.strftime("%Y-%m-%d %H:%M")
            except Exception:
                continue
        return value[:16]

    def _report_section_status(self, report) -> dict[str, bool]:
        tasks, plans = self.report_service.get_report_tasks(report.id)
        problems = self.report_service.get_report_problems(report.id)
        return {
            "tasks": bool(tasks),
            "problems": bool(problems),
            "plans": bool(plans or (report.next_plan_summary or "").strip()),
            "summary": bool(
                (report.highlights or "").strip()
                or (report.shortcomings or "").strip()
                or (report.improvements or "").strip()
            ),
        }

    def _report_completeness(self, report) -> int:
        sections = self._report_section_status(report)
        return sum(25 for ready in sections.values() if ready)

    def _feedback_text(self, report_id: int) -> str:
        comments = self.comment_service.get_comments(report_id)
        if not comments:
            return "No feedback"
        unread = sum(1 for c in comments if not c.get("is_read"))
        if unread:
            return f"{unread} unread"
        return "Reviewed"

    def _make_completeness_badge(self, value: int) -> QWidget:
        container = QWidget()
        container.setFixedSize(120, 54)
        container.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        container.setStyleSheet("QWidget { background: transparent; }")
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        if value >= 90:
            text = f"{value}%"
            bg = "#DCFCE7"
            fg = "#16A34A"
        elif value >= 70:
            text = f"{value}%"
            bg = "#DBEAFE"
            fg = "#2563EB"
        elif value >= 40:
            text = f"{value}%"
            bg = "#FEF3C7"
            fg = "#D97706"
        else:
            text = f"{value}%"
            bg = "#FEE2E2"
            fg = "#DC2626"

        badge = QLabel(text)
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        badge.setFixedSize(68, 24)
        badge.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        badge.setStyleSheet(f"""
            QLabel {{
                background: {bg};
                color: {fg};
                border: none;
                border-radius: 12px;
                font-size: 12px;
                font-weight: 700;
                padding: 0px;
            }}
        """)
        layout.addWidget(badge, 0, Qt.AlignmentFlag.AlignCenter)
        return container

    def _make_report_actions(self, report_id: int) -> QWidget:
        container = QWidget()
        container.setFixedSize(280, 54)
        container.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        container.setStyleSheet("QWidget { background: transparent; }")
        layout = QHBoxLayout(container)
        layout.setContentsMargins(6, 12, 6, 12)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addStretch(1)

        view_btn = self._make_compact_action_button(
            "View", "#EAF2FF", "#2563EB", 60
        )
        view_btn.clicked.connect(lambda: self._view_details_by_id(report_id))
        edit_btn = self._make_compact_action_button(
            "Edit", "#F1F5F9", "#334155", 60
        )
        edit_btn.clicked.connect(lambda: self._open_report_dialog(report_id))

        ai_btn = self._make_compact_menu_button(
            "AI v", "#F3E8FF", "#7C3AED", 58
        )
        ai_menu = QMenu(ai_btn)
        ai_menu.addAction("Generate Weekly Report", lambda: self._run_ai_action(report_id, "generate"))
        ai_menu.addAction("AI Analysis Center", lambda: self._run_ai_action(report_id, "analysis"))
        ai_menu.addAction("Polish Language", lambda: self._run_ai_action(report_id, "polish"))
        ai_menu.addAction("Check Completeness", lambda: self._run_ai_action(report_id, "check"))
        ai_menu.addAction("Rewrite Based on Feedback", lambda: self._run_ai_action(report_id, "rewrite"))
        ai_menu.addAction("Generate Presentation Script", lambda: self._run_ai_action(report_id, "presentation"))
        self._style_action_menu(ai_menu)
        ai_btn.setMenu(ai_menu)

        more_btn = self._make_compact_menu_button(
            "More v", "#ECFDF5", "#16A34A", 70
        )
        more_menu = QMenu(more_btn)
        more_menu.addAction("Export Markdown", lambda: self._export_report_by_id(report_id, "markdown"))
        more_menu.addAction("Export TXT", lambda: self._export_report_by_id(report_id, "txt"))
        more_menu.addAction("Export Word", lambda: self._export_report_by_id(report_id, "word"))
        more_menu.addAction("Export PDF", lambda: self._export_report_by_id(report_id, "pdf"))
        more_menu.addSeparator()
        more_menu.addAction("Version History", lambda: self._open_version_history(report_id))
        more_menu.addSeparator()
        more_menu.addAction("Delete", lambda: self._delete_report_by_id(report_id))
        self._style_action_menu(more_menu)
        more_btn.setMenu(more_menu)

        layout.addWidget(view_btn)
        layout.addWidget(edit_btn)
        layout.addWidget(ai_btn)
        layout.addWidget(more_btn)
        layout.addStretch(1)
        return container

    def _style_action_menu(self, menu: QMenu):
        menu.setStyleSheet("""
            QMenu {
                background: #FFFFFF;
                color: #0F172A;
                border: 1px solid #E5E7EB;
                border-radius: 8px;
                padding: 6px;
            }
            QMenu::item {
                background: transparent;
                color: #0F172A;
                padding: 8px 18px 8px 14px;
                border-radius: 6px;
                min-width: 150px;
                font-size: 12px;
            }
            QMenu::item:selected {
                background: #EAF2FF;
                color: #2563EB;
            }
            QMenu::separator {
                height: 1px;
                background: #E5E7EB;
                margin: 5px 8px;
            }
        """)

    def _make_compact_action_button(self, text: str, bg: str, fg: str, width: int) -> QPushButton:
        button = QPushButton(text)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setFixedSize(width, 30)
        button.setStyleSheet(f"""
            QPushButton {{
                background: {bg};
                color: {fg};
                border: 1px solid {fg}33;
                border-radius: 8px;
                padding: 0px 10px;
                font-size: 12px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background: {fg}18;
                border: 1px solid {fg}66;
            }}
            QPushButton:pressed {{
                background: {fg}24;
            }}
        """)
        return button

    def _make_compact_menu_button(self, text: str, bg: str, fg: str, width: int) -> QToolButton:
        button = QToolButton()
        button.setText(text)
        button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setFixedSize(width, 30)
        button.setStyleSheet(f"""
            QToolButton {{
                background: {bg};
                color: {fg};
                border: 1px solid {fg}33;
                border-radius: 8px;
                padding: 0px 10px;
                font-size: 12px;
                font-weight: 700;
            }}
            QToolButton:hover {{
                background: {fg}18;
                border: 1px solid {fg}66;
            }}
            QToolButton::menu-indicator {{
                image: none;
                width: 0px;
            }}
        """)
        return button

    def _load_reports(self):
        reports = self.db.get_reports_by_user(self.current_user.id)
        self._all_reports = reports
        self._filter_reports()

    def _reset_report_filters(self):
        if hasattr(self, "filter_combo"):
            self.filter_combo.setCurrentText("All")
        if hasattr(self, "filter_week"):
            self.filter_week.setCurrentText("All")
        if hasattr(self, "search_edit"):
            self.search_edit.clear()
        self._filter_reports()

    def _filter_reports(self):
        status_filter = self.filter_combo.currentText()
        week_filter = self.filter_week.currentText()
        search_text = self.search_edit.text().strip().lower() if hasattr(self, "search_edit") else ""

        filtered = self._all_reports if hasattr(self, '_all_reports') else []
        if status_filter != "All":
            filtered = [r for r in filtered if r.status.lower() == status_filter.lower()]
        if week_filter != "All":
            filtered = [r for r in filtered if str(r.week_number) == week_filter]
        if search_text:
            def matches(report) -> bool:
                haystack = " ".join([
                    f"week {report.week_number}",
                    report.start_date or "",
                    report.end_date or "",
                    report.status or "",
                    report.highlights or "",
                    report.shortcomings or "",
                    report.improvements or "",
                    report.next_plan_summary or "",
                    self._feedback_text(report.id),
                ]).lower()
                return search_text in haystack

            filtered = [r for r in filtered if matches(r)]

        self.report_table.setRowCount(0)
        for report in filtered:
            row = self.report_table.rowCount()
            self.report_table.insertRow(row)
            self.report_table.setRowHeight(row, 54)

            completeness = self._report_completeness(report)
            self.report_table.setItem(row, 0, QTableWidgetItem(f"Week {report.week_number}"))
            self.report_table.setItem(row, 1, QTableWidgetItem(self._format_date_range(report.start_date, report.end_date)))
            self.report_table.setCellWidget(row, 2, StatusBadge(report.status))
            self.report_table.setCellWidget(row, 3, self._make_completeness_badge(completeness))
            self.report_table.setItem(row, 4, QTableWidgetItem(self._feedback_text(report.id)))
            self.report_table.setItem(row, 5, QTableWidgetItem(self._format_datetime(report.updated_at or report.created_at)))
            self.report_table.setCellWidget(row, 6, self._make_report_actions(report.id))
            self.report_table.setItem(row, 7, QTableWidgetItem(str(report.id)))

        last_updated = max((r.updated_at or r.created_at for r in filtered), default="")
        report_word = "report" if len(filtered) == 1 else "reports"
        status_text = f"Showing {len(filtered)} {report_word}"
        if last_updated:
            status_text += f" - Last updated: {self._format_datetime(last_updated)}"
        self.statusBar().showMessage(status_text)
        self._refresh_report_stats(filtered)
        self._refresh_dashboard()
        self._refresh_report_preview()

    def _selected_report_id(self) -> Optional[int]:
        if not hasattr(self, "report_table"):
            return None
        row = self.report_table.currentRow()
        if row < 0 or not self.report_table.item(row, 7):
            return None
        try:
            return int(self.report_table.item(row, 7).text())
        except Exception:
            return None

    def _refresh_report_stats(self, reports):
        if not hasattr(self, "report_stats_label"):
            return
        total = len(reports)
        submitted = sum(1 for r in reports if r.status in ("submitted", "reviewed", "approved"))
        unread = self.comment_service.get_unread_count(self.current_user.id)
        avg = round(sum(self._report_completeness(r) for r in reports) / total) if total else 0
        self.report_stats_label.setText(
            f"Total Reports: {total}   Submitted: {submitted}   "
            f"Unread Feedback: {unread}   Average Completeness: {avg}%"
        )
        self._refresh_bottom_summary_cards(reports)

    def _set_summary_card_value(self, card: QFrame, key: str, value: str):
        labels = getattr(card, "summary_labels", {})
        if key in labels:
            labels[key].setText(f"{key}: {value}")

    def _latest_log_text(self, keyword: str, empty_text: str) -> str:
        try:
            logs = self.db.get_operation_logs(self.current_user.id, limit=50)
        except Exception:
            return empty_text
        keyword = keyword.lower()
        for log in logs:
            haystack = f"{log.operation_type} {log.description}".lower()
            if keyword in haystack:
                created = self._format_datetime(log.created_at)
                detail = log.description or log.operation_type
                if len(detail) > 44:
                    detail = detail[:41] + "..."
                return f"{created} - {detail}"
        return empty_text

    def _refresh_bottom_summary_cards(self, reports):
        if not hasattr(self, "report_insights_card"):
            return
        total = len(reports)
        submitted = sum(1 for r in reports if r.status in ("submitted", "reviewed", "approved"))
        unread = self.comment_service.get_unread_count(self.current_user.id)
        avg = round(sum(self._report_completeness(r) for r in reports) / total) if total else 0

        self._set_summary_card_value(self.report_insights_card, "Total Reports", str(total))
        self._set_summary_card_value(self.report_insights_card, "Submitted Reports", str(submitted))
        self._set_summary_card_value(self.report_insights_card, "Average Completeness", f"{avg}%")
        self._set_summary_card_value(self.report_insights_card, "Unread Feedback", str(unread))

        needs_polish = sum(1 for r in reports if self._report_completeness(r) < 100)
        ready_drafts = sum(1 for r in reports if r.status == "draft" and self._report_completeness(r) >= 75)
        self._set_summary_card_value(self.ai_suggestions_card, "Reports needing polish", str(needs_polish))
        self._set_summary_card_value(self.ai_suggestions_card, "Drafts ready to submit", str(ready_drafts))
        self._set_summary_card_value(self.ai_suggestions_card, "Feedback needing review", str(unread))

        latest = max(reports, key=lambda r: (r.updated_at or r.created_at), default=None)
        latest_text = (
            f"Week {latest.week_number} - {self._format_datetime(latest.updated_at or latest.created_at)}"
            if latest else "No reports yet"
        )
        self._set_summary_card_value(self.recent_activity_card, "Last updated report", latest_text)
        self._set_summary_card_value(
            self.recent_activity_card,
            "Last AI action",
            self._latest_log_text("ai", "No AI action yet"),
        )
        self._set_summary_card_value(
            self.recent_activity_card,
            "Last export action",
            self._latest_log_text("export", "No export action yet"),
        )

    def _refresh_dashboard(self):
        if not hasattr(self, "dashboard_recent_table"):
            return
        reports = self._all_reports if hasattr(self, "_all_reports") else self.db.get_reports_by_user(self.current_user.id)
        total = len(reports)
        submitted = sum(1 for r in reports if r.status in ("submitted", "reviewed", "approved"))
        unread = self.comment_service.get_unread_count(self.current_user.id)
        avg = round(sum(self._report_completeness(r) for r in reports) / total) if total else 0
        self.dashboard_total_value.setText(str(total))
        self.dashboard_submitted_value.setText(str(submitted))
        self.dashboard_feedback_value.setText(str(unread))
        self.dashboard_complete_value.setText(f"{avg}%")
        newest_report = max(reports, key=lambda r: (r.week_number, r.updated_at or r.created_at), default=None)
        self._update_dashboard_progress_overview(newest_report)

        self.dashboard_recent_table.setRowCount(0)
        for report in reports[:5]:
            row = self.dashboard_recent_table.rowCount()
            self.dashboard_recent_table.insertRow(row)
            self.dashboard_recent_table.setRowHeight(row, 54)
            self.dashboard_recent_table.setItem(row, 0, QTableWidgetItem(f"Week {report.week_number}"))
            self.dashboard_recent_table.setItem(row, 1, QTableWidgetItem(self._format_date_range(report.start_date, report.end_date)))
            self.dashboard_recent_table.setCellWidget(row, 2, StatusBadge(report.status))
            self.dashboard_recent_table.setCellWidget(row, 3, self._make_completeness_badge(self._report_completeness(report)))
            self.dashboard_recent_table.setItem(row, 4, QTableWidgetItem(self._feedback_text(report.id)))

    def _dashboard_section_status(self, report) -> dict[str, bool]:
        return self._report_section_status(report)

    def _update_dashboard_progress_overview(self, report):
        if not hasattr(self, "dashboard_progress_percent"):
            return
        label_texts = {
            "tasks": "Tasks",
            "problems": "Problems & Reflection",
            "plans": "Next Week Plan",
            "summary": "Summary",
        }
        if report is None:
            self.dashboard_progress_week.setText("No weekly report yet")
            self.dashboard_progress_percent.setText("0%")
            self.dashboard_progress_bar.setValue(0)
            for key, label in self.dashboard_section_labels.items():
                label.setText(f"[ ] {label_texts[key]}")
                label.setStyleSheet("font-size: 12px; color: #64748B; border: none; padding: 2px 0px;")
            self.dashboard_progress_tip.setText("Create a weekly report or use AI Assistant to start from keywords.")
            return

        sections = self._dashboard_section_status(report)
        completed = sum(1 for ready in sections.values() if ready)
        percent = completed * 25
        self.dashboard_progress_week.setText(f"Week {report.week_number} report completion status")
        self.dashboard_progress_percent.setText(f"{percent}%")
        self.dashboard_progress_bar.setValue(percent)
        for key, ready in sections.items():
            self.dashboard_section_labels[key].setText(f"{'[x]' if ready else '[ ]'} {label_texts[key]}")
            color = "#16A34A" if ready else "#64748B"
            self.dashboard_section_labels[key].setStyleSheet(f"font-size: 12px; color: {color}; border: none; padding: 2px 0px;")
        if percent == 100:
            tip = "All main sections are complete. You can polish, submit, or export this report."
        elif percent >= 75:
            tip = "You have completed most parts. Finish the remaining section before submission."
        elif percent >= 50:
            tip = "The report has a useful foundation. Add missing reflection or planning details."
        else:
            tip = "The report is incomplete. Use AI Assistant to generate missing sections from keywords."
        self.dashboard_progress_tip.setText(tip)

    def _refresh_report_preview(self):
        if not hasattr(self, "preview_meta"):
            return
        report_id = self._selected_report_id()
        if report_id is None:
            self.preview_meta.setText("Select a report to preview its status, completeness, feedback, and summary.")
            self.preview_text.setPlainText("")
            return
        report = self.db.get_report(report_id)
        if not report:
            return
        completeness = self._report_completeness(report)
        self.preview_meta.setText(
            f"Week {report.week_number} | {self._format_date_range(report.start_date, report.end_date)} | "
            f"Status: {report.status.title()} | Completeness: {completeness}% | "
            f"Last Updated: {self._format_datetime(report.updated_at or report.created_at)}"
        )
        summary_parts = [
            ("Highlights", report.highlights),
            ("Problems", report.shortcomings),
            ("Improvements", report.improvements),
            ("Next Week Plan", report.next_plan_summary),
        ]
        preview = []
        for label, text in summary_parts:
            clean = (text or "").strip()
            if clean:
                preview.append(f"{label}:\n{clean}")
        self.preview_text.setPlainText(
            "\n\n".join(preview)
            if preview
            else "No summary content yet. Use AI Generate or Edit to complete this report."
        )

    def _new_report(self):
        # Check if report already exists for this week
        week = self.report_service.get_current_week_number()
        existing = [r for r in (self._all_reports if hasattr(self, '_all_reports') else [])
                    if r.week_number == week and r.status == "draft"]
        if existing:
            reply = QMessageBox.question(
                self, "Draft Exists",
                f"You already have a draft for week {week}. Edit it?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                self._open_report_dialog(existing[0].id)
                return

        dialog = WeeklyReportDialog(
            self.db, self.current_user.id, self.current_user.class_name
        )
        dialog.report_saved.connect(lambda rid: self._load_reports())
        dialog.exec()

    def _new_ai_report(self):
        dialog = WeeklyReportDialog(
            self.db, self.current_user.id, self.current_user.class_name
        )
        dialog.tabs.setCurrentIndex(3)  # Summary tab with local LLM generator.
        dialog.report_saved.connect(lambda rid: self._load_reports())
        dialog.exec()

    def _edit_report(self):
        row = self.report_table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a report.")
            return
        report_id = int(self.report_table.item(row, 7).text())
        self._open_report_dialog(report_id)

    def _open_report_dialog(self, report_id: int):
        dialog = WeeklyReportDialog(
            self.db, self.current_user.id, self.current_user.class_name, report_id
        )
        dialog.report_saved.connect(lambda rid: self._load_reports())
        dialog.exec()

    def _view_details(self):
        report_id = self._selected_report_id()
        if report_id is None:
            return
        self._view_details_by_id(report_id)

    def _view_details_by_id(self, report_id: int):
        dialog = ReportDetailDialog(self.db, report_id, self)
        dialog.exec()

    def _delete_report(self):
        report_id = self._selected_report_id()
        if report_id is None:
            return
        self._delete_report_by_id(report_id)

    def _delete_report_by_id(self, report_id: int):
        reply = QMessageBox.question(
            self, "Confirm Delete",
            "Delete this report and all its tasks? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.report_service.delete_report(report_id)
            self._load_reports()

    def _export_report(self):
        report_id = self._selected_report_id()
        if report_id is None:
            return
        self._export_report_by_id(report_id)

    def _export_report_by_id(self, report_id: int, export_format: Optional[str] = None):
        report = self.db.get_report(report_id)
        week = report.week_number if report else "report"
        format_options = {
            "markdown": ("Markdown (*.md)", f"weekly_report_week_{week}.md", ".md"),
            "txt": ("Text File (*.txt)", f"weekly_report_week_{week}.txt", ".txt"),
            "word": ("Word Document (*.docx)", f"weekly_report_week_{week}.docx", ".docx"),
            "pdf": ("PDF Document (*.pdf)", f"weekly_report_week_{week}.pdf", ".pdf"),
        }
        if export_format in format_options:
            file_filter, default_name, suffix = format_options[export_format]
            filters = file_filter
        else:
            default_name = f"weekly_report_week_{week}"
            suffix = ""
            filters = "Markdown (*.md);;Word Document (*.docx);;PDF Document (*.pdf);;Text File (*.txt)"

        path, selected_filter = QFileDialog.getSaveFileName(
            self, "Export Report", default_name, filters
        )
        if path:
            if suffix and not path.lower().endswith(suffix):
                path += suffix
            elif not export_format and "." not in os.path.basename(path):
                if "Word" in selected_filter:
                    path += ".docx"
                elif "PDF" in selected_filter:
                    path += ".pdf"
                elif "Text" in selected_filter:
                    path += ".txt"
                else:
                    path += ".md"
            success = False
            lowered = path.lower()
            if lowered.endswith(".md"):
                success = self.export_service.export_to_markdown(report_id, path)
            elif lowered.endswith(".docx"):
                success = self.export_service.export_to_docx(report_id, path)
            elif lowered.endswith(".pdf"):
                success = self.export_service.export_to_pdf(report_id, path)
            elif lowered.endswith(".txt"):
                success = self.export_service.export_to_txt(report_id, path)
            if success:
                report = self.db.get_report(report_id)
                week = report.week_number if report else report_id
                self.db.log_operation(
                    self.current_user.id,
                    self.current_user.username,
                    "export",
                    f"Exported Week {week} report to {os.path.basename(path)}",
                )
                self._refresh_bottom_summary_cards(
                    self._all_reports if hasattr(self, "_all_reports") else self.db.get_reports_by_user(self.current_user.id)
                )
                QMessageBox.information(self, "Success", "Report exported.")
            else:
                QMessageBox.warning(self, "Error", "Export failed.")

    def _run_selected_ai_action(self, action: str):
        report_id = self._selected_report_id()
        if report_id is None:
            QMessageBox.warning(self, "Warning", "Please select a report first.")
            return
        self._run_ai_action(report_id, action)

    def _run_ai_action(self, report_id: int, action: str):
        if action == "generate":
            dialog = WeeklyReportDialog(
                self.db, self.current_user.id, self.current_user.class_name, report_id
            )
            dialog.tabs.setCurrentIndex(3)
            dialog.report_saved.connect(lambda rid: self._load_reports())
            dialog.exec()
            self.db.log_operation(
                self.current_user.id,
                self.current_user.username,
                "ai_action",
                f"AI Generate Weekly Report for report {report_id}",
            )
            self._refresh_bottom_summary_cards(
                self._all_reports if hasattr(self, "_all_reports") else self.db.get_reports_by_user(self.current_user.id)
            )
            return
        if action == "analysis":
            self._open_ai_analysis(report_id)
            self.db.log_operation(
                self.current_user.id,
                self.current_user.username,
                "ai_action",
                f"AI Analysis Center for report {report_id}",
            )
            self._refresh_bottom_summary_cards(
                self._all_reports if hasattr(self, "_all_reports") else self.db.get_reports_by_user(self.current_user.id)
            )
            return

        report = self.db.get_report(report_id)
        if not report:
            QMessageBox.warning(self, "Warning", "Report not found.")
            return

        if action == "polish":
            title = "AI Polish Language"
            content = self._build_polished_report(report_id)
        elif action == "check":
            title = "AI Completeness Check"
            content = self._build_completeness_report(report)
        elif action == "rewrite":
            title = "AI Rewrite Based on Feedback"
            content = self._build_feedback_rewrite(report_id)
        elif action == "presentation":
            title = "AI Presentation Script"
            content = self._build_presentation_script(report_id)
        else:
            return

        dialog = AIResultDialog(title, content, self)
        dialog.exec()
        self.db.log_operation(
            self.current_user.id,
            self.current_user.username,
            "ai_action",
            f"{title} for Week {report.week_number}",
        )
        self._refresh_bottom_summary_cards(
            self._all_reports if hasattr(self, "_all_reports") else self.db.get_reports_by_user(self.current_user.id)
        )

    def _build_report_snapshot(self, report_id: int) -> dict:
        report = self.db.get_report(report_id)
        tasks, plans = self.report_service.get_report_tasks(report_id)
        problems = self.report_service.get_report_problems(report_id)
        comments = self.comment_service.get_comments(report_id)
        return {
            "report": report,
            "tasks": tasks,
            "plans": plans,
            "problems": problems,
            "comments": comments,
        }

    def _build_polished_report(self, report_id: int) -> str:
        data = self._build_report_snapshot(report_id)
        report = data["report"]
        tasks = data["tasks"]
        plans = data["plans"]
        problems = data["problems"]

        task_lines = []
        for task in tasks:
            task_lines.append(
                f"- {task.name}: {task.description or 'This task was advanced during the week.'} "
                f"(status: {task.status.replace('_', ' ')}, progress: {task.progress}%)."
            )
        problem_lines = []
        for problem in problems:
            problem_lines.append(
                f"- {problem.description}. Attempted solution: {problem.attempted_solution or 'Further review is needed.'} "
                f"Remaining issue: {problem.unresolved_reason or 'The issue still needs follow-up evidence.'}"
            )
        plan_lines = []
        for plan in plans:
            plan_lines.append(f"- {plan.name}: {plan.description or 'Continue this work and produce checkable results.'}")

        return f"""Week {report.week_number} Polished Weekly Report

1. Core Work This Week
{chr(10).join(task_lines) if task_lines else "- No task records have been added yet."}

2. Completed Outcomes and Progress
{report.highlights or "This section can be strengthened by adding concrete outcomes, progress evidence, and completed deliverables."}

3. Problems and Reflection
{chr(10).join(problem_lines) if problem_lines else (report.shortcomings or "- No problem records have been added yet.")}

4. Improvement Measures
{report.improvements or "Next, the work should be broken into smaller milestones, with clearer completion standards and better process records."}

5. Next Week Plan
{chr(10).join(plan_lines) if plan_lines else (report.next_plan_summary or "- No next-week plan has been added yet.")}
"""

    def _build_completeness_report(self, report) -> str:
        score = self._report_completeness(report)
        sections = self._report_section_status(report)
        checklist = [
            ("Tasks", sections["tasks"]),
            ("Problems & Reflection", sections["problems"]),
            ("Next Week Plan", sections["plans"]),
            ("Summary", sections["summary"]),
        ]
        lines = [f"Completeness: {score}%", ""]
        for name, ok in checklist:
            lines.append(f"{'[OK]' if ok else '[Missing]'} {name}")
        lines.append("")
        if score < 100:
            lines.append("AI Suggestion:")
            lines.append("Complete the missing sections before submission. A high-quality weekly report should include Tasks, Problems & Reflection, Next Week Plan, and Summary.")
        else:
            lines.append("AI Suggestion:")
            lines.append("The report is structurally complete. You can polish language and add evidence before exporting.")
        return "\n".join(lines)

    def _build_feedback_rewrite(self, report_id: int) -> str:
        data = self._build_report_snapshot(report_id)
        report = data["report"]
        comments = data["comments"]
        feedback_text = "\n".join(f"- {c.get('content', '')}" for c in comments) or "No teacher feedback has been recorded yet."
        base = self._build_polished_report(report_id)
        return f"""Teacher Feedback
{feedback_text}

AI Revision Suggestion
Based on the feedback above, revise Week {report.week_number} by making the implementation process more specific, adding clearer evidence for completed work, and explaining how each problem will be addressed in the next stage.

Suggested Revised Draft
{base}
"""

    def _build_presentation_script(self, report_id: int) -> str:
        data = self._build_report_snapshot(report_id)
        report = data["report"]
        tasks = data["tasks"]
        plans = data["plans"]
        main_tasks = ", ".join(t.name for t in tasks[:3]) or "my weekly study and project tasks"
        next_plans = ", ".join(p.name for p in plans[:3]) or "continue improving the unfinished work"
        return f"""1-Minute Presentation Script

Good morning. This is my Week {report.week_number} weekly report. During this week, I mainly focused on {main_tasks}. Through these tasks, I made progress in both work organization and practical implementation.

The main outcome is that I completed the key weekly tasks and clarified the next stage of work. At the same time, I noticed several issues, such as insufficient process evidence, limited reflection depth, or unclear follow-up planning. These problems remind me that a weekly report should not only record what was done, but also explain how the work was completed and what can be improved.

Next week, I plan to {next_plans}. I will make the plan more specific, record progress in time, and use teacher feedback to improve the final report quality. Thank you.
"""

    def _export_all(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Select Export Directory")
        if not dir_path:
            return
        reports = self.db.get_reports_by_user(self.current_user.id)
        report_ids = [r.id for r in reports]
        if report_ids:
            count = self.export_service.export_batch_markdown(report_ids, dir_path)
            QMessageBox.information(self, "Success", f"Exported {count} reports to {dir_path}")

    def _load_feedback(self):
        reports = self.db.get_reports_by_user(self.current_user.id)
        self.feedback_table.setRowCount(0)
        for report in reports:
            comments = self.comment_service.get_comments(report.id)
            for c in comments:
                row = self.feedback_table.rowCount()
                self.feedback_table.insertRow(row)
                self.feedback_table.setItem(row, 0, QTableWidgetItem(str(report.week_number)))
                self.feedback_table.setItem(row, 1, QTableWidgetItem(c.get("teacher_name", "Teacher")))
                self.feedback_table.setItem(row, 2, QTableWidgetItem(c["content"]))
                self.feedback_table.setItem(row, 3, QTableWidgetItem("Read" if c["is_read"] else "Unread"))
                self.feedback_table.setItem(row, 4, QTableWidgetItem("Yes" if c.get("student_reply") else "No"))
                self.feedback_table.setItem(row, 5, QTableWidgetItem(str(c["id"])))

    def _mark_feedback_read(self):
        row = self.feedback_table.currentRow()
        if row < 0:
            return
        comment_id = int(self.feedback_table.item(row, 5).text())
        self.comment_service.mark_read(comment_id)
        self.feedback_table.item(row, 3).setText("Read")
        self._update_unread_count()

    def _reply_feedback(self):
        row = self.feedback_table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a comment.")
            return
        comment_id = int(self.feedback_table.item(row, 5).text())

        from PyQt6.QtWidgets import QInputDialog
        reply, ok = QInputDialog.getMultiLineText(self, "Reply", "Enter your reply:")
        if ok and reply:
            self.comment_service.student_reply(comment_id, reply)
            QMessageBox.information(self, "Success", "Reply sent.")
            self._load_feedback()

    def _update_unread_count(self):
        unread = self.comment_service.get_unread_count(self.current_user.id)
        self.unread_label.setText(f"Notifications {unread}")
        self.unread_label.setStyleSheet(
            f"""
            QPushButton {{
                color: {'#EF4444' if unread > 0 else '#16A34A'};
                background: {'#FEE2E2' if unread > 0 else '#EAF7EE'};
                border: 1px solid {'#FECACA' if unread > 0 else '#BBF7D0'};
                border-radius: 8px;
                font-weight: bold;
                padding: 0px 16px;
            }}
            QPushButton:hover {{ background: {'#FECACA' if unread > 0 else '#DCFCE7'}; }}
            """
        )

    def _save_settings(self):
        self.db.update_user(
            self.current_user.id,
            display_name=self.settings_name.text(),
            class_name=self.settings_class.text(),
            student_id=self.settings_id.text(),
            email=self.settings_email.text(),
        )
        self.current_user = self.db.get_user_by_id(self.current_user.id)
        QMessageBox.information(self, "Success", "Settings saved.")

    def _backup_data(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Backup Data", f"backup_{datetime.now().strftime('%Y%m%d')}.db", "Database (*.db)"
        )
        if path:
            if self.db.backup(path):
                QMessageBox.information(self, "Success", "Data backed up.")
            else:
                QMessageBox.warning(self, "Error", "Backup failed.")


class ToolsCenterDialog(QDialog):
    """Card-based toolbox dialog for academic, writing, and utility tools."""

    def __init__(self, parent: StudentMainWindow):
        super().__init__(parent)
        self.parent_window = parent
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("Tools Center")
        self.setMinimumSize(760, 560)
        layout = QVBoxLayout(self)
        title = QLabel("Tools Center")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #1F2D3D;")
        subtitle = QLabel("Choose a tool for weekly reports, academic writing, file conversion, and daily planning.")
        subtitle.setStyleSheet("color: #6B7280;")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        grid = QGridLayout()
        grid.setSpacing(12)
        tools = [
            ("Reference Converter", "Convert references to APA / IEEE / MLA / GB/T.", self.parent_window._open_reference_converter),
            ("Paper Card", "Generate reading cards from paper title and abstract.", self.parent_window._open_paper_card),
            ("Presentation", "Create presentation scripts from weekly reports.", self.parent_window._open_presentation_report),
            ("Translation Tool", "Translate literature, words, reports, and comments.", self.parent_window._open_translation_tool),
            ("Memo Board", "Save polished notes and temporary ideas.", self.parent_window._open_memo_board),
            ("AI Calls", "Review local model and AI assistant call records.", self.parent_window._open_ai_call_history),
            ("File Converter", "Convert TXT, Markdown, Word, PDF, and PPT files.", self.parent_window._open_file_converter),
            ("Weather & Time", "Show current date, week, weather, and reminders.", self.parent_window._open_weather_time),
        ]
        for index, (name, desc, callback) in enumerate(tools):
            card = self._tool_card(name, desc, callback)
            grid.addWidget(card, index // 2, index % 2)
        layout.addLayout(grid, 1)

        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _tool_card(self, name: str, desc: str, callback) -> QFrame:
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background: #FFFFFF;
                border: 1px solid #E5EAF0;
                border-radius: 8px;
            }
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 12)
        title = QLabel(name)
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #1F2D3D;")
        body = QLabel(desc)
        body.setWordWrap(True)
        body.setStyleSheet("color: #6B7280;")
        open_btn = StyledButton("Open", "info")
        open_btn.clicked.connect(lambda: self._open_tool(callback))
        layout.addWidget(title)
        layout.addWidget(body)
        layout.addStretch()
        layout.addWidget(open_btn)
        return card

    def _open_tool(self, callback):
        self.accept()
        callback()


class AIResultDialog(QDialog):
    """Display AI-generated helper output in a readable, copyable panel."""

    def __init__(self, title: str, content: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(760, 560)
        layout = QVBoxLayout(self)
        header = QLabel(title)
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #1F2D3D;")
        layout.addWidget(header)

        self.output = QTextEdit()
        self.output.setPlainText(content)
        self.output.setReadOnly(False)
        self.output.setStyleSheet("""
            QTextEdit {
                background: #FFFFFF;
                border: 1px solid #D9E2EC;
                border-radius: 6px;
                padding: 10px;
                line-height: 1.4;
            }
        """)
        layout.addWidget(self.output, 1)

        btn_row = QHBoxLayout()
        copy_note = QLabel("You can edit or copy this AI output into the report editor.")
        copy_note.setStyleSheet("color: #6B7280;")
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(copy_note)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)


class ReportDetailDialog(QDialog):
    """Read-only report detail viewer."""

    def __init__(self, db: DatabaseManager, report_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.report_id = report_id
        self.report_service = ReportService(db)
        self.comment_service = CommentService(db)
        self._init_ui()
        self._load_data()

    def _init_ui(self):
        self.setWindowTitle("Report Details")
        self.setMinimumSize(700, 500)
        layout = QVBoxLayout()

        self.header = QLabel()
        self.header.setStyleSheet("font-size: 16px; font-weight: bold; padding: 8px;")
        layout.addWidget(self.header)

        tabs = QTabWidget()

        # Tasks tab
        tasks_tab = QWidget()
        t_layout = QVBoxLayout()
        self.task_table = QTableWidget()
        self.task_table.setColumnCount(5)
        self.task_table.setHorizontalHeaderLabels(["Category", "Task", "Status", "Task Progress", "Tags"])
        t_layout.addWidget(self.task_table)

        t_layout.addWidget(QLabel("Highlights:"))
        self.highlights = QLabel()
        self.highlights.setWordWrap(True)
        t_layout.addWidget(self.highlights)

        t_layout.addWidget(QLabel("Shortcomings:"))
        self.shortcomings = QLabel()
        self.shortcomings.setWordWrap(True)
        t_layout.addWidget(self.shortcomings)

        tasks_tab.setLayout(t_layout)
        tabs.addTab(tasks_tab, "Report")

        # Plans tab
        plans_tab = QWidget()
        p_layout = QVBoxLayout()
        self.plan_table = QTableWidget()
        self.plan_table.setColumnCount(2)
        self.plan_table.setHorizontalHeaderLabels(["Plan", "Category"])
        p_layout.addWidget(self.plan_table)

        p_layout.addWidget(QLabel("Summary:"))
        self.plan_summary = QLabel()
        self.plan_summary.setWordWrap(True)
        p_layout.addWidget(self.plan_summary)

        plans_tab.setLayout(p_layout)
        tabs.addTab(plans_tab, "Next Week Plans")

        # Comments tab
        comments_tab = QWidget()
        c_layout = QVBoxLayout()
        self.comment_table = QTableWidget()
        self.comment_table.setColumnCount(3)
        self.comment_table.setHorizontalHeaderLabels(["Teacher", "Comment", "Reply"])
        c_layout.addWidget(self.comment_table)
        comments_tab.setLayout(c_layout)
        tabs.addTab(comments_tab, "Comments")

        layout.addWidget(tabs)

        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

        self.setLayout(layout)

    def _load_data(self):
        report = self.db.get_report_with_student(self.report_id)
        if not report:
            self.header.setText("Report not found.")
            return
        self.header.setText(
            f"Week {report['week_number']} Report ({report['start_date']} ~ {report['end_date']})"
        )

        tasks, plans = self.report_service.get_report_tasks(self.report_id)

        self.task_table.setRowCount(0)
        for task in tasks:
            row = self.task_table.rowCount()
            self.task_table.insertRow(row)
            self.task_table.setItem(row, 0, QTableWidgetItem(task.category))
            self.task_table.setItem(row, 1, QTableWidgetItem(task.name))
            self.task_table.setItem(row, 2, QTableWidgetItem(task.status))
            self.task_table.setItem(row, 3, QTableWidgetItem(f"{task.progress}%"))
            self.task_table.setItem(row, 4, QTableWidgetItem(task.tags))

        self.highlights.setText(report.get("highlights", "None") or "None")
        self.shortcomings.setText(report.get("shortcomings", "None") or "None")

        self.plan_table.setRowCount(0)
        for plan in plans:
            row = self.plan_table.rowCount()
            self.plan_table.insertRow(row)
            self.plan_table.setItem(row, 0, QTableWidgetItem(plan.name))
            self.plan_table.setItem(row, 1, QTableWidgetItem(plan.category))

        comments = self.comment_service.get_comments(self.report_id)
        self.comment_table.setRowCount(0)
        for c in comments:
            row = self.comment_table.rowCount()
            self.comment_table.insertRow(row)
            self.comment_table.setItem(row, 0, QTableWidgetItem(c.get("teacher_name", "Teacher")))
            self.comment_table.setItem(row, 1, QTableWidgetItem(c["content"]))
            reply_parts = []
            if c.get("student_reply"):
                reply_parts.append(f"Student: {c['student_reply']}")
            if c.get("teacher_reply"):
                reply_parts.append(f"Teacher: {c['teacher_reply']}")
            self.comment_table.setItem(row, 2, QTableWidgetItem(" | ".join(reply_parts) or "No reply"))
