"""Notification center for review, comment, and deadline reminders."""

from __future__ import annotations

from datetime import datetime

from PyQt6.QtWidgets import QDialog, QLabel, QVBoxLayout

from database.db_manager import DatabaseManager
from ui.common_widgets import ReadOnlyTable, StyledButton


class NotificationCenterDialog(QDialog):
    """Show student-facing notifications generated from existing report data."""

    def __init__(self, db: DatabaseManager, user_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.user_id = user_id
        self._init_ui()
        self._load_notifications()

    def _init_ui(self):
        self.setWindowTitle("Notification Center")
        self.setMinimumSize(820, 520)
        self.setStyleSheet("""
            QDialog { background: #F8FAFC; }
            QLabel { color: #0F172A; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        title = QLabel("Notification Center")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        subtitle = QLabel("Review results, teacher comments, deadline reminders, and system messages.")
        subtitle.setStyleSheet("color: #64748B;")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        self.table = ReadOnlyTable(["Type", "Message", "Time", "Status"])
        layout.addWidget(self.table, 1)

        self.empty_label = QLabel("")
        self.empty_label.setStyleSheet("color: #64748B;")
        layout.addWidget(self.empty_label)

        close_btn = StyledButton("Close", "primary")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _load_notifications(self):
        self.table.clear_all()
        rows = []
        reports = self.db.get_reports_by_user(self.user_id)
        current_week = datetime.now().isocalendar()[1]

        has_current_week_report = any(report.week_number == current_week for report in reports)
        if not has_current_week_report:
            rows.append([
                "Deadline",
                f"Week {current_week} report has not been created yet.",
                datetime.now().strftime("%Y-%m-%d"),
                "Reminder",
            ])

        for report in reports:
            if report.status in {"reviewed", "approved", "rejected"}:
                rows.append([
                    "Review",
                    f"Week {report.week_number} report status changed to {report.status.title()}.",
                    report.updated_at or report.created_at,
                    report.status.title(),
                ])
            if report.status == "rejected":
                rows.append([
                    "Revision",
                    f"Week {report.week_number} report needs revision before resubmission.",
                    report.updated_at or report.created_at,
                    "Action Required",
                ])

            for comment in self.db.get_comments_by_report(report.id):
                rows.append([
                    "Teacher Comment",
                    f"Week {report.week_number}: {comment.get('content', '')}",
                    comment.get("created_at", ""),
                    "Unread" if not comment.get("is_read") else "Read",
                ])

        rows = sorted(rows, key=lambda item: item[2] or "", reverse=True)
        for row in rows:
            self.table.add_row(row)
        self.empty_label.setText("" if rows else "No notifications yet.")
