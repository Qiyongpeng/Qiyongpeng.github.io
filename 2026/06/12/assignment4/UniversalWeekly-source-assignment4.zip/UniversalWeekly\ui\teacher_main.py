"""Teacher main window - student report management, commenting, statistics."""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QSplitter, QTabWidget,
    QTextEdit, QListWidget, QListWidgetItem, QGroupBox,
    QFrame, QFileDialog, QMenu, QToolBar, QStatusBar,
    QDialog, QFormLayout, QDialogButtonBox, QCheckBox,
    QScrollArea, QGridLayout, QLineEdit, QStackedWidget, QToolButton
)
from PyQt6.QtCore import Qt, QSize, pyqtSignal
from PyQt6.QtGui import QAction, QFont, QIcon

from datetime import datetime
from typing import List, Optional
import os

from database.db_manager import DatabaseManager
from database.models import User
from business.auth_service import AuthService
from business.report_service import ReportService
from business.comment_service import CommentService
from business.statistics_service import StatisticsService
from business.export_service import ExportService
from business.template_service import TemplateService
from ui.common_widgets import (
    StyledButton, SectionLabel, CardFrame, StatusBadge,
    ReadOnlyTable, IconButton
)
from ui.statistics_widget import StatisticsWidget
from ui.weekly_report_dialog import WeeklyReportDialog
from ui.reference_converter_dialog import ReferenceConverterDialog
from ui.file_converter_dialog import FileConverterDialog
from ui.translation_dialog import TranslationDialog
from ui.paper_card_dialog import PaperCardDialog
from ui.memo_dialog import MemoDialog
from ui.weather_time_dialog import WeatherTimeDialog
from ui.ai_call_history_dialog import AICallHistoryDialog


class TeacherMainWindow(QMainWindow):
    """Main interface for teacher users."""

    logout_requested = pyqtSignal()

    def __init__(self, db: DatabaseManager, auth: AuthService):
        super().__init__()
        self.db = db
        self.auth = auth
        self.current_user = auth.current_user
        self.report_service = ReportService(db)
        self.comment_service = CommentService(db)
        self.stats_service = StatisticsService(db)
        self.export_service = ExportService(db)
        self.template_service = TemplateService(db)
        self._init_ui()
        self._setup_menus()
        self._load_classes()
        self._load_data()

    def _init_ui_legacy_top_tabs(self):
        self.setWindowTitle(f"UniversalWeekly - Teacher Panel [{self.current_user.display_name}]")
        self.setMinimumSize(1200, 800)
        self.setStyleSheet("""
            QMainWindow { background-color: #F5F7FA; }
            QMenuBar { background: #2C3E50; color: white; padding: 4px; }
            QMenuBar::item:selected { background: #4A90D9; }
            QStatusBar { background: #ECF0F1; }
        """)

        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(12, 12, 12, 12)

        # Top bar
        top_bar = QWidget()
        top_bar.setStyleSheet("background: white; border-radius: 8px; padding: 8px;")
        top_layout = QHBoxLayout()

        welcome = QLabel(f"Welcome, {self.current_user.display_name} (Teacher)")
        welcome.setStyleSheet("font-size: 16px; font-weight: bold; color: #2C3E50;")

        top_layout.addWidget(welcome)
        top_layout.addStretch()

        top_layout.addWidget(QLabel("Class:"))
        self.class_combo = QComboBox()
        self.class_combo.setMinimumWidth(150)
        self.class_combo.currentTextChanged.connect(self._load_data)
        top_layout.addWidget(self.class_combo)

        top_layout.addWidget(QLabel("Week:"))
        self.week_combo = QComboBox()
        self.week_combo.addItems([str(w) for w in range(1, 54)])
        self.week_combo.setCurrentText(str(datetime.now().isocalendar()[1]))
        self.week_combo.currentTextChanged.connect(self._load_data)
        top_layout.addWidget(self.week_combo)

        refresh_btn = StyledButton("Refresh", "primary")
        refresh_btn.clicked.connect(self._load_data)
        top_layout.addWidget(refresh_btn)

        tools_btn = StyledButton("Tools Center", "info")
        tools_btn.clicked.connect(self._open_tools_center)
        top_layout.addWidget(tools_btn)

        logout_btn = StyledButton("Logout", "danger")
        logout_btn.clicked.connect(self.logout_requested.emit)
        top_layout.addWidget(logout_btn)

        top_bar.setLayout(top_layout)
        main_layout.addWidget(top_bar)

        # Main content tabs
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { background: white; border-radius: 6px; }
            QTabBar::tab { padding: 10px 24px; font-size: 13px; }
            QTabBar::tab:selected { border-bottom: 3px solid #4A90D9; color: #4A90D9; font-weight: bold; }
        """)

        # Tab 1: Student reports
        self.report_tab = self._create_report_tab()
        self.tabs.addTab(self.report_tab, "Student Reports")

        # Tab 2: Batch comment
        self.comment_tab = self._create_comment_tab()
        self.tabs.addTab(self.comment_tab, "Comments")

        # Tab 3: Statistics
        self.stats_widget = StatisticsWidget(self.db, is_teacher=True)
        self.tabs.addTab(self.stats_widget, "Statistics")

        # Tab 4: Data management
        self.manage_tab = self._create_manage_tab()
        self.tabs.addTab(self.manage_tab, "Management")

        main_layout.addWidget(self.tabs, 1)
        self.setCentralWidget(central)

        self.statusBar().showMessage("Ready")

    def _init_ui(self):
        """Build a SaaS-style teacher workspace with a fixed left sidebar."""
        self.setWindowTitle(f"UniversalWeekly - Teacher Panel [{self.current_user.display_name}]")
        self.setMinimumSize(1220, 780)
        self.setStyleSheet("""
            QMainWindow { background-color: #F8FAFC; }
            QMenuBar { background: #0F172A; color: white; padding: 4px; }
            QMenuBar::item:selected { background: #2563EB; }
            QStatusBar { background: #F8FAFC; color: #64748B; }
        """)

        central = QWidget()
        shell_layout = QHBoxLayout(central)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)

        self.nav_buttons = {}
        self.page_widgets = {}
        self.nav_titles = {}
        self.nav_subtitles = {}

        shell_layout.addWidget(self._create_teacher_sidebar())

        main_area = QWidget()
        main_area.setObjectName("MainArea")
        main_area.setStyleSheet("QWidget#MainArea { background: #F8FAFC; }")
        main_layout = QVBoxLayout(main_area)
        main_layout.setContentsMargins(28, 22, 28, 18)
        main_layout.setSpacing(18)

        main_layout.addWidget(self._create_teacher_header())

        self.tabs = QStackedWidget()
        self.tabs.setObjectName("ContentStack")
        self.tabs.setStyleSheet("""
            QStackedWidget#ContentStack {
                background: transparent;
                border: none;
            }
        """)

        self.report_tab = self._create_report_tab()
        self.comment_tab = self._create_comment_tab()
        self.stats_widget = StatisticsWidget(self.db, is_teacher=True)
        self.manage_tab = self._create_manage_tab()

        self._add_teacher_page(
            "submissions", "Submissions", self.report_tab,
            "Submissions",
            "Review class weekly report submissions by class and week."
        )
        self._add_teacher_page(
            "reviews", "Feedback Templates", self.comment_tab,
            "Reviews & Feedback",
            "Send batch comments and manage reusable feedback templates."
        )
        self._add_teacher_page(
            "statistics", "Statistics", self.stats_widget,
            "Statistics",
            "Track submission rate, progress, status distribution, and class trends."
        )
        self._add_teacher_page(
            "management", "Export Data", self.manage_tab,
            "Export Data & Management",
            "Back up, restore, clean, export, and review operation logs."
        )

        self.tabs.currentChanged.connect(self._on_teacher_page_changed)
        main_layout.addWidget(self.tabs, 1)
        shell_layout.addWidget(main_area, 1)

        self.setCentralWidget(central)
        self.statusBar().showMessage("Ready")
        self._switch_page("submissions")

    def _create_teacher_sidebar(self) -> QWidget:
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(236)
        sidebar.setStyleSheet("""
            QWidget#Sidebar {
                background: #FFFFFF;
                border-right: 1px solid #E5E7EB;
            }
            QLabel#SidebarLogo {
                color: #0F172A;
                font-size: 18px;
                font-weight: 800;
            }
            QLabel#SidebarSub {
                color: #64748B;
                font-size: 11px;
            }
            QLabel#SidebarSection {
                color: #94A3B8;
                font-size: 11px;
                font-weight: 700;
                padding: 12px 0 4px 2px;
            }
            QLabel#SidebarMeta {
                color: #64748B;
                font-size: 12px;
            }
        """)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(16, 18, 16, 16)
        layout.setSpacing(8)

        logo = QLabel("UniversalWeekly")
        logo.setObjectName("SidebarLogo")
        subtitle = QLabel("Teacher Workspace")
        subtitle.setObjectName("SidebarSub")
        layout.addWidget(logo)
        layout.addWidget(subtitle)
        layout.addSpacing(14)

        layout.addWidget(self._sidebar_section("Review"))
        self._add_sidebar_nav(layout, "submissions", "Submissions")
        self._add_sidebar_nav(layout, "reviews", "Reviews & Feedback")
        self._add_sidebar_nav(layout, "statistics", "Statistics")

        layout.addWidget(self._sidebar_section("Workspace"))
        self._add_sidebar_action(layout, "Tools Center", self._open_tools_center)
        self._add_sidebar_nav(layout, "management", "Export Data")

        layout.addStretch()
        role_label = QLabel("ROLE")
        role_label.setObjectName("SidebarSection")
        role_value = QLabel("Teacher")
        role_value.setObjectName("SidebarMeta")
        user_label = QLabel(self.current_user.display_name)
        user_label.setObjectName("SidebarMeta")
        version = QLabel("v1.0.0")
        version.setObjectName("SidebarMeta")
        layout.addWidget(role_label)
        layout.addWidget(role_value)
        layout.addWidget(user_label)
        layout.addSpacing(6)
        layout.addWidget(version)
        return sidebar

    def _sidebar_section(self, text: str) -> QLabel:
        label = QLabel(text.upper())
        label.setObjectName("SidebarSection")
        return label

    def _add_sidebar_nav(self, layout: QVBoxLayout, key: str, title: str):
        btn = QPushButton(title)
        btn.setMinimumHeight(42)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.clicked.connect(lambda _, k=key: self._switch_page(k))
        btn.setStyleSheet(self._nav_button_style(False))
        self.nav_buttons[key] = btn
        layout.addWidget(btn)

    def _add_sidebar_action(self, layout: QVBoxLayout, title: str, callback):
        btn = QPushButton(title)
        btn.setMinimumHeight(42)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.clicked.connect(callback)
        btn.setStyleSheet(self._nav_button_style(False))
        layout.addWidget(btn)

    def _create_teacher_header(self) -> QWidget:
        header = QWidget()
        layout = QHBoxLayout(header)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)

        title_block = QWidget()
        title_layout = QVBoxLayout(title_block)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(3)
        self.page_title_label = QLabel("Submissions")
        self.page_title_label.setStyleSheet("font-size: 26px; font-weight: 800; color: #0F172A;")
        self.page_subtitle_label = QLabel("Review class weekly report submissions.")
        self.page_subtitle_label.setWordWrap(True)
        self.page_subtitle_label.setStyleSheet("font-size: 13px; color: #64748B;")
        title_layout.addWidget(self.page_title_label)
        title_layout.addWidget(self.page_subtitle_label)
        layout.addWidget(title_block, 1)

        layout.addWidget(QLabel("Class:"))
        self.class_combo = QComboBox()
        self.class_combo.setMinimumWidth(150)
        self.class_combo.currentTextChanged.connect(self._load_data)
        layout.addWidget(self.class_combo)

        layout.addWidget(QLabel("Week:"))
        self.week_combo = QComboBox()
        self.week_combo.addItems([str(w) for w in range(1, 54)])
        self.week_combo.setCurrentText(str(datetime.now().isocalendar()[1]))
        self.week_combo.currentTextChanged.connect(self._load_data)
        layout.addWidget(self.week_combo)

        refresh_btn = StyledButton("Refresh", "primary")
        refresh_btn.clicked.connect(self._load_data)
        layout.addWidget(refresh_btn)

        user_btn = QToolButton()
        user_btn.setText(f"{self.current_user.display_name} v")
        user_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        user_btn.setMinimumHeight(38)
        user_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        user_btn.setStyleSheet("""
            QToolButton {
                background-color: #FFFFFF;
                color: #0F172A;
                border: 1px solid #E5E7EB;
                border-radius: 10px;
                padding: 8px 14px;
                font-size: 13px;
                font-weight: 700;
            }
            QToolButton::menu-indicator { image: none; width: 0px; }
            QToolButton:hover { background-color: #F8FAFC; border-color: #CBD5E1; }
        """)
        user_menu = QMenu(user_btn)
        user_menu.addAction("Tools Center", self._open_tools_center)
        user_menu.addSeparator()
        user_menu.addAction("Logout", self.logout_requested.emit)
        user_btn.setMenu(user_menu)
        layout.addWidget(user_btn)
        return header

    def _add_teacher_page(self, key: str, title: str, widget: QWidget, header: str, subtitle: str):
        self.tabs.addWidget(widget)
        self.page_widgets[key] = widget
        self.nav_titles[key] = header
        self.nav_subtitles[key] = subtitle

    def _switch_page(self, key: str):
        widget = self.page_widgets.get(key)
        if widget is None:
            return
        self.tabs.setCurrentWidget(widget)
        self._set_active_nav(key)
        self.page_title_label.setText(self.nav_titles.get(key, key.title()))
        self.page_subtitle_label.setText(self.nav_subtitles.get(key, ""))

    def _on_teacher_page_changed(self, index: int):
        widget = self.tabs.widget(index)
        key = self._key_for_widget(widget)
        if key:
            self._set_active_nav(key)
            self.page_title_label.setText(self.nav_titles.get(key, key.title()))
            self.page_subtitle_label.setText(self.nav_subtitles.get(key, ""))
        if widget == self.stats_widget:
            self.stats_widget._refresh_teacher_stats()

    def _set_active_nav(self, active_key: str):
        for key, btn in self.nav_buttons.items():
            btn.setStyleSheet(self._nav_button_style(key == active_key))

    def _key_for_widget(self, widget: QWidget) -> str:
        for key, page in self.page_widgets.items():
            if page == widget:
                return key
        return ""

    def _nav_button_style(self, active: bool) -> str:
        if active:
            return """
                QPushButton {
                    background: #EEF4FF;
                    color: #2563EB;
                    border: none;
                    border-left: 4px solid #2563EB;
                    border-radius: 10px;
                    padding: 0px 12px;
                    text-align: left;
                    font-size: 14px;
                    font-weight: 800;
                }
            """
        return """
            QPushButton {
                background: transparent;
                color: #334155;
                border: none;
                border-left: 4px solid transparent;
                border-radius: 10px;
                padding: 0px 12px;
                text-align: left;
                font-size: 14px;
                font-weight: 650;
            }
            QPushButton:hover {
                background: #F1F5F9;
                color: #2563EB;
            }
        """

    def _setup_menus(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        export_action = QAction("Export Selected Reports", self)
        export_action.triggered.connect(self._export_selected)
        file_menu.addAction(export_action)

        backup_action = QAction("Backup Database", self)
        backup_action.triggered.connect(self._backup_db)
        file_menu.addAction(backup_action)

        restore_action = QAction("Restore Database", self)
        restore_action.triggered.connect(self._restore_db)
        file_menu.addAction(restore_action)

        file_menu.addSeparator()
        logout_action = QAction("Logout", self)
        logout_action.triggered.connect(self.logout_requested.emit)
        file_menu.addAction(logout_action)

        tools_menu = menubar.addMenu("Tools")
        tools_center_action = QAction("Open Tools Center", self)
        tools_center_action.triggered.connect(self._open_tools_center)
        tools_menu.addAction(tools_center_action)
        tools_menu.addSeparator()

        reference_action = QAction("Reference Converter", self)
        reference_action.triggered.connect(self._open_reference_converter)
        tools_menu.addAction(reference_action)

        file_converter_action = QAction("File Converter", self)
        file_converter_action.triggered.connect(self._open_file_converter)
        tools_menu.addAction(file_converter_action)

        translation_action = QAction("Translation Tool", self)
        translation_action.triggered.connect(self._open_translation_tool)
        tools_menu.addAction(translation_action)

        paper_card_action = QAction("Paper Reading Card", self)
        paper_card_action.triggered.connect(self._open_paper_card)
        tools_menu.addAction(paper_card_action)

        memo_action = QAction("Memo Board", self)
        memo_action.triggered.connect(self._open_memo_board)
        tools_menu.addAction(memo_action)

        weather_time_action = QAction("Weather & Time", self)
        weather_time_action.triggered.connect(self._open_weather_time)
        tools_menu.addAction(weather_time_action)

        ai_history_action = QAction("AI Call History", self)
        ai_history_action.triggered.connect(self._open_ai_call_history)
        tools_menu.addAction(ai_history_action)

    def _create_report_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()

        # Summary bar
        summary_bar = QWidget()
        summary_bar.setStyleSheet("background: #F8F9FA; border-radius: 4px; padding: 4px;")
        s_layout = QHBoxLayout()
        self.submitted_label = QLabel("Submitted: 0")
        self.unsubmitted_label = QLabel("Unsubmitted: 0")
        self.reviewed_label = QLabel("Reviewed: 0")
        for lbl in [self.submitted_label, self.unsubmitted_label, self.reviewed_label]:
            lbl.setStyleSheet("font-size: 12px; padding: 4px 12px;")
        s_layout.addWidget(self.submitted_label)
        s_layout.addWidget(self.unsubmitted_label)
        s_layout.addWidget(self.reviewed_label)
        s_layout.addStretch()

        self.batch_comment_btn = StyledButton("Batch Comment", "primary")
        self.batch_comment_btn.clicked.connect(self._batch_comment)
        s_layout.addWidget(self.batch_comment_btn)

        self.batch_export_btn = StyledButton("Batch Export", "info")
        self.batch_export_btn.clicked.connect(self._batch_export)
        s_layout.addWidget(self.batch_export_btn)

        summary_bar.setLayout(s_layout)
        layout.addWidget(summary_bar)

        # Report table
        self.report_table = QTableWidget()
        self.report_table.setColumnCount(7)
        self.report_table.setHorizontalHeaderLabels(
            ["Student", "ID", "Status", "Tasks", "Progress", "Week", "Report ID"]
        )
        self.report_table.setColumnHidden(6, True)
        self.report_table.horizontalHeader().setStretchLastSection(True)
        self.report_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.report_table.setAlternatingRowColors(True)
        self.report_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.report_table.setStyleSheet("""
            QTableWidget { border: 1px solid #E0E0E0; gridline-color: #F0F0F0; }
            QHeaderView::section { background: #4A90D9; color: white; padding: 6px; font-weight: bold; }
            QTableWidget::item:selected { background: #4A90D944; }
        """)
        self.report_table.itemDoubleClicked.connect(self._view_report)
        layout.addWidget(self.report_table)

        # Bottom controls
        btn_row = QHBoxLayout()
        view_btn = StyledButton("View Report", "info")
        view_btn.clicked.connect(self._view_report)
        comment_btn = StyledButton("Comment", "primary")
        comment_btn.clicked.connect(self._comment_single)
        export_btn = StyledButton("Export", "success")
        export_btn.clicked.connect(self._export_single)
        refresh_btn = StyledButton("Refresh", "default")
        refresh_btn.clicked.connect(self._load_data)

        btn_row.addWidget(view_btn)
        btn_row.addWidget(comment_btn)
        btn_row.addWidget(export_btn)
        btn_row.addWidget(refresh_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        widget.setLayout(layout)
        return widget

    def _create_comment_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left: comment list
        left_panel = QWidget()
        left_layout = QVBoxLayout()
        left_layout.addWidget(QLabel("Comment Templates:"))
        self.comment_template_list = QListWidget()
        self.comment_template_list.itemClicked.connect(self._template_selected)
        left_layout.addWidget(self.comment_template_list)

        template_hint = QLabel("System/shared templates are read-only. Your saved templates can be deleted.")
        template_hint.setWordWrap(True)
        template_hint.setStyleSheet("color: #6B7280; font-size: 12px;")
        left_layout.addWidget(template_hint)

        template_btn_row = QHBoxLayout()
        save_template_btn = StyledButton("Save as Template", "info")
        save_template_btn.clicked.connect(self._save_comment_template)
        delete_template_btn = StyledButton("Delete Selected", "danger")
        delete_template_btn.clicked.connect(self._delete_comment_template)
        template_btn_row.addWidget(save_template_btn)
        template_btn_row.addWidget(delete_template_btn)
        left_layout.addLayout(template_btn_row)
        left_panel.setLayout(left_layout)

        # Right: comment editor
        right_panel = QWidget()
        right_layout = QVBoxLayout()
        right_layout.addWidget(QLabel("Comment Content:"))
        self.comment_editor = QTextEdit()
        self.comment_editor.setPlaceholderText("Write your comment here...")
        right_layout.addWidget(self.comment_editor)

        send_btn = StyledButton("Send Comment to Selected Students", "primary")
        send_btn.clicked.connect(self._batch_comment_send)
        right_layout.addWidget(send_btn)

        right_panel.setLayout(right_layout)

        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setSizes([300, 500])
        layout.addWidget(splitter)

        widget.setLayout(layout)
        return widget

    def _create_manage_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(SectionLabel("Data Management"))

        cards = QGridLayout()

        # Backup card
        backup_card = CardFrame()
        b_layout = QVBoxLayout()
        b_layout.addWidget(QLabel("Database Backup"))
        b_layout.addWidget(QLabel("Create a full backup of all data."))
        b_layout.addWidget(QLabel(" "))
        backup_btn = StyledButton("Backup Now", "primary")
        backup_btn.clicked.connect(self._backup_db)
        b_layout.addWidget(backup_btn)
        backup_card.setLayout(b_layout)
        cards.addWidget(backup_card, 0, 0)

        # Restore card
        restore_card = CardFrame()
        r_layout = QVBoxLayout()
        r_layout.addWidget(QLabel("Database Restore"))
        r_layout.addWidget(QLabel("Restore data from a backup file."))
        r_layout.addWidget(QLabel(" "))
        restore_btn = StyledButton("Restore", "warning")
        restore_btn.clicked.connect(self._restore_db)
        r_layout.addWidget(restore_btn)
        restore_card.setLayout(r_layout)
        cards.addWidget(restore_card, 0, 1)

        # Cleanup card
        cleanup_card = CardFrame()
        c_layout = QVBoxLayout()
        c_layout.addWidget(QLabel("Data Cleanup"))
        c_layout.addWidget(QLabel("Remove reports older than 1 year."))
        c_layout.addWidget(QLabel(" "))
        cleanup_btn = StyledButton("Cleanup", "danger")
        cleanup_btn.clicked.connect(self._cleanup_data)
        c_layout.addWidget(cleanup_btn)
        cleanup_card.setLayout(c_layout)
        cards.addWidget(cleanup_card, 0, 2)

        layout.addLayout(cards)

        # Operation log
        layout.addWidget(SectionLabel("Operation Log"))
        self.log_table = ReadOnlyTable(["Time", "User", "Action", "Description"])
        layout.addWidget(self.log_table)

        refresh_log_btn = StyledButton("Refresh Log", "default")
        refresh_log_btn.clicked.connect(self._load_logs)
        layout.addWidget(refresh_log_btn)

        widget.setLayout(layout)
        return widget

    def _load_classes(self):
        classes = self.db.get_all_classes()
        self.class_combo.clear()
        if classes:
            self.class_combo.addItems(classes)
        else:
            self.class_combo.addItem("No classes")

    def _load_data(self):
        class_name = self.class_combo.currentText()
        if not class_name or class_name == "No classes":
            return
        week = int(self.week_combo.currentText())

        submissions = self.db.get_submission_status(class_name, week)
        self.report_table.setRowCount(0)

        submitted = 0
        unsubmitted = 0
        reviewed = 0

        for s in submissions:
            row = self.report_table.rowCount()
            self.report_table.insertRow(row)
            self.report_table.setItem(row, 0, QTableWidgetItem(s["display_name"]))
            self.report_table.setItem(row, 1, QTableWidgetItem(s.get("student_id", "")))

            status = s.get("report_status")
            if status:
                self.report_table.setItem(row, 2, QTableWidgetItem(status))
                submitted += 1
                if status in ("reviewed", "approved"):
                    reviewed += 1
            else:
                self.report_table.setItem(row, 2, QTableWidgetItem("Not Submitted"))

            # Count tasks and progress
            report_id = s.get("report_id")
            if report_id:
                tasks, _ = self.report_service.get_report_tasks(report_id)
                self.report_table.setItem(row, 3, QTableWidgetItem(str(len(tasks))))
                if tasks:
                    avg = sum(t.progress for t in tasks) / len(tasks)
                    self.report_table.setItem(row, 4, QTableWidgetItem(f"{avg:.0f}%"))
                else:
                    self.report_table.setItem(row, 4, QTableWidgetItem("0%"))
                self.report_table.setItem(row, 5, QTableWidgetItem(str(week)))
                self.report_table.setItem(row, 6, QTableWidgetItem(str(report_id)))
            else:
                self.report_table.setItem(row, 3, QTableWidgetItem("-"))
                self.report_table.setItem(row, 4, QTableWidgetItem("-"))
                self.report_table.setItem(row, 5, QTableWidgetItem(str(week)))
                self.report_table.setItem(row, 6, QTableWidgetItem(""))
            unsubmitted = len(submissions) - submitted

        self.submitted_label.setText(f"Submitted: {submitted}")
        self.unsubmitted_label.setText(f"Unsubmitted: {unsubmitted}")
        self.reviewed_label.setText(f"Reviewed: {reviewed}")

        # Load comment templates
        self.comment_template_list.clear()
        templates = self.template_service.get_all_available_templates(self.current_user.id, "comment")
        for t in templates:
            owner = "My" if t.user_id == self.current_user.id else ("System" if t.user_id is None else "Shared")
            item = QListWidgetItem(f"{t.name}  [{owner}]")
            item.setData(Qt.ItemDataRole.UserRole, t.id)
            self.comment_template_list.addItem(item)

        # Refresh statistics tab
        self.stats_widget._refresh_teacher_stats()

        self.statusBar().showMessage(f"Loaded {class_name} week {week} data")

    def _open_reference_converter(self):
        dialog = ReferenceConverterDialog(self)
        dialog.exec()

    def _open_file_converter(self):
        dialog = FileConverterDialog(self)
        dialog.exec()

    def _open_translation_tool(self):
        dialog = TranslationDialog(self)
        dialog.exec()

    def _open_paper_card(self):
        dialog = PaperCardDialog(self)
        dialog.exec()

    def _open_memo_board(self):
        dialog = MemoDialog(self.db, self.current_user.id, self)
        dialog.exec()

    def _open_weather_time(self):
        dialog = WeatherTimeDialog(self)
        dialog.exec()

    def _open_ai_call_history(self):
        dialog = AICallHistoryDialog(self.db, None, self)
        dialog.exec()

    def _open_tools_center(self):
        dialog = TeacherToolsCenterDialog(self)
        dialog.exec()

    def _view_report(self):
        row = self.report_table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a report.")
            return
        report_id_item = self.report_table.item(row, 6)
        if not report_id_item or not report_id_item.text():
            QMessageBox.information(self, "Info", "This student has not submitted a report.")
            return
        report_id = int(report_id_item.text())
        self._open_report_viewer(report_id)

    def _open_report_viewer(self, report_id: int):
        dialog = ReportViewerDialog(self.db, report_id, self.current_user.id, self)
        dialog.exec()
        self._load_data()

    def _comment_single(self):
        row = self.report_table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a report.")
            return
        report_id_item = self.report_table.item(row, 6)
        if not report_id_item or not report_id_item.text():
            QMessageBox.information(self, "Info", "This student has not submitted a report.")
            return
        report_id = int(report_id_item.text())

        dialog = SingleCommentDialog(self.db, report_id, self.current_user.id, self)
        if dialog.exec():
            self._load_data()

    def _batch_comment(self):
        self.tabs.setCurrentIndex(1)

    def _batch_comment_send(self):
        content = self.comment_editor.toPlainText().strip()
        if not content:
            QMessageBox.warning(self, "Warning", "Please enter comment content.")
            return

        selected = []
        for row in range(self.report_table.rowCount()):
            report_id_item = self.report_table.item(row, 6)
            if report_id_item and report_id_item.text():
                selected.append(int(report_id_item.text()))

        if not selected:
            QMessageBox.warning(self, "Warning", "No submitted reports to comment on.")
            return

        count = self.comment_service.batch_comment(selected, self.current_user.id, content)
        QMessageBox.information(self, "Success", f"Comment sent to {count} students.")
        self.comment_editor.clear()
        self._load_data()

    def _template_selected(self, item):
        template_id = item.data(Qt.ItemDataRole.UserRole)
        template = self._get_comment_template(template_id)
        if not template:
            return
        import json
        try:
            content = json.loads(template.content)
            templates_list = content.get("templates", [])
            if templates_list:
                self.comment_editor.setPlainText(templates_list[0])
        except json.JSONDecodeError:
            pass

    def _get_comment_template(self, template_id: int):
        templates = self.template_service.get_all_available_templates(self.current_user.id, "comment")
        for template in templates:
            if template.id == template_id:
                return template
        return None

    def _save_comment_template(self):
        content = self.comment_editor.toPlainText().strip()
        if not content:
            QMessageBox.warning(self, "Warning", "Comment content is empty.")
            return

        from PyQt6.QtWidgets import QInputDialog
        name, ok = QInputDialog.getText(self, "Template Name", "Enter template name:")
        if ok and name:
            data = {"templates": [content]}
            self.template_service.save_template(
                self.current_user.id, name, "comment", data
            )
            QMessageBox.information(self, "Success", "Template saved.")
            self._load_data()

    def _delete_comment_template(self):
        item = self.comment_template_list.currentItem()
        if not item:
            QMessageBox.warning(self, "Warning", "Please select a comment template to delete.")
            return

        template_id = item.data(Qt.ItemDataRole.UserRole)
        template = self._get_comment_template(template_id)
        if not template:
            QMessageBox.warning(self, "Warning", "Template not found. Please refresh and try again.")
            self._load_data()
            return

        if template.user_id != self.current_user.id:
            QMessageBox.information(
                self,
                "Read-only Template",
                "System or shared templates cannot be deleted. You can only delete templates saved by yourself."
            )
            return

        reply = QMessageBox.question(
            self,
            "Delete Template",
            f"Delete comment template \"{template.name}\"?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        if self.template_service.delete_template(template_id):
            self.db.log_operation(
                self.current_user.id,
                self.current_user.username,
                "delete_template",
                f"Deleted comment template: {template.name}"
            )
            self.comment_editor.clear()
            QMessageBox.information(self, "Success", "Template deleted.")
            self._load_data()
        else:
            QMessageBox.warning(self, "Error", "Template deletion failed.")

    def _export_single(self):
        row = self.report_table.currentRow()
        if row < 0:
            return
        report_id_item = self.report_table.item(row, 6)
        if not report_id_item or not report_id_item.text():
            return
        report_id = int(report_id_item.text())

        path, _ = QFileDialog.getSaveFileName(
            self, "Export Report", "", "Markdown (*.md);;Word (*.docx);;Text (*.txt)"
        )
        if path:
            success = False
            if path.endswith(".md"):
                success = self.export_service.export_to_markdown(report_id, path)
            elif path.endswith(".docx"):
                success = self.export_service.export_to_docx(report_id, path)
            elif path.endswith(".txt"):
                success = self.export_service.export_to_txt(report_id, path)
            if success:
                QMessageBox.information(self, "Success", "Report exported.")
            else:
                QMessageBox.warning(self, "Error", "Export failed.")

    def _export_selected(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Select Export Directory")
        if not dir_path:
            return
        report_ids = []
        for row in range(self.report_table.rowCount()):
            item = self.report_table.item(row, 6)
            if item and item.text():
                report_ids.append(int(item.text()))
        if report_ids:
            count = self.export_service.export_batch_markdown(report_ids, dir_path)
            QMessageBox.information(self, "Success", f"Exported {count} reports to {dir_path}")

    def _batch_export(self):
        self._export_selected()

    def _backup_db(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Backup Database", f"backup_{datetime.now().strftime('%Y%m%d')}.db",
            "SQLite Database (*.db)"
        )
        if path:
            if self.db.backup(path):
                QMessageBox.information(self, "Success", "Database backed up successfully.")
            else:
                QMessageBox.warning(self, "Error", "Backup failed.")

    def _restore_db(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Restore Database", "", "SQLite Database (*.db)"
        )
        if path:
            reply = QMessageBox.warning(
                self, "Confirm Restore",
                "This will overwrite all current data. Continue?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                if self.db.restore(path):
                    QMessageBox.information(self, "Success", "Database restored.")
                    self._load_data()
                else:
                    QMessageBox.warning(self, "Error", "Restore failed.")

    def _cleanup_data(self):
        reply = QMessageBox.warning(
            self, "Confirm Cleanup",
            "Delete all reports older than 1 year? This cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            one_year_ago = datetime.now().replace(year=datetime.now().year - 1).strftime("%Y-%m-%d")
            count = self.db.cleanup_old_reports(one_year_ago)
            QMessageBox.information(self, "Cleanup", f"{count} old reports deleted.")

    def _load_logs(self):
        self.log_table.clear_all()
        logs = self.db.get_operation_logs(limit=50)
        for log in logs:
            self.log_table.add_row([log.created_at, log.username, log.operation_type, log.description])


class TeacherToolsCenterDialog(QDialog):
    """Card-based toolbox dialog for teacher-side academic and utility tools."""

    def __init__(self, parent):
        super().__init__(parent)
        self.parent_window = parent
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("Tools Center")
        self.setMinimumSize(780, 560)
        self.setStyleSheet("""
            QDialog { background: #F8FAFC; }
            QFrame#ToolCard {
                background: #FFFFFF;
                border: 1px solid #E5EAF0;
                border-radius: 10px;
            }
            QLabel#ToolTitle {
                color: #1F2D3D;
                font-size: 15px;
                font-weight: bold;
            }
            QLabel#ToolDesc {
                color: #6B7280;
                font-size: 12px;
            }
            QGroupBox {
                background: #FFFFFF;
                border: 1px solid #E5EAF0;
                border-radius: 10px;
                margin-top: 16px;
                padding: 12px;
                font-weight: bold;
                color: #1F2D3D;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 6px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        title = QLabel("Tools Center")
        title.setStyleSheet("font-size: 22px; font-weight: bold; color: #0F172A;")
        subtitle = QLabel(
            "Choose a teacher-side tool for review work, academic writing, conversion, and daily planning."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("color: #64748B;")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        layout.addWidget(self._tool_section("Academic Tools", [
            ("Reference Converter", "Convert references to APA / IEEE / MLA / GB/T.", self.parent_window._open_reference_converter),
            ("Paper Reading Card", "Generate reading cards from paper title and abstract.", self.parent_window._open_paper_card),
        ]))
        layout.addWidget(self._tool_section("Writing & Review Tools", [
            ("Translation Tool", "Translate reports, comments, literature, and words.", self.parent_window._open_translation_tool),
            ("Memo Board", "Save review notes, reminders, and reusable comments.", self.parent_window._open_memo_board),
            ("AI Call History", "Review local model and AI assistant call records.", self.parent_window._open_ai_call_history),
        ]))
        layout.addWidget(self._tool_section("Utility Tools", [
            ("File Converter", "Convert TXT, Markdown, Word, PDF, and PPT files.", self.parent_window._open_file_converter),
            ("Weather & Time", "Show date, time, weather, and deadline reminders.", self.parent_window._open_weather_time),
        ]))
        layout.addStretch()

        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _tool_section(self, title: str, tools: list[tuple[str, str, object]]) -> QGroupBox:
        group = QGroupBox(title)
        grid = QGridLayout(group)
        grid.setSpacing(12)
        for index, (name, desc, callback) in enumerate(tools):
            grid.addWidget(self._tool_card(name, desc, callback), index // 2, index % 2)
        return group

    def _tool_card(self, name: str, desc: str, callback) -> QFrame:
        card = QFrame()
        card.setObjectName("ToolCard")
        card.setMinimumHeight(116)

        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(8)

        title = QLabel(name)
        title.setObjectName("ToolTitle")
        body = QLabel(desc)
        body.setObjectName("ToolDesc")
        body.setWordWrap(True)
        open_btn = StyledButton("Open", "info")
        open_btn.clicked.connect(lambda: self._open_tool(callback))

        layout.addWidget(title)
        layout.addWidget(body)
        layout.addStretch()
        layout.addWidget(open_btn)
        return card

    def _open_tool(self, callback):
        self.accept()
        callback()


class ReportViewerDialog(QDialog):
    """Full report viewer for teachers with commenting."""

    def __init__(self, db: DatabaseManager, report_id: int, teacher_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.report_id = report_id
        self.teacher_id = teacher_id
        self.report_service = ReportService(db)
        self.comment_service = CommentService(db)
        self._init_ui()
        self._load_data()

    def _init_ui(self):
        self.setWindowTitle("Weekly Report Viewer")
        self.setMinimumSize(800, 600)

        layout = QVBoxLayout()

        # Report header
        self.header_label = QLabel("Loading...")
        self.header_label.setStyleSheet("font-size: 16px; font-weight: bold; padding: 8px;")
        layout.addWidget(self.header_label)

        # Content tabs
        tabs = QTabWidget()

        # Report content tab
        content_tab = QWidget()
        content_layout = QVBoxLayout()

        content_layout.addWidget(QLabel("Tasks:"))
        self.task_list = QTableWidget()
        self.task_list.setColumnCount(4)
        self.task_list.setHorizontalHeaderLabels(["Category", "Task", "Status", "Progress"])
        content_layout.addWidget(self.task_list)

        content_layout.addWidget(QLabel("Problems:"))
        self.problem_list = QTableWidget()
        self.problem_list.setColumnCount(2)
        self.problem_list.setHorizontalHeaderLabels(["Problem", "Type"])
        content_layout.addWidget(self.problem_list)

        content_layout.addWidget(QLabel("Highlights:"))
        self.highlights_text = QLabel()
        self.highlights_text.setWordWrap(True)
        content_layout.addWidget(self.highlights_text)

        content_layout.addWidget(QLabel("Next Week Plans:"))
        self.plan_list = QTableWidget()
        self.plan_list.setColumnCount(2)
        self.plan_list.setHorizontalHeaderLabels(["Plan", "Category"])
        content_layout.addWidget(self.plan_list)

        content_tab.setLayout(content_layout)
        tabs.addTab(content_tab, "Report")

        # Comments tab
        comment_tab = QWidget()
        comment_layout = QVBoxLayout()

        self.comments_area = QTableWidget()
        self.comments_area.setColumnCount(3)
        self.comments_area.setHorizontalHeaderLabels(["Teacher", "Comment", "Reply"])
        comment_layout.addWidget(self.comments_area)

        comment_layout.addWidget(QLabel("Add Comment:"))
        self.comment_input = QTextEdit()
        self.comment_input.setMaximumHeight(100)
        comment_layout.addWidget(self.comment_input)

        send_btn = StyledButton("Send Comment", "primary")
        send_btn.clicked.connect(self._send_comment)
        comment_layout.addWidget(send_btn)

        comment_tab.setLayout(comment_layout)
        tabs.addTab(comment_tab, "Comments & Feedback")

        layout.addWidget(tabs)

        # Close button
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

        self.setLayout(layout)

    def _load_data(self):
        report = self.db.get_report_with_student(self.report_id)
        if not report:
            self.header_label.setText("Report not found.")
            return

        self.header_label.setText(
            f"Week {report['week_number']} - {report.get('student_name', 'N/A')} "
            f"({report['start_date']} ~ {report['end_date']})"
        )

        tasks, plans = self.report_service.get_report_tasks(self.report_id)
        self.task_list.setRowCount(0)
        ts = self.report_service.get_report_tasks(self.report_id)
        tasks = ts[0]

        for task in tasks:
            row = self.task_list.rowCount()
            self.task_list.insertRow(row)
            self.task_list.setItem(row, 0, QTableWidgetItem(task.category))
            self.task_list.setItem(row, 1, QTableWidgetItem(task.name))
            self.task_list.setItem(row, 2, QTableWidgetItem(task.status))
            self.task_list.setItem(row, 3, QTableWidgetItem(f"{task.progress}%"))

        problems = self.report_service.get_report_problems(self.report_id)
        self.problem_list.setRowCount(0)
        for p in problems:
            row = self.problem_list.rowCount()
            self.problem_list.insertRow(row)
            self.problem_list.setItem(row, 0, QTableWidgetItem(p.description))
            self.problem_list.setItem(row, 1, QTableWidgetItem(p.problem_type))

        self.highlights_text.setText(report.get("highlights", "None") or "None")

        plans = ts[1]
        self.plan_list.setRowCount(0)
        for plan in plans:
            row = self.plan_list.rowCount()
            self.plan_list.insertRow(row)
            self.plan_list.setItem(row, 0, QTableWidgetItem(plan.name))
            self.plan_list.setItem(row, 1, QTableWidgetItem(plan.category))

        # Load comments
        comments = self.comment_service.get_comments(self.report_id)
        self.comments_area.setRowCount(0)
        for c in comments:
            row = self.comments_area.rowCount()
            self.comments_area.insertRow(row)
            self.comments_area.setItem(row, 0, QTableWidgetItem(c.get("teacher_name", "Teacher")))
            self.comments_area.setItem(row, 1, QTableWidgetItem(c["content"]))
            replies = []
            if c.get("student_reply"):
                replies.append(f"Student: {c['student_reply']}")
            if c.get("teacher_reply"):
                replies.append(f"Teacher: {c['teacher_reply']}")
            self.comments_area.setItem(row, 2, QTableWidgetItem(" | ".join(replies)))

    def _send_comment(self):
        content = self.comment_input.toPlainText().strip()
        if not content:
            QMessageBox.warning(self, "Warning", "Comment cannot be empty.")
            return
        self.comment_service.add_comment(self.report_id, self.teacher_id, content)
        QMessageBox.information(self, "Success", "Comment sent.")
        self.comment_input.clear()
        self._load_data()


class SingleCommentDialog(QDialog):
    """Dialog for commenting on a single report."""

    def __init__(self, db: DatabaseManager, report_id: int, teacher_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.report_id = report_id
        self.teacher_id = teacher_id
        self.comment_service = CommentService(db)
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("Comment on Report")
        self.setMinimumWidth(500)
        layout = QVBoxLayout()

        report = self.db.get_report_with_student(self.report_id)
        if report:
            header = QLabel(f"Week {report['week_number']} - {report.get('student_name', 'N/A')}")
            header.setStyleSheet("font-weight: bold; font-size: 14px;")
            layout.addWidget(header)

        layout.addWidget(QLabel("Comment:"))
        self.comment_edit = QTextEdit()
        self.comment_edit.setPlaceholderText("Enter your feedback...")
        layout.addWidget(self.comment_edit)

        btn_layout = QHBoxLayout()
        send_btn = StyledButton("Send", "primary")
        cancel_btn = StyledButton("Cancel", "default")
        send_btn.clicked.connect(self._send)
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(send_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

        self.setLayout(layout)

    def _send(self):
        content = self.comment_edit.toPlainText().strip()
        if not content:
            QMessageBox.warning(self, "Warning", "Comment cannot be empty.")
            return
        self.comment_service.add_comment(self.report_id, self.teacher_id, content)
        QMessageBox.information(self, "Success", "Comment sent.")
        self.accept()
