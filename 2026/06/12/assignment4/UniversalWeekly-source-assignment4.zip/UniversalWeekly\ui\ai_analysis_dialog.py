"""AI-style report analysis center using local heuristics."""

from __future__ import annotations

from PyQt6.QtWidgets import QDialog, QFrame, QHBoxLayout, QLabel, QTextEdit, QVBoxLayout

from business.report_service import ReportService
from database.db_manager import DatabaseManager
from ui.common_widgets import StyledButton


class AIAnalysisDialog(QDialog):
    """Analyze a weekly report and show completeness, clarity, risk, and suggestions."""

    def __init__(self, db: DatabaseManager, report_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.report_id = report_id
        self.report_service = ReportService(db)
        self._init_ui()
        self._load_analysis()

    def _init_ui(self):
        self.setWindowTitle("AI Analysis Center")
        self.setMinimumSize(820, 580)
        self.setStyleSheet("QDialog { background: #F8FAFC; } QLabel { border: none; }")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)

        title = QLabel("AI Analysis Center")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #0F172A;")
        subtitle = QLabel("Analyze report completeness, clarity, risk level, and revision suggestions.")
        subtitle.setStyleSheet("color: #64748B;")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        metrics = QHBoxLayout()
        self.completeness_value = self._metric(metrics, "Completeness", "0%", "#2563EB")
        self.clarity_value = self._metric(metrics, "Clarity", "0%", "#16A34A")
        self.risk_value = self._metric(metrics, "Risk Level", "Low", "#F97316")
        layout.addLayout(metrics)

        self.result_edit = QTextEdit()
        self.result_edit.setReadOnly(True)
        self.result_edit.setStyleSheet("""
            QTextEdit {
                background: #FFFFFF;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
                padding: 12px;
                color: #0F172A;
            }
        """)
        layout.addWidget(self.result_edit, 1)

        close_btn = StyledButton("Close", "primary")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _metric(self, parent: QHBoxLayout, title: str, value: str, color: str) -> QLabel:
        card = QFrame()
        card.setObjectName("MetricCard")
        card.setStyleSheet("""
            QFrame#MetricCard {
                background: #FFFFFF;
                border: 1px solid #EEF2F7;
                border-radius: 14px;
            }
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 14, 18, 14)
        title_label = QLabel(title)
        title_label.setStyleSheet("color: #64748B; font-size: 12px; font-weight: bold;")
        value_label = QLabel(value)
        value_label.setStyleSheet(f"color: {color}; font-size: 30px; font-weight: bold;")
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        parent.addWidget(card, 1)
        return value_label

    def _load_analysis(self):
        report = self.db.get_report(self.report_id)
        if not report:
            self.result_edit.setPlainText("Report not found.")
            return

        tasks, plans = self.report_service.get_report_tasks(self.report_id)
        problems = self.report_service.get_report_problems(self.report_id)
        comments = self.db.get_comments_by_report(self.report_id)

        sections = {
            "Core work content": bool(tasks or (report.highlights or "").strip()),
            "Completed tasks and results": bool(any(t.progress > 0 or t.status == "completed" for t in tasks) or (report.highlights or "").strip()),
            "Problems and solutions": bool(problems or (report.shortcomings or "").strip() or (report.improvements or "").strip()),
            "Next-week plan": bool(plans or (report.next_plan_summary or "").strip()),
        }
        completeness = sum(25 for ready in sections.values() if ready)
        text_length = sum(len(text or "") for text in [
            report.highlights,
            report.shortcomings,
            report.improvements,
            report.next_plan_summary,
        ])
        clarity = min(100, max(35, round(text_length / 8) + len(tasks) * 8 + len(plans) * 6))
        risk_score = 0
        if completeness < 75:
            risk_score += 2
        if not plans:
            risk_score += 1
        if any(t.progress < 50 for t in tasks):
            risk_score += 1
        if report.status == "rejected":
            risk_score += 2
        risk = "High" if risk_score >= 4 else "Medium" if risk_score >= 2 else "Low"

        self.completeness_value.setText(f"{completeness}%")
        self.clarity_value.setText(f"{clarity}%")
        self.risk_value.setText(risk)

        suggestions = []
        for name, ready in sections.items():
            if not ready:
                suggestions.append(f"Add content for: {name}.")
        if text_length < 240:
            suggestions.append("Add more process details and measurable outcomes.")
        if problems and not (report.improvements or "").strip():
            suggestions.append("Add concrete improvement measures for the recorded problems.")
        if comments:
            suggestions.append("Review teacher feedback and update the report before exporting.")
        if not suggestions:
            suggestions.append("The report structure is complete. Consider polishing language before final submission.")

        section_lines = "\n".join(f"{'✓' if ready else '○'} {name}" for name, ready in sections.items())
        suggestion_lines = "\n".join(f"{index + 1}. {item}" for index, item in enumerate(suggestions))

        self.result_edit.setPlainText(
            f"""Week {report.week_number} AI Review Result

Section Status
{section_lines}

Suggestions
{suggestion_lines}

Teacher Feedback Count: {len(comments)}
Task Count: {len(tasks)}
Next Plan Count: {len(plans)}
Problem Count: {len(problems)}
"""
        )
