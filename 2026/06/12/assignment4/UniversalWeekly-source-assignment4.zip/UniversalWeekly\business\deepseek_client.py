"""DeepSeek API client for the embedded AI weekly-report assistant."""

from __future__ import annotations

from typing import Any

import requests

from config import (
    DEEPSEEK_API_KEY,
    DEEPSEEK_BASE_URL,
    DEEPSEEK_MODEL,
    DEEPSEEK_TIMEOUT_SECONDS,
)


class DeepSeekClient:
    """OpenAI-compatible DeepSeek chat client."""

    def __init__(
        self,
        api_key: str = DEEPSEEK_API_KEY,
        model: str = DEEPSEEK_MODEL,
        base_url: str = DEEPSEEK_BASE_URL,
    ):
        self.api_key = (api_key or "").strip()
        self.model = (model or "deepseek-v4-flash").strip()
        self.base_url = (base_url or DEEPSEEK_BASE_URL).strip()

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key)

    def chat(
        self,
        user_message: str,
        history: list[dict[str, str]] | None = None,
        report_context: str = "",
    ) -> str:
        """Send a chat request and return the assistant response text."""
        if not self.is_configured:
            return (
                "DeepSeek API key is not configured. Please set DEEPSEEK_API_KEY "
                "in config.py or as an environment variable, then restart the app."
            )

        user_message = (user_message or "").strip()
        if not user_message:
            return "Please enter a message first."

        messages: list[dict[str, str]] = [
            {
                "role": "system",
                "content": (
                    "You are the embedded AI Weekly Report Assistant in UniversalWeekly. "
                    "Help students generate, polish, check, and revise weekly reports. "
                    "Use a clear, formal, practical style. The default weekly-report "
                    "structure is: 1) Core work this week; 2) Completed tasks and results; "
                    "3) Problems, reflection, and attempted solutions; 4) Next-week plan. "
                    "If the user writes in Chinese, answer in Chinese. If the user writes "
                    "in English, answer in English unless asked otherwise."
                ),
            }
        ]

        if report_context.strip():
            messages.append(
                {
                    "role": "system",
                    "content": (
                        "Current selected report context. Use it only when relevant:\n"
                        + report_context.strip()
                    ),
                }
            )

        messages.extend(history or [])
        messages.append({"role": "user", "content": user_message})

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "temperature": 0.7,
        }

        try:
            response = requests.post(
                self.base_url,
                headers=headers,
                json=payload,
                timeout=DEEPSEEK_TIMEOUT_SECONDS,
            )
            if response.status_code != 200:
                return f"API request failed: {response.status_code}\n{response.text}"

            data = response.json()
            return data["choices"][0]["message"]["content"].strip()
        except requests.exceptions.Timeout:
            return "Request timed out. Please check the network or try again later."
        except requests.exceptions.RequestException as exc:
            return f"Network request error: {exc}"
        except Exception as exc:
            return f"Program error: {exc}"
