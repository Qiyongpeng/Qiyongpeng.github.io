"""Weather forecast and time/date utility service."""

from __future__ import annotations

import json
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta
from typing import Any


WEATHER_CODES = {
    0: "Clear sky",
    1: "Mainly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Depositing rime fog",
    51: "Light drizzle",
    53: "Moderate drizzle",
    55: "Dense drizzle",
    56: "Light freezing drizzle",
    57: "Dense freezing drizzle",
    61: "Slight rain",
    63: "Moderate rain",
    65: "Heavy rain",
    66: "Light freezing rain",
    67: "Heavy freezing rain",
    71: "Slight snow",
    73: "Moderate snow",
    75: "Heavy snow",
    77: "Snow grains",
    80: "Slight rain showers",
    81: "Moderate rain showers",
    82: "Violent rain showers",
    85: "Slight snow showers",
    86: "Heavy snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with slight hail",
    99: "Thunderstorm with heavy hail",
}


class WeatherTimeService:
    """Fetch weather forecasts and provide time/date calculations."""

    GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
    FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

    @staticmethod
    def current_time_info(now: datetime | None = None) -> dict[str, str | int]:
        now = now or datetime.now()
        iso = now.isocalendar()
        return {
            "date": now.strftime("%Y-%m-%d"),
            "time": now.strftime("%H:%M:%S"),
            "weekday": now.strftime("%A"),
            "month": now.strftime("%B"),
            "iso_week": iso.week,
            "day_of_year": int(now.strftime("%j")),
            "timestamp": now.strftime("%Y-%m-%d %H:%M:%S"),
        }

    @staticmethod
    def days_between(start: date, end: date) -> int:
        return (end - start).days

    @staticmethod
    def add_days(start: date, days: int) -> date:
        return start + timedelta(days=days)

    @classmethod
    def fetch_weather(cls, city: str) -> tuple[bool, dict[str, Any] | str]:
        city = city.strip()
        if not city:
            return False, "Please enter a city name."
        try:
            location = cls._geocode_city(city)
            forecast = cls._fetch_forecast(location["latitude"], location["longitude"])
            return True, cls._normalize_weather(location, forecast)
        except Exception as open_meteo_exc:
            try:
                return True, cls._fetch_wttr(city)
            except Exception as wttr_exc:
                return False, (
                    "Weather forecast unavailable.\n"
                    f"Open-Meteo error: {open_meteo_exc}\n"
                    f"Backup weather source error: {wttr_exc}"
                )

    @classmethod
    def _geocode_city(cls, city: str) -> dict[str, Any]:
        params = urllib.parse.urlencode({
            "name": city,
            "count": 1,
            "language": "en",
            "format": "json",
        })
        data = cls._get_json(f"{cls.GEOCODE_URL}?{params}")
        results = data.get("results") or []
        if not results:
            raise ValueError(f"No location found for '{city}'.")
        first = results[0]
        return {
            "name": first.get("name", city),
            "country": first.get("country", ""),
            "admin1": first.get("admin1", ""),
            "latitude": first["latitude"],
            "longitude": first["longitude"],
            "timezone": first.get("timezone", "auto"),
        }

    @classmethod
    def _fetch_forecast(cls, latitude: float, longitude: float) -> dict[str, Any]:
        params = urllib.parse.urlencode({
            "latitude": latitude,
            "longitude": longitude,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
            "forecast_days": 7,
            "timezone": "auto",
        })
        return cls._get_json(f"{cls.FORECAST_URL}?{params}")

    @staticmethod
    def _get_json(url: str) -> dict[str, Any]:
        try:
            import requests

            response = requests.get(url, headers={"User-Agent": "UniversalWeekly/1.0"}, timeout=10)
            response.raise_for_status()
            return response.json()
        except ImportError:
            request = urllib.request.Request(url, headers={"User-Agent": "UniversalWeekly/1.0"})
            with urllib.request.urlopen(request, timeout=10) as response:
                return json.loads(response.read().decode("utf-8"))

    @classmethod
    def _normalize_weather(cls, location: dict[str, Any], forecast: dict[str, Any]) -> dict[str, Any]:
        current = forecast.get("current", {})
        daily = forecast.get("daily", {})
        code = int(current.get("weather_code", -1))
        days = []
        dates = daily.get("time", [])
        for index, day in enumerate(dates):
            day_code = int((daily.get("weather_code") or [None])[index])
            days.append({
                "date": day,
                "weather": WEATHER_CODES.get(day_code, f"Weather code {day_code}"),
                "temp_min": (daily.get("temperature_2m_min") or [""])[index],
                "temp_max": (daily.get("temperature_2m_max") or [""])[index],
                "precipitation": (daily.get("precipitation_probability_max") or [""])[index],
            })
        return {
            "location": location,
            "timezone": forecast.get("timezone", location.get("timezone", "")),
            "current": {
                "time": current.get("time", ""),
                "temperature": current.get("temperature_2m", ""),
                "apparent_temperature": current.get("apparent_temperature", ""),
                "humidity": current.get("relative_humidity_2m", ""),
                "wind_speed": current.get("wind_speed_10m", ""),
                "weather": WEATHER_CODES.get(code, f"Weather code {code}"),
            },
            "daily": days,
        }

    @classmethod
    def _fetch_wttr(cls, city: str) -> dict[str, Any]:
        url = f"https://wttr.in/{urllib.parse.quote(city)}?format=j1"
        data = cls._get_json(url)
        current_raw = (data.get("current_condition") or [{}])[0]
        nearest = (data.get("nearest_area") or [{}])[0]
        area = (nearest.get("areaName") or [{"value": city}])[0].get("value", city)
        country = (nearest.get("country") or [{"value": ""}])[0].get("value", "")
        region = (nearest.get("region") or [{"value": ""}])[0].get("value", "")
        weather_desc = (current_raw.get("weatherDesc") or [{"value": "Unknown"}])[0].get("value", "Unknown")
        days = []
        for item in (data.get("weather") or [])[:7]:
            hourly = item.get("hourly") or []
            rain_values = [int(h.get("chanceofrain", 0) or 0) for h in hourly]
            days.append({
                "date": item.get("date", ""),
                "weather": (hourly[4].get("weatherDesc") or [{"value": weather_desc}])[0].get("value", weather_desc) if len(hourly) > 4 else weather_desc,
                "temp_min": item.get("mintempC", ""),
                "temp_max": item.get("maxtempC", ""),
                "precipitation": max(rain_values) if rain_values else "",
            })
        return {
            "location": {
                "name": area,
                "country": country,
                "admin1": region,
                "latitude": "",
                "longitude": "",
                "timezone": "auto",
            },
            "timezone": "auto",
            "current": {
                "time": current_raw.get("localObsDateTime", ""),
                "temperature": current_raw.get("temp_C", ""),
                "apparent_temperature": current_raw.get("FeelsLikeC", ""),
                "humidity": current_raw.get("humidity", ""),
                "wind_speed": current_raw.get("windspeedKmph", ""),
                "weather": weather_desc,
            },
            "daily": days,
        }
