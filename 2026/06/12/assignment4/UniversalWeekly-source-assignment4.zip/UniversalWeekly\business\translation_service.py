"""Academic translation service powered by local LLMs."""

from __future__ import annotations

import re

from business.local_llm_service import LocalLLMService


LANGUAGE_MAP = {
    "Auto": "auto",
    "English": "english",
    "Chinese (Simplified)": "chinese (simplified)",
    "Chinese (Traditional)": "chinese (traditional)",
    "Japanese": "japanese",
    "Korean": "korean",
    "French": "french",
    "German": "german",
    "Spanish": "spanish",
}

ENGINE_OPTIONS = [
    "Local LLM (Ollama)",
    "Local LLM (OpenAI-compatible)",
    "Offline Academic Fallback",
]


ACADEMIC_GLOSSARY_EN_ZH = {
    "accuracy": "准确率",
    "adaptive": "自适应",
    "algorithm": "算法",
    "architecture": "架构",
    "bearing": "轴承",
    "bearings": "轴承",
    "bearing fault diagnosis": "轴承故障诊断",
    "classification": "分类",
    "classification accuracy": "分类准确率",
    "condition monitoring": "状态监测",
    "data augmentation": "数据增强",
    "data-driven": "数据驱动",
    "deep learning": "深度学习",
    "diagnosis": "诊断",
    "digital twin": "数字孪生",
    "digital twin-driven": "数字孪生驱动",
    "domain adaptation": "域自适应",
    "domain gap": "域差异",
    "domain shift": "域偏移",
    "experimental results": "实验结果",
    "existing": "现有的",
    "existing methods": "现有方法",
    "explainable ai": "可解释人工智能",
    "fault diagnosis": "故障诊断",
    "feature extraction": "特征提取",
    "framework": "框架",
    "health management": "健康管理",
    "intelligent diagnosis": "智能诊断",
    "literature review": "文献综述",
    "machine learning": "机器学习",
    "method": "方法",
    "methods": "方法",
    "model": "模型",
    "proposed": "所提出的",
    "proposed framework": "所提出的框架",
    "proposed method": "所提出的方法",
    "predictive maintenance": "预测性维护",
    "remaining useful life": "剩余使用寿命",
    "research gap": "研究空白",
    "robustness": "鲁棒性",
    "rolling bearing": "滚动轴承",
    "rolling bearings": "滚动轴承",
    "rotating machinery": "旋转机械",
    "signal processing": "信号处理",
    "simulation": "仿真",
    "transfer learning": "迁移学习",
    "variable working conditions": "变工况",
    "under variable working conditions": "在变工况下",
    "virtual data": "虚拟数据",
}

ACADEMIC_GLOSSARY_ZH_EN = {value: key for key, value in ACADEMIC_GLOSSARY_EN_ZH.items()}
ACADEMIC_GLOSSARY_ZH_EN.update({
    "方法": "method",
    "轴承": "bearing",
    "框架": "framework",
    "现有方法": "existing methods",
    "所提出的": "proposed",
})


class TranslationService:
    """Translate academic words, phrases, and literature paragraphs."""

    MAX_CHARS = 4200

    @classmethod
    def translate(
        cls,
        text: str,
        source_label: str = "Auto",
        target_label: str = "Chinese (Simplified)",
        mode: str = "Literature Translation",
        engine_label: str = "Local LLM (Ollama)",
        endpoint: str = "",
        model: str = "",
    ) -> tuple[bool, str, str]:
        clean = text.strip()
        if not clean:
            return False, "Please enter text to translate.", "none"

        source = LANGUAGE_MAP.get(source_label, "auto")
        target = LANGUAGE_MAP.get(target_label, "chinese (simplified)")
        if target == "auto":
            target = "chinese (simplified)"

        if engine_label == "Offline Academic Fallback":
            return True, cls._offline_translate(clean, source, target, mode), engine_label

        if engine_label in {"Local LLM (Ollama)", "Local LLM (OpenAI-compatible)"}:
            try:
                translated = cls._local_llm_translate(clean, source, target, mode, engine_label, endpoint, model)
                return True, translated, cls._engine_label(engine_label, model)
            except Exception as exc:
                fallback = cls._offline_translate(clean, source, target, mode)
                return True, fallback + f"\n\nNote: Local LLM translation failed, so offline academic fallback was used.\nReason: {exc}", "offline fallback"

        return True, cls._offline_translate(clean, source, target, mode), "offline academic"

    @classmethod
    def _local_llm_translate(
        cls,
        text: str,
        source: str,
        target: str,
        mode: str,
        engine_label: str,
        endpoint: str,
        model: str,
    ) -> str:
        provider = "Ollama" if engine_label == "Local LLM (Ollama)" else "OpenAI-compatible"
        translated_chunks = []
        for chunk in cls._chunk_text(text):
            prompt = cls._build_llm_prompt(chunk, source, target, mode)
            if provider == "Ollama":
                translated = LocalLLMService._call_ollama(
                    endpoint or LocalLLMService.DEFAULT_OLLAMA_URL,
                    model or LocalLLMService.DEFAULT_MODEL,
                    prompt,
                )
            else:
                translated = LocalLLMService._call_openai_compatible(
                    endpoint or LocalLLMService.DEFAULT_OPENAI_COMPAT_URL,
                    model or "local-model",
                    prompt,
                )
            translated_chunks.append(cls._clean_llm_translation(translated))
        return "\n\n".join(part for part in translated_chunks if part.strip())

    @staticmethod
    def _engine_label(engine_label: str, model: str) -> str:
        if engine_label == "Local LLM (Ollama)":
            return f"Ollama / {model or LocalLLMService.DEFAULT_MODEL}"
        return f"OpenAI-compatible / {model or 'local-model'}"

    @classmethod
    def _build_llm_prompt(cls, text: str, source: str, target: str, mode: str) -> str:
        source_text = "auto-detected language" if source == "auto" else source
        if mode == "Word / Phrase Translation":
            instruction = (
                "Translate the term or phrase accurately. If it is an academic or technical term, "
                "prefer the standard academic wording. Return only the translation and a very short usage note if useful."
            )
        else:
            instruction = (
                "Translate the literature excerpt accurately and fluently. Preserve paragraph breaks, academic tone, "
                "technical terms, logical connectors, numbers, citations, and abbreviations. Do not add explanations."
            )
        return f"""
You are an academic translation engine running locally.

Task: {instruction}
Source language: {source_text}
Target language: {target}

Rules:
1. Return only the translated text.
2. Do not summarize, explain, or answer the content.
3. Do not add Markdown fences.
4. Keep terminology consistent. For papers about digital twin, bearings, PHM, machine learning, and fault diagnosis, use precise academic terms.

Text to translate:
{text}
""".strip()

    @staticmethod
    def _clean_llm_translation(text: str) -> str:
        text = (text or "").strip()
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        prefixes = [
            "Translation:",
            "Translated text:",
            "译文：",
            "翻译：",
        ]
        for prefix in prefixes:
            if text.startswith(prefix):
                text = text[len(prefix):].strip()
        return text

    @classmethod
    def _offline_translate(cls, text: str, source: str, target: str, mode: str) -> str:
        target_is_chinese = target.startswith("chinese")
        target_is_english = target == "english"
        source_is_chinese = cls._contains_chinese(text)

        if mode == "Word / Phrase Translation":
            exact = cls._exact_term_lookup(text, target)
            if exact:
                return exact
            converted = cls._replace_terms(text, target)
            if converted != text:
                return converted
            return cls._unknown_term_message(text, target)

        if target_is_chinese and not source_is_chinese:
            return cls._translate_literature_en_to_zh(text)
        if target_is_english and source_is_chinese:
            return cls._translate_literature_zh_to_en(text)

        converted = cls._replace_terms(text, target)
        if converted != text:
            return converted
        return (
            "Offline academic translation currently focuses on English-Chinese literature translation. "
            "Please choose a Local LLM engine for this language pair."
        )

    @classmethod
    def _translate_literature_en_to_zh(cls, text: str) -> str:
        paragraphs = re.split(r"\n\s*\n", text)
        translated_paragraphs = []
        for paragraph in paragraphs:
            sentences = cls._split_sentences(paragraph)
            translated_sentences = [cls._translate_sentence_en_to_zh(sentence) for sentence in sentences]
            translated_paragraphs.append("".join(translated_sentences))
        return "\n\n".join(p for p in translated_paragraphs if p.strip())

    @classmethod
    def _translate_sentence_en_to_zh(cls, sentence: str) -> str:
        original = sentence.strip()
        if not original:
            return ""
        lower = original.lower().strip(" .!?。！？")
        lower = re.sub(r"\s+", " ", lower)

        patterns = [
            (r"^this paper proposes (.+)$", "本文提出了{}。"),
            (r"^this study proposes (.+)$", "本研究提出了{}。"),
            (r"^this paper presents (.+)$", "本文介绍了{}。"),
            (r"^this study investigates (.+)$", "本研究探讨了{}。"),
            (r"^the proposed (method|framework|model) (.+)$", "所提出的{}{}。"),
            (r"^experimental results show that (.+)$", "实验结果表明，{}。"),
            (r"^the results show that (.+)$", "结果表明，{}。"),
            (r"^however, (.+)$", "然而，{}。"),
            (r"^therefore, (.+)$", "因此，{}。"),
            (r"^in conclusion, (.+)$", "综上，{}。"),
            (r"^existing (.+)$", "现有{}。"),
            (r"^compared with (.+)$", "与{}相比。"),
        ]
        for pattern, template in patterns:
            match = re.match(pattern, lower, flags=re.I)
            if match:
                groups = [cls._en_phrase_to_zh(g) for g in match.groups()]
                return template.format(*groups)

        converted = cls._en_phrase_to_zh(lower)
        return f"{converted}。"

    @classmethod
    def _translate_literature_zh_to_en(cls, text: str) -> str:
        paragraphs = re.split(r"\n\s*\n", text)
        translated_paragraphs = []
        for paragraph in paragraphs:
            sentences = cls._split_sentences(paragraph)
            translated = [cls._translate_sentence_zh_to_en(sentence) for sentence in sentences]
            translated_paragraphs.append(" ".join(s for s in translated if s.strip()))
        return "\n\n".join(p for p in translated_paragraphs if p.strip())

    @classmethod
    def _translate_sentence_zh_to_en(cls, sentence: str) -> str:
        clean = sentence.strip("。！？ \n\t")
        if not clean:
            return ""
        replacements = [
            ("本文提出了", "This paper proposes "),
            ("本研究提出了", "This study proposes "),
            ("实验结果表明", "Experimental results show that "),
            ("结果表明", "The results show that "),
            ("然而", "However, "),
            ("因此", "Therefore, "),
            ("现有", "Existing "),
        ]
        converted = clean
        for source, target in replacements:
            converted = converted.replace(source, target)
        converted = converted.replace("提高了", " improves ")
        converted = converted.replace("提高", " improves ")
        converted = converted.replace("该", " the ")
        converted = converted.replace("的", " ")
        converted = cls._replace_terms(converted, "english")
        converted = converted.replace("。", "").replace("，", ",")
        converted = re.sub(r"\s+", " ", converted).strip()
        if not converted.endswith("."):
            converted += "."
        return converted

    @classmethod
    def _en_phrase_to_zh(cls, phrase: str) -> str:
        phrase = re.sub(r"\b(a|an|the)\b\s*", "", phrase, flags=re.I)
        converted = cls._replace_terms(phrase, "chinese (simplified)")
        replacements = {
            "still suffer from": "仍然面临",
            "suffer from": "面临",
            "proposes": "提出",
            "propose": "提出",
            "improves": "提高",
            "improve": "提高",
            "shows": "表明",
            "show": "表明",
            "under": "在",
            "for": "用于",
            "with": "结合",
            "and": "和",
            "of": "的",
        }
        for source, target in replacements.items():
            converted = re.sub(rf"\b{re.escape(source)}\b", target, converted, flags=re.I)
        converted = converted.replace("still suffer from", "仍然面临")
        converted = converted.replace("suffer from", "面临")
        return cls._tidy_mixed_text(converted)

    @classmethod
    def _exact_term_lookup(cls, text: str, target: str) -> str:
        key = text.strip().lower()
        if target.startswith("chinese"):
            return ACADEMIC_GLOSSARY_EN_ZH.get(key, "")
        if target == "english":
            return ACADEMIC_GLOSSARY_ZH_EN.get(text.strip(), "")
        return ""

    @classmethod
    def _replace_terms(cls, text: str, target: str) -> str:
        glossary = ACADEMIC_GLOSSARY_EN_ZH if target.startswith("chinese") else ACADEMIC_GLOSSARY_ZH_EN
        result = text
        for source, value in sorted(glossary.items(), key=lambda item: len(item[0]), reverse=True):
            replacement = f" {value} " if target == "english" else value
            result = re.sub(re.escape(source), replacement, result, flags=re.I)
        return re.sub(r"\s+", " ", result).strip()

    @staticmethod
    def _unknown_term_message(text: str, target: str) -> str:
        if target.startswith("chinese"):
            return f"No exact glossary match found for: {text}\nYou can still use a Local LLM engine for a general translation."
        if target == "english":
            return f"No exact glossary match found for: {text}\nYou can still use a Local LLM engine for a general translation."
        return "Offline glossary mode currently supports English-Chinese academic terms."

    @staticmethod
    def _split_sentences(text: str) -> list[str]:
        stripped = text.strip()
        if re.search(r"[。！？]", stripped):
            return [s.strip() for s in re.findall(r"[^。！？.!?]+[。！？.!?]?", stripped) if s.strip()]
        return [s.strip() for s in re.split(r"(?<=[.!?])\s+", stripped) if s.strip()]

    @staticmethod
    def _contains_chinese(text: str) -> bool:
        return bool(re.search(r"[\u4e00-\u9fff]", text))

    @classmethod
    def _chunk_text(cls, text: str) -> list[str]:
        paragraphs = re.split(r"\n\s*\n", text)
        chunks: list[str] = []
        current = ""
        for paragraph in paragraphs:
            paragraph = paragraph.strip()
            if not paragraph:
                continue
            if current and len(current) + len(paragraph) + 2 > cls.MAX_CHARS:
                chunks.append(current)
                current = paragraph
            else:
                current = f"{current}\n\n{paragraph}" if current else paragraph
        if current:
            chunks.append(current)
        return chunks or [text]

    @staticmethod
    def _tidy_mixed_text(text: str) -> str:
        text = re.sub(r"\s+", " ", text).strip()
        text = text.strip(" .")
        text = re.sub(r"(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])", "", text)
        text = re.sub(r"(?<=[\u4e00-\u9fff])\s+(?=[A-Za-z])", "", text)
        text = re.sub(r"(?<=[A-Za-z])\s+(?=[\u4e00-\u9fff])", "", text)
        text = text.replace(" ，", "，").replace(" 。", "。")
        text = text.replace(" ,", ",").replace(" .", ".")
        text = text.replace("。。", "。")
        return text
