"""Statistics visualization widget using Matplotlib."""

from datetime import datetime
from typing import Dict

import matplotlib

matplotlib.use("QtAgg")
matplotlib.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.ticker import MaxNLocator
from PyQt6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QProgressBar,
    QTableWidget, QTableWidgetItem, QHeaderView, QVBoxLayout, QWidget
)
from PyQt6.QtCore import Qt

from business.statistics_service import StatisticsService
from business.template_service import TemplateService
from database.db_manager import DatabaseManager
from ui.common_widgets import SectionLabel, StatusBadge, StyledButton

class StatisticsWidget(QWidget):
    """Statistics and charts panel for teachers and students."""

    def __init__(self, db: DatabaseManager, is_teacher: bool = False):
        super().__init__()
        self.db = db
        self.is_teacher = is_teacher
        self.stats_service = StatisticsService(db)
        self.template_service = TemplateService(db)
        self._card_values: Dict[str, QLabel] = {}
        self._card_subtitles: Dict[str, QLabel] = {}
        self._student_summary_values: Dict[str, QLabel] = {}
        self._student_user_id = None
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(16)

        if self.is_teacher:
            layout.addWidget(SectionLabel("Class Statistics"))
            self._build_teacher_stats(layout)
        else:
            title = QLabel("Weekly Analytics")
            title.setStyleSheet("font-size: 20px; font-weight: bold; color: #0F172A;")
            subtitle = QLabel("Track your weekly report submission, progress and feedback status.")
            subtitle.setStyleSheet("font-size: 13px; color: #64748B;")
            layout.addWidget(title)
            layout.addWidget(subtitle)
            self._build_student_stats(layout)

        self.setLayout(layout)

    def _build_teacher_stats(self, layout: QVBoxLayout):
        controls = QHBoxLayout()
        controls.setSpacing(10)
        controls.addWidget(QLabel("Class:"))
        self.class_combo = QComboBox()
        self.class_combo.setMinimumWidth(170)
        classes = self.db.get_all_classes()
        self.class_combo.addItems(classes if classes else ["No classes"])
        controls.addWidget(self.class_combo)

        controls.addWidget(QLabel("Week:"))
        self.week_combo = QComboBox()
        self.week_combo.addItems([str(w) for w in range(1, 54)])
        from datetime import datetime

        self.week_combo.setCurrentText(str(datetime.now().isocalendar()[1]))
        controls.addWidget(self.week_combo)

        refresh_btn = StyledButton("Refresh", "primary")
        refresh_btn.clicked.connect(self._refresh_teacher_stats)
        controls.addWidget(refresh_btn)
        controls.addStretch()
        layout.addLayout(controls)

        cards = QHBoxLayout()
        cards.setSpacing(14)
        self.submission_card = self._make_card("Submission Rate", "0%", "#3498DB", "0/0 submitted")
        self.avg_progress_card = self._make_card("Avg Progress", "0%", "#27AE60", "Average task completion")
        self.delayed_card = self._make_card("Delayed Tasks", "0", "#E74C3C", "tasks")
        cards.addWidget(self.submission_card, 1)
        cards.addWidget(self.avg_progress_card, 1)
        cards.addWidget(self.delayed_card, 1)
        layout.addLayout(cards)

        chart_layout = QHBoxLayout()
        chart_layout.setSpacing(14)

        sub_chart = self._make_chart_frame()
        sub_layout = QVBoxLayout(sub_chart)
        sub_layout.addWidget(self._chart_title("Submission Status"))
        self.submission_figure = Figure(figsize=(4.4, 3.2))
        self.submission_canvas = FigureCanvas(self.submission_figure)
        sub_layout.addWidget(self.submission_canvas)
        chart_layout.addWidget(sub_chart, 1)

        problem_chart = self._make_chart_frame()
        problem_layout = QVBoxLayout(problem_chart)
        problem_layout.addWidget(self._chart_title("Problem Distribution"))
        self.problem_figure = Figure(figsize=(5.8, 3.2), dpi=100)
        self.problem_canvas = FigureCanvas(self.problem_figure)
        problem_layout.addWidget(self.problem_canvas)
        chart_layout.addWidget(problem_chart, 1)

        layout.addLayout(chart_layout)

        flagged_title = QLabel("Flagged Students (Low Progress)")
        flagged_title.setStyleSheet("font-weight: bold; color: #2C3E50; margin-top: 4px;")
        layout.addWidget(flagged_title)
        self.flagged_label = QLabel("No flagged students.")
        self.flagged_label.setWordWrap(True)
        self._set_flagged_style("neutral")
        layout.addWidget(self.flagged_label)

        self._refresh_teacher_stats()

    def _wrap_axis_label(self, text: str, max_len: int = 18) -> str:
        """Wrap long chart labels so left axis text is not clipped."""
        if len(text) <= max_len:
            return text

        words = text.split()
        lines = []
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip()
            if len(candidate) <= max_len:
                current = candidate
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return "\n".join(lines)

    def _build_student_stats(self, layout: QVBoxLayout, user_id: int = None):
        self._student_user_id = user_id

        summary_cards = QHBoxLayout()
        summary_cards.setSpacing(16)
        self.total_reports_card = self._make_student_summary_card(
            "Total Reports", "0", "#2563EB", "reports created"
        )
        self.submission_summary_card = self._make_student_summary_card(
            "Submission Rate", "0%", "#2563EB", "Submitted: 0 / 0"
        )
        self.overall_progress_card = self._make_student_summary_card(
            "Avg Progress", "0%", "#16A34A", "Average of all weekly reports"
        )
        self.unread_feedback_card = self._make_student_summary_card(
            "Unread Feedback", "0", "#EF4444", "comments waiting"
        )
        summary_cards.addWidget(self.total_reports_card, 1)
        summary_cards.addWidget(self.submission_summary_card, 1)
        summary_cards.addWidget(self.overall_progress_card, 1)
        summary_cards.addWidget(self.unread_feedback_card, 1)
        layout.addLayout(summary_cards)

        bottom_layout = QHBoxLayout()
        bottom_layout.setSpacing(16)

        status_card = self._make_chart_frame()
        status_layout = QVBoxLayout(status_card)
        status_layout.setContentsMargins(18, 16, 18, 16)
        status_layout.addWidget(self._chart_title("Status Distribution"))
        self.status_figure = Figure(figsize=(4.8, 3.1))
        self.status_canvas = FigureCanvas(self.status_figure)
        status_layout.addWidget(self.status_canvas)
        bottom_layout.addWidget(status_card, 1)

        self.progress_overview_card = self._make_progress_overview_card()
        bottom_layout.addWidget(self.progress_overview_card, 1)
        layout.addLayout(bottom_layout)

        summary_card = self._make_chart_frame()
        summary_layout = QVBoxLayout(summary_card)
        summary_layout.setContentsMargins(18, 16, 18, 16)
        summary_layout.addWidget(self._chart_title("Recent Report Summary"))
        self.recent_table = QTableWidget()
        self.recent_table.setColumnCount(5)
        self.recent_table.setHorizontalHeaderLabels(["Week", "Status", "Progress", "Feedback", "Last Updated"])
        self.recent_table.verticalHeader().setVisible(False)
        self.recent_table.horizontalHeader().setStretchLastSection(True)
        self.recent_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.recent_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.recent_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.recent_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.recent_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.recent_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.recent_table.setAlternatingRowColors(True)
        self.recent_table.setStyleSheet(self._table_style())
        summary_layout.addWidget(self.recent_table)
        layout.addWidget(summary_card, 1)

    def load_student_data(self, user_id: int):
        self._student_user_id = user_id
        self._refresh_student_charts()

    def _make_card(self, title: str, value: str, color: str, subtitle: str = "") -> QFrame:
        card = QFrame()
        card.setObjectName("KpiCard")
        card.setMinimumHeight(132)
        card.setMinimumWidth(190)
        card.setStyleSheet(
            f"""
            QFrame#KpiCard {{
                background: white;
                border: 1px solid #EEF2F7;
                border-radius: 14px;
            }}
            """
        )

        card_layout = QVBoxLayout()
        card_layout.setContentsMargins(20, 18, 20, 16)
        card_layout.setSpacing(8)

        icon_map = {
            "Total Reports": "📄",
            "Submission Rate": "✓",
            "Avg Progress": "📊",
            "Unread Feedback": "💬",
            "Submitted": "✓",
            "Delayed Tasks": "!",
        }
        icon_bg_map = {
            "Total Reports": "#EFF6FF",
            "Submission Rate": "#EFF6FF",
            "Avg Progress": "#ECFDF5",
            "Unread Feedback": "#FFF7ED",
            "Submitted": "#ECFDF5",
            "Delayed Tasks": "#FEF2F2",
        }
        title_row = QHBoxLayout()
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet("color: #64748B; font-size: 12px; font-weight: bold; border: none;")
        icon_lbl = QLabel(icon_map.get(title, "•"))
        icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_lbl.setFixedSize(30, 30)
        icon_lbl.setStyleSheet(f"""
            QLabel {{
                color: {color};
                background: {icon_bg_map.get(title, "#F8FAFC")};
                border: none;
                border-radius: 15px;
                font-size: 15px;
                font-weight: bold;
            }}
        """)
        title_row.addWidget(title_lbl)
        title_row.addStretch()
        title_row.addWidget(icon_lbl)

        value_lbl = QLabel(value)
        value_lbl.setStyleSheet(f"color: {color}; font-size: 34px; font-weight: bold; border: none;")
        subtitle_lbl = QLabel(subtitle)
        subtitle_lbl.setStyleSheet("color: #94A3B8; font-size: 12px; border: none;")

        self._card_values[title] = value_lbl
        self._card_subtitles[title] = subtitle_lbl

        card_layout.addLayout(title_row)
        card_layout.addWidget(value_lbl)
        card_layout.addStretch()
        card_layout.addWidget(subtitle_lbl)
        card.setLayout(card_layout)
        return card

    def _make_student_summary_card(self, title: str, value: str, color: str, subtitle: str) -> QFrame:
        card = self._make_card(title, value, color, subtitle)
        self._student_summary_values[title] = self._card_values[title]
        return card

    def _make_progress_overview_card(self) -> QFrame:
        card = self._make_chart_frame()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(10)

        title_row = QHBoxLayout()
        title_block = QVBoxLayout()
        title = QLabel("Progress Overview")
        title.setStyleSheet("font-size: 15px; font-weight: bold; color: #0F172A; border: none;")
        self.overview_week_label = QLabel("Current weekly report completion")
        self.overview_week_label.setStyleSheet("font-size: 12px; color: #64748B; border: none;")
        title_block.addWidget(title)
        title_block.addWidget(self.overview_week_label)
        self.overview_percent_label = QLabel("0%")
        self.overview_percent_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.overview_percent_label.setStyleSheet("font-size: 34px; font-weight: bold; color: #7C3AED; border: none;")
        title_row.addLayout(title_block)
        title_row.addStretch()
        title_row.addWidget(self.overview_percent_label)
        layout.addLayout(title_row)

        self.overview_progress_bar = QProgressBar()
        self.overview_progress_bar.setRange(0, 100)
        self.overview_progress_bar.setValue(0)
        self.overview_progress_bar.setTextVisible(False)
        self.overview_progress_bar.setFixedHeight(12)
        self.overview_progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                border-radius: 6px;
                background: #E5E7EB;
            }
            QProgressBar::chunk {
                background: #7C3AED;
                border-radius: 6px;
            }
        """)
        layout.addWidget(self.overview_progress_bar)

        section_title = QLabel("Sections")
        section_title.setStyleSheet("font-size: 12px; font-weight: bold; color: #334155; border: none; padding-top: 6px;")
        layout.addWidget(section_title)
        self.overview_section_labels: Dict[str, QLabel] = {}
        for key, text in [
            ("core", "Core Work Content"),
            ("results", "Completed Tasks & Results"),
            ("problems", "Problems & Solutions"),
            ("plans", "Next Week Plan"),
        ]:
            label = QLabel(f"○ {text}")
            label.setStyleSheet("font-size: 12px; color: #64748B; border: none; padding: 2px 0px;")
            self.overview_section_labels[key] = label
            layout.addWidget(label)

        self.overview_tip_label = QLabel("Create a weekly report to see progress guidance.")
        self.overview_tip_label.setWordWrap(True)
        self.overview_tip_label.setStyleSheet("""
            QLabel {
                color: #64748B;
                background: #F8FAFC;
                border: none;
                border-radius: 8px;
                padding: 8px 10px;
                margin-top: 6px;
            }
        """)
        layout.addStretch()
        layout.addWidget(self.overview_tip_label)
        return card

    def _report_section_status(self, report) -> dict[str, bool]:
        tasks = self.db.get_tasks_by_report(report.id, is_plan=False)
        plans = self.db.get_tasks_by_report(report.id, is_plan=True)
        problems = self.db.get_problems_by_report(report.id)
        return {
            "core": bool(tasks or (report.highlights or "").strip()),
            "results": bool(any(t.progress > 0 or t.status == "completed" for t in tasks) or (report.highlights or "").strip()),
            "problems": bool(problems or (report.shortcomings or "").strip() or (report.improvements or "").strip()),
            "plans": bool(plans or (report.next_plan_summary or "").strip()),
        }

    def _set_progress_overview(self, report):
        if report is None:
            self.overview_week_label.setText("No weekly report selected")
            self.overview_percent_label.setText("0%")
            self.overview_progress_bar.setValue(0)
            for label in self.overview_section_labels.values():
                text = label.text().replace("✓ ", "").replace("○ ", "")
                label.setText(f"○ {text}")
                label.setStyleSheet("font-size: 12px; color: #64748B; border: none; padding: 2px 0px;")
            self.overview_tip_label.setText("Create a weekly report to see progress guidance.")
            return

        sections = self._report_section_status(report)
        completed = sum(1 for ready in sections.values() if ready)
        percent = completed * 25
        self.overview_week_label.setText(f"Week {report.week_number} report completion status")
        self.overview_percent_label.setText(f"{percent}%")
        self.overview_progress_bar.setValue(percent)
        label_texts = {
            "core": "Core Work Content",
            "results": "Completed Tasks & Results",
            "problems": "Problems & Solutions",
            "plans": "Next Week Plan",
        }
        for key, ready in sections.items():
            self.overview_section_labels[key].setText(f"{'✓' if ready else '○'} {label_texts[key]}")
            color = "#16A34A" if ready else "#64748B"
            self.overview_section_labels[key].setStyleSheet(f"font-size: 12px; color: {color}; border: none; padding: 2px 0px;")
        if percent == 100:
            tip = "All core sections are complete. You can polish language or export the report."
        elif percent >= 75:
            tip = "You have completed most parts of this weekly report. Finish the remaining section before submission."
        elif percent >= 50:
            tip = "The report has a usable foundation. Add missing reflection or next-week planning to improve quality."
        else:
            tip = "The report is still incomplete. Use AI Assistant to generate missing sections from keywords."
        self.overview_tip_label.setText(tip)

    def _make_chart_frame(self) -> QFrame:
        frame = QFrame()
        frame.setObjectName("ChartCard")
        frame.setStyleSheet(
            """
            QFrame#ChartCard {
                background: white;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
            }
            """
        )
        return frame

    def _chart_title(self, text: str) -> QLabel:
        label = QLabel(text)
        label.setStyleSheet("font-size: 15px; font-weight: bold; color: #0F172A; padding: 0px 0px 8px 0px; border: none;")
        return label

    def _set_flagged_style(self, state: str):
        styles = {
            "danger": ("#E74C3C", "#FDEDEC", "#F5B7B1"),
            "success": ("#27AE60", "#EAF7EF", "#A9DFBF"),
            "neutral": ("#7F8C8D", "#FFFFFF", "#E8ECF1"),
        }
        color, bg, border = styles[state]
        self.flagged_label.setStyleSheet(
            f"""
            color: {color};
            padding: 10px 12px;
            background: {bg};
            border: 1px solid {border};
            border-radius: 6px;
            """
        )

    def _table_style(self) -> str:
        return """
            QTableWidget {
                border: 1px solid #E5E7EB;
                border-radius: 8px;
                gridline-color: #F1F5F9;
                background: white;
                alternate-background-color: #F8FAFC;
                color: #0F172A;
            }
            QHeaderView::section {
                background: #F8FAFC;
                color: #334155;
                padding: 8px;
                border: none;
                border-bottom: 1px solid #E5E7EB;
                font-weight: bold;
            }
            QTableWidget::item {
                padding: 6px;
            }
            QTableWidget::item:selected {
                background: #E8F2FF;
                color: #0F172A;
            }
        """

    def _report_progress(self, report_id: int) -> float:
        tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
        if not tasks:
            return 0.0
        return round(sum(task.progress for task in tasks) / len(tasks), 1)

    def _feedback_text(self, report_id: int) -> str:
        comments = self.db.get_comments_by_report(report_id)
        if not comments:
            return "0 unread"
        unread = sum(1 for item in comments if not item.get("is_read"))
        return f"{unread} unread" if unread else "Reviewed"

    def _unread_feedback_count(self, reports) -> int:
        return sum(
            1
            for report in reports
            for item in self.db.get_comments_by_report(report.id)
            if not item.get("is_read")
        )

    def _format_datetime(self, value: str) -> str:
        if not value:
            return "N/A"
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
            try:
                parsed = datetime.strptime(value[:19], fmt)
                return parsed.strftime("%Y-%m-%d %H:%M")
            except Exception:
                continue
        return value[:16]

    def _refresh_teacher_stats(self):
        class_name = self.class_combo.currentText()
        week = int(self.week_combo.currentText())

        summary = self.stats_service.get_class_summary(class_name, week)

        if "Submission Rate" in self._card_values:
            rate = summary.get("submission_rate", 0)
            total = summary.get("total_students", 0)
            submitted = summary.get("submitted", 0)
            delayed = summary.get("delayed_tasks", 0)
            self._card_values["Submission Rate"].setText(f"{rate}%")
            self._card_subtitles["Submission Rate"].setText(f"{submitted}/{total} submitted")
            self._card_values["Avg Progress"].setText(f"{summary.get('avg_progress', 0)}%")
            self._card_subtitles["Avg Progress"].setText("Average task completion")
            self._card_values["Delayed Tasks"].setText(str(delayed))
            self._card_subtitles["Delayed Tasks"].setText("task" if delayed == 1 else "tasks")

        self.submission_figure.clear()
        ax = self.submission_figure.add_subplot(111)
        submitted = summary.get("submitted", 0)
        unsubmitted = summary.get("unsubmitted", 0)
        if submitted + unsubmitted > 0:
            ax.pie(
                [submitted, unsubmitted],
                labels=["Submitted", "Unsubmitted"],
                autopct="%1.1f%%",
                colors=["#27AE60", "#E74C3C"],
                startangle=90,
                textprops={"fontsize": 9},
            )
            ax.set_title(f"Week {week} Submission Status", fontsize=11)
        else:
            ax.text(0.5, 0.5, "No submission data", ha="center", va="center")
        self.submission_canvas.draw()

        self.problem_figure.clear()
        ax = self.problem_figure.add_subplot(111)
        problems = self.stats_service.get_problem_analysis(class_name, week)
        if problems:
            labels = [
                self._wrap_axis_label(self.template_service.get_problem_type_label(p["problem_type"]))
                for p in problems
            ]
            counts = [p["cnt"] for p in problems]
            colors = ["#3B82F6", "#EF4444", "#F59E0B", "#64748B"][: len(labels)]
            ax.barh(labels, counts, color=colors, height=0.55)
            ax.set_title("Problem Distribution", fontsize=13, pad=10)
            ax.set_xlabel("")
            ax.set_ylabel("")
            ax.tick_params(axis="y", labelsize=10)
            ax.tick_params(axis="x", labelsize=9)
            ax.grid(axis="x", linestyle="--", alpha=0.25)
            ax.set_axisbelow(True)
            ax.xaxis.set_major_locator(MaxNLocator(integer=True))
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            self.problem_figure.subplots_adjust(left=0.36, right=0.96, top=0.84, bottom=0.18)
        else:
            ax.text(0.5, 0.5, "No problems reported", ha="center", va="center")
            self.problem_figure.subplots_adjust(left=0.12, right=0.96, top=0.84, bottom=0.18)
        self.problem_canvas.draw()

        flagged = self.stats_service.get_flagged_students(class_name)
        if flagged:
            text = "; ".join(f"{s['name']} ({s['avg_progress']}%)" for s in flagged)
            self.flagged_label.setText(f"Attention: {text}")
            self._set_flagged_style("danger")
        else:
            self.flagged_label.setText("No students flagged.")
            self._set_flagged_style("success")

    def _refresh_student_charts(self):
        if not self._student_user_id:
            return

        history = self.stats_service.get_student_avg_progress_by_week(self._student_user_id)
        reports = self.db.get_reports_by_user(self._student_user_id)
        reports = sorted(reports, key=lambda report: (report.week_number, report.updated_at or report.created_at), reverse=True)
        submitted_statuses = {"submitted", "reviewed", "approved"}
        submitted_count = sum(1 for report in reports if report.status in submitted_statuses)
        submission_rate = round(submitted_count / len(reports) * 100, 1) if reports else 0
        progress_values = [self._report_progress(report.id) for report in reports]
        overall_progress = round(sum(progress_values) / len(progress_values), 1) if progress_values else 0
        unread_feedback = self._unread_feedback_count(reports)

        if "Total Reports" in self._student_summary_values:
            self._student_summary_values["Total Reports"].setText(str(len(reports)))
            self._card_subtitles["Total Reports"].setText("report" if len(reports) == 1 else "reports created")
            self._student_summary_values["Submission Rate"].setText(f"{submission_rate}%")
            self._card_subtitles["Submission Rate"].setText(f"Submitted: {submitted_count} / {len(reports)}")
            self._student_summary_values["Avg Progress"].setText(f"{overall_progress}%")
            self._card_subtitles["Avg Progress"].setText("Average of all weekly reports")
            self._student_summary_values["Unread Feedback"].setText(str(unread_feedback))
            self._card_subtitles["Unread Feedback"].setText("comments waiting")

        status_counts = {"Draft": 0, "Submitted": 0, "Reviewed": 0, "Approved": 0, "Rejected": 0}
        for report in reports:
            label = report.status.replace("_", " ").title()
            status_counts[label] = status_counts.get(label, 0) + 1

        self.status_figure.clear()
        ax = self.status_figure.add_subplot(111)
        labels = [label for label, count in status_counts.items() if count > 0]
        counts = [status_counts[label] for label in labels]
        if counts:
            colors = ["#94A3B8", "#2563EB", "#F59E0B", "#16A34A", "#EF4444"][: len(labels)]
            ax.bar(labels, counts, color=colors, width=0.58)
            ax.set_ylabel("Reports")
            ax.set_ylim(0, max(counts) + 1)
            ax.yaxis.set_major_locator(MaxNLocator(integer=True))
            ax.tick_params(axis="x", labelrotation=15, labelsize=9)
            ax.tick_params(axis="y", labelsize=9)
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            for index, count in enumerate(counts):
                ax.text(index, count + 0.05, str(count), ha="center", va="bottom", fontsize=9)
        else:
            ax.text(
                0.5, 0.5,
                "No reports yet\nCreate a weekly report to generate analytics.",
                ha="center", va="center", color="#64748B", fontsize=10
            )
            ax.set_axis_off()
        self.status_figure.tight_layout()
        self.status_canvas.draw()

        self._set_progress_overview(reports[0] if reports else None)

        if hasattr(self, "recent_table"):
            self.recent_table.setRowCount(0)
            for report in reports[:6]:
                row = self.recent_table.rowCount()
                self.recent_table.insertRow(row)
                self.recent_table.setRowHeight(row, 42)
                self.recent_table.setItem(row, 0, QTableWidgetItem(f"Week {report.week_number}"))
                self.recent_table.setCellWidget(row, 1, StatusBadge(report.status))
                self.recent_table.setItem(row, 2, QTableWidgetItem(f"{self._report_progress(report.id):.0f}%"))
                self.recent_table.setItem(row, 3, QTableWidgetItem(self._feedback_text(report.id)))
                self.recent_table.setItem(row, 4, QTableWidgetItem(self._format_datetime(report.updated_at or report.created_at)))
