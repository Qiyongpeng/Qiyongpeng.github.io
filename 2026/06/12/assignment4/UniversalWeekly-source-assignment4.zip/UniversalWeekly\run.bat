@echo off
title UniversalWeekly - Weekly Report Management System
echo ============================================
echo   UniversalWeekly - Dual-Role Weekly Report
echo   Management System
echo ============================================
echo.
echo Starting application...
python "%~dp0main.py"
if %errorlevel% neq 0 (
    echo.
    echo Error: Failed to start. Make sure dependencies are installed.
    echo Run: pip install -r requirements.txt
    pause
)
