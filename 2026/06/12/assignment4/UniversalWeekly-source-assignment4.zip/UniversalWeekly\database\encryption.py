"""Data encryption utilities for local data security."""

import os
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


class DataEncryption:
    """Handle encryption and decryption of sensitive data."""

    def __init__(self, key_file=None):
        self.key_file = key_file or os.path.join(
            os.path.dirname(os.path.dirname(__file__)), ".app_key"
        )
        self._fernet = None

    def _derive_key(self, password: str, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=480000,
        )
        return base64.urlsafe_b64encode(kdf.derive(password.encode()))

    def _get_or_create_key(self) -> bytes:
        if os.path.exists(self.key_file):
            with open(self.key_file, "rb") as f:
                return f.read()
        key = Fernet.generate_key()
        with open(self.key_file, "wb") as f:
            f.write(key)
        return key

    @property
    def fernet(self) -> Fernet:
        if self._fernet is None:
            self._fernet = Fernet(self._get_or_create_key())
        return self._fernet

    def encrypt(self, plain_text: str) -> str:
        if not plain_text:
            return ""
        return self.fernet.encrypt(plain_text.encode()).decode()

    def decrypt(self, encrypted_text: str) -> str:
        if not encrypted_text:
            return ""
        try:
            return self.fernet.decrypt(encrypted_text.encode()).decode()
        except Exception:
            return ""

    def encrypt_password(self, password: str) -> str:
        salt = os.urandom(16)
        key = self._derive_key(password, salt)
        return base64.b64encode(salt + key).decode()

    def verify_password(self, password: str, stored: str) -> bool:
        try:
            data = base64.b64decode(stored.encode())
            salt = data[:16]
            stored_key = data[16:]
            key = self._derive_key(password, salt)
            return key == stored_key
        except Exception:
            return False
