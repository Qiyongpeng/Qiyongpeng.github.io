"""Login and registration window."""

from PyQt6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QLineEdit, QFormLayout,
    QMessageBox, QTabWidget, QCheckBox, QRadioButton, QButtonGroup
)
from PyQt6.QtCore import Qt, pyqtSignal, QTimer, QSettings
from database.db_manager import DatabaseManager
from business.auth_service import AuthService
from ui.common_widgets import StyledButton


class LoginWindow(QWidget):
    """Main login/registration window with dual-role support."""

    login_successful = pyqtSignal(object, bool)  # (auth_service, is_teacher)

    def __init__(self, db: DatabaseManager):
        super().__init__()
        self.db = db
        self.auth = AuthService(db)
        self.settings = QSettings("UniversalWeekly", "UniversalWeekly")
        self._dark_mode = False
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("UniversalWeekly - Weekly Report Management System")
        self.setMinimumSize(980, 640)

        root_layout = QHBoxLayout()
        root_layout.setContentsMargins(28, 28, 28, 28)
        root_layout.setSpacing(22)

        left_panel = self._create_brand_panel()
        right_panel = QWidget()
        right_panel.setObjectName("AuthPanel")
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(34, 26, 34, 30)
        right_layout.setSpacing(18)

        top_bar = QHBoxLayout()
        top_bar.addStretch()
        self.dark_mode_check = QCheckBox("Dark Mode")
        self.dark_mode_check.setObjectName("ThemeToggle")
        self.dark_mode_check.toggled.connect(self._toggle_theme)
        top_bar.addWidget(self.dark_mode_check)

        auth_title = QLabel("Welcome Back")
        auth_title.setObjectName("AuthTitle")
        auth_subtitle = QLabel("Sign in to manage weekly reports, reviews, progress, and analytics.")
        auth_subtitle.setObjectName("AuthSubtitle")
        auth_subtitle.setWordWrap(True)

        self.tab_widget = QTabWidget()

        self.login_tab = self._create_login_tab()
        self.register_tab = self._create_register_tab()

        self.tab_widget.addTab(self.login_tab, "Sign In")
        self.tab_widget.addTab(self.register_tab, "Register")

        right_layout.addLayout(top_bar)
        right_layout.addWidget(auth_title)
        right_layout.addWidget(auth_subtitle)
        right_layout.addWidget(self.tab_widget, 1)

        root_layout.addWidget(left_panel, 5)
        root_layout.addWidget(right_panel, 4)
        self.setLayout(root_layout)

        self._load_remembered_login()
        self._apply_theme(False)

    def _create_brand_panel(self) -> QWidget:
        panel = QWidget()
        panel.setObjectName("BrandPanel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(34, 34, 34, 28)
        layout.setSpacing(18)

        logo_row = QHBoxLayout()
        logo = QLabel("UW")
        logo.setObjectName("LogoBadge")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setFixedSize(72, 72)

        brand_text = QVBoxLayout()
        title = QLabel("UniversalWeekly")
        title.setObjectName("BrandTitle")
        subtitle = QLabel("Weekly Report Management System")
        subtitle.setObjectName("BrandSubtitle")
        brand_text.addWidget(title)
        brand_text.addWidget(subtitle)
        logo_row.addWidget(logo)
        logo_row.addLayout(brand_text, 1)

        headline = QLabel("A dual-role platform for students and teachers.")
        headline.setObjectName("HeroHeadline")
        headline.setWordWrap(True)

        description = QLabel(
            "Create reports, receive teacher feedback, track weekly progress, "
            "and review statistics in one clean workspace."
        )
        description.setObjectName("HeroDescription")
        description.setWordWrap(True)

        features = QWidget()
        features.setObjectName("FeatureBox")
        feature_layout = QVBoxLayout(features)
        feature_layout.setContentsMargins(18, 16, 18, 16)
        feature_layout.setSpacing(10)
        for text in (
            "Weekly Report Submission",
            "Teacher Review System",
            "Progress Tracking",
            "Analytics Dashboard",
        ):
            label = QLabel(f"[OK] {text}")
            label.setObjectName("FeatureItem")
            feature_layout.addWidget(label)

        stats = self._load_login_stats()
        stats_row = QHBoxLayout()
        stats_row.setSpacing(10)
        stats_row.addWidget(self._create_stat_chip("Students", str(stats["students"])))
        stats_row.addWidget(self._create_stat_chip("Teachers", str(stats["teachers"])))
        stats_row.addWidget(self._create_stat_chip("Reports", f"{stats['reports']}+"))

        version = QLabel("System Version 2.0")
        version.setObjectName("VersionLabel")

        layout.addLayout(logo_row)
        layout.addSpacing(12)
        layout.addWidget(headline)
        layout.addWidget(description)
        layout.addSpacing(8)
        layout.addWidget(features)
        layout.addStretch()
        layout.addLayout(stats_row)
        layout.addWidget(version)
        return panel

    def _create_stat_chip(self, label: str, value: str) -> QWidget:
        chip = QWidget()
        chip.setObjectName("StatChip")
        layout = QVBoxLayout(chip)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(3)

        value_label = QLabel(value)
        value_label.setObjectName("StatValue")
        value_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label_widget = QLabel(label)
        label_widget.setObjectName("StatLabel")
        label_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(value_label)
        layout.addWidget(label_widget)
        return chip

    def _load_login_stats(self) -> dict:
        try:
            with self.db._get_db() as conn:
                students = conn.execute(
                    "SELECT COUNT(*) as cnt FROM user_info WHERE role = 'student' AND is_active = 1"
                ).fetchone()["cnt"]
                teachers = conn.execute(
                    "SELECT COUNT(*) as cnt FROM user_info WHERE role = 'teacher' AND is_active = 1"
                ).fetchone()["cnt"]
                reports = conn.execute(
                    "SELECT COUNT(*) as cnt FROM weekly_report"
                ).fetchone()["cnt"]
            return {"students": students, "teachers": teachers, "reports": reports}
        except Exception:
            return {"students": 120, "teachers": 8, "reports": 3500}

    def _create_login_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(8, 28, 8, 20)
        layout.setSpacing(12)

        form = QFormLayout()
        form.setSpacing(14)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        self.login_username = QLineEdit()
        self.login_username.setPlaceholderText("Enter your username")
        self.login_username.setMinimumHeight(44)

        self.login_password = QLineEdit()
        self.login_password.setPlaceholderText("Enter your password")
        self.login_password.setEchoMode(QLineEdit.EchoMode.Password)
        self.login_password.setMinimumHeight(44)

        form.addRow("Username:", self.login_username)
        form.addRow("Password:", self.login_password)

        options_row = QHBoxLayout()
        self.remember_check = QCheckBox("Remember Me")
        self.show_password_check = QCheckBox("Show Password")
        self.show_password_check.toggled.connect(self._toggle_login_password)
        options_row.addWidget(self.remember_check)
        options_row.addStretch()
        options_row.addWidget(self.show_password_check)

        forgot_row = QHBoxLayout()
        forgot_row.addStretch()
        forgot_btn = QPushButton("Forgot Password?")
        forgot_btn.setObjectName("LinkButton")
        forgot_btn.clicked.connect(self._forgot_password)
        forgot_row.addWidget(forgot_btn)

        self.login_error_label = QLabel("")
        self.login_error_label.setObjectName("InlineError")
        self.login_error_label.setWordWrap(True)
        self.login_error_label.hide()

        self.login_btn = StyledButton("Sign In", "primary")
        self.login_btn.setMinimumHeight(44)
        self.login_btn.clicked.connect(self._handle_login)

        demo_label = QLabel("Quick Demo Login")
        demo_label.setObjectName("SectionCaption")
        demo_layout = QHBoxLayout()
        demo_layout.setSpacing(10)
        demo_student = StyledButton("Demo Student", "info")
        demo_teacher = StyledButton("Demo Teacher", "success")
        demo_student.clicked.connect(lambda: self._quick_fill("student1", "123456"))
        demo_teacher.clicked.connect(lambda: self._quick_fill("teacher1", "123456"))
        demo_layout.addWidget(demo_student)
        demo_layout.addWidget(demo_teacher)

        layout.addLayout(form)
        layout.addLayout(options_row)
        layout.addLayout(forgot_row)
        layout.addWidget(self.login_error_label)
        layout.addSpacing(6)
        layout.addWidget(self.login_btn)
        layout.addSpacing(18)
        layout.addWidget(demo_label)
        layout.addLayout(demo_layout)
        layout.addStretch()

        widget.setLayout(layout)
        return widget

    def _create_register_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(8, 18, 8, 20)
        layout.setSpacing(12)

        scroll = QWidget()
        form = QFormLayout()
        form.setSpacing(12)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        self.reg_username = QLineEdit()
        self.reg_username.setPlaceholderText("Min 3 characters")
        self.reg_username.setMinimumHeight(40)

        self.reg_password = QLineEdit()
        self.reg_password.setPlaceholderText("Min 6 characters")
        self.reg_password.setEchoMode(QLineEdit.EchoMode.Password)
        self.reg_password.setMinimumHeight(40)

        self.reg_confirm = QLineEdit()
        self.reg_confirm.setPlaceholderText("Confirm password")
        self.reg_confirm.setEchoMode(QLineEdit.EchoMode.Password)
        self.reg_confirm.setMinimumHeight(40)

        role_widget = QWidget()
        role_layout = QHBoxLayout(role_widget)
        role_layout.setContentsMargins(0, 0, 0, 0)
        role_layout.setSpacing(14)
        self.reg_role_group = QButtonGroup(self)
        self.student_role_radio = QRadioButton("Student")
        self.teacher_role_radio = QRadioButton("Teacher")
        self.student_role_radio.setChecked(True)
        self.reg_role_group.addButton(self.student_role_radio)
        self.reg_role_group.addButton(self.teacher_role_radio)
        role_layout.addWidget(self.student_role_radio)
        role_layout.addWidget(self.teacher_role_radio)
        role_layout.addStretch()

        self.reg_name = QLineEdit()
        self.reg_name.setPlaceholderText("Your display name")
        self.reg_name.setMinimumHeight(40)

        self.reg_id = QLineEdit()
        self.reg_id.setPlaceholderText("Student/teacher number")
        self.reg_id.setMinimumHeight(40)

        self.reg_class = QLineEdit()
        self.reg_class.setPlaceholderText("e.g., CS2024-A")
        self.reg_class.setMinimumHeight(40)

        self.reg_email = QLineEdit()
        self.reg_email.setPlaceholderText("Optional")
        self.reg_email.setMinimumHeight(40)

        self.reg_show_password_check = QCheckBox("Show Password")
        self.reg_show_password_check.toggled.connect(self._toggle_register_password)

        form.addRow("Username:", self.reg_username)
        form.addRow("Password:", self.reg_password)
        form.addRow("Confirm:", self.reg_confirm)
        form.addRow("Role:", role_widget)
        form.addRow("Full Name:", self.reg_name)
        form.addRow("ID Number:", self.reg_id)
        form.addRow("Class:", self.reg_class)
        form.addRow("Email:", self.reg_email)
        form.addRow("", self.reg_show_password_check)

        scroll.setLayout(form)

        self.register_btn = StyledButton("Create Account", "success")
        self.register_btn.setMinimumHeight(44)
        self.register_btn.clicked.connect(self._handle_register)

        layout.addWidget(scroll)
        layout.addSpacing(10)
        layout.addWidget(self.register_btn)
        layout.addStretch()
        widget.setLayout(layout)
        return widget

    def _handle_login(self):
        username = self.login_username.text().strip()
        password = self.login_password.text()
        self._set_login_error("")
        self._set_login_busy(True)
        QTimer.singleShot(350, lambda: self._finish_login(username, password))

    def _finish_login(self, username: str, password: str):
        success, msg = self.auth.login(username, password)
        if success:
            if self.remember_check.isChecked():
                self.settings.setValue("remember_username", True)
                self.settings.setValue("saved_username", username)
            else:
                self.settings.remove("remember_username")
                self.settings.remove("saved_username")
            self.login_successful.emit(self.auth, self.auth.is_teacher)
        else:
            self._set_login_busy(False)
            self._set_login_error(f"Error: {msg}")

    def _handle_register(self):
        role = "teacher" if self.teacher_role_radio.isChecked() else "student"
        result = self.auth.register(
            username=self.reg_username.text(),
            password=self.reg_password.text(),
            confirm_password=self.reg_confirm.text(),
            role=role,
            display_name=self.reg_name.text(),
            student_id=self.reg_id.text(),
            class_name=self.reg_class.text(),
            email=self.reg_email.text(),
        )
        if result[0]:
            QMessageBox.information(self, "Success", result[1])
            self.tab_widget.setCurrentIndex(0)
        else:
            QMessageBox.warning(self, "Registration Failed", result[1])

    def _quick_fill(self, username: str, password: str):
        self.login_username.setText(username)
        self.login_password.setText(password)
        self._set_login_error("")

    def _load_remembered_login(self):
        remember = self.settings.value("remember_username", False, type=bool)
        if remember:
            self.remember_check.setChecked(True)
            self.login_username.setText(self.settings.value("saved_username", "", type=str))

    def _toggle_login_password(self, checked: bool):
        mode = QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password
        self.login_password.setEchoMode(mode)

    def _toggle_register_password(self, checked: bool):
        mode = QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password
        self.reg_password.setEchoMode(mode)
        self.reg_confirm.setEchoMode(mode)

    def _forgot_password(self):
        QMessageBox.information(
            self,
            "Forgot Password",
            "Please contact the system administrator to reset your password."
        )

    def _set_login_busy(self, busy: bool):
        self.login_btn.setEnabled(not busy)
        self.login_btn.setText("Signing in..." if busy else "Sign In")

    def _set_login_error(self, message: str):
        self.login_error_label.setText(message)
        self.login_error_label.setVisible(bool(message))

    def _toggle_theme(self, checked: bool):
        self._dark_mode = checked
        self._apply_theme(checked)

    def _apply_theme(self, dark: bool):
        if dark:
            self.setStyleSheet("""
                QWidget {
                    background-color: #0F172A;
                    color: #E5E7EB;
                    font-family: "Segoe UI", "Microsoft YaHei", sans-serif;
                    font-size: 13px;
                }
                QWidget#BrandPanel {
                    background-color: #111827;
                    border: 1px solid #243244;
                    border-radius: 22px;
                }
                QWidget#AuthPanel {
                    background-color: #111827;
                    border: 1px solid #243244;
                    border-radius: 22px;
                }
                QLabel#LogoBadge {
                    background-color: #2563EB;
                    color: white;
                    border-radius: 18px;
                    font-size: 24px;
                    font-weight: 800;
                }
                QLabel#BrandTitle {
                    color: #F8FAFC;
                    font-size: 30px;
                    font-weight: 800;
                }
                QLabel#BrandSubtitle, QLabel#HeroDescription, QLabel#AuthSubtitle,
                QLabel#StatLabel, QLabel#VersionLabel, QLabel#SectionCaption {
                    color: #94A3B8;
                }
                QLabel#HeroHeadline {
                    color: #F8FAFC;
                    font-size: 24px;
                    font-weight: 700;
                }
                QWidget#FeatureBox, QWidget#StatChip {
                    background-color: #1E293B;
                    border: 1px solid #334155;
                    border-radius: 14px;
                }
                QLabel#FeatureItem {
                    color: #DDEAFE;
                    font-size: 14px;
                    font-weight: 600;
                }
                QLabel#StatValue {
                    color: #93C5FD;
                    font-size: 22px;
                    font-weight: 800;
                }
                QLabel#AuthTitle {
                    color: #F8FAFC;
                    font-size: 26px;
                    font-weight: 800;
                }
                QLabel#InlineError {
                    color: #FCA5A5;
                    background-color: #451A1A;
                    border: 1px solid #7F1D1D;
                    border-radius: 8px;
                    padding: 8px 10px;
                }
                QLineEdit {
                    background: #0F172A;
                    color: #F8FAFC;
                    border: 1px solid #334155;
                    border-radius: 10px;
                    padding: 10px 12px;
                }
                QLineEdit:focus {
                    border: 1px solid #60A5FA;
                }
                QTabWidget::pane {
                    border: none;
                    background: transparent;
                }
                QTabBar::tab {
                    background: #1E293B;
                    color: #CBD5E1;
                    padding: 12px 26px;
                    min-width: 120px;
                    border-radius: 10px;
                    margin-right: 8px;
                    font-weight: 700;
                }
                QTabBar::tab:selected {
                    background: #2563EB;
                    color: white;
                }
                QCheckBox, QRadioButton {
                    color: #CBD5E1;
                    spacing: 8px;
                }
                QPushButton#LinkButton {
                    background: transparent;
                    color: #93C5FD;
                    border: none;
                    font-weight: 700;
                }
            """)
        else:
            self.setStyleSheet("""
                QWidget {
                    background-color: #F8FAFC;
                    color: #0F172A;
                    font-family: "Segoe UI", "Microsoft YaHei", sans-serif;
                    font-size: 13px;
                }
                QWidget#BrandPanel {
                    background-color: #FFFFFF;
                    border: 1px solid #E2E8F0;
                    border-radius: 22px;
                }
                QWidget#AuthPanel {
                    background-color: #FFFFFF;
                    border: 1px solid #E2E8F0;
                    border-radius: 22px;
                }
                QLabel#LogoBadge {
                    background-color: #2563EB;
                    color: white;
                    border-radius: 18px;
                    font-size: 24px;
                    font-weight: 800;
                }
                QLabel#BrandTitle {
                    color: #0F172A;
                    font-size: 30px;
                    font-weight: 800;
                }
                QLabel#BrandSubtitle, QLabel#HeroDescription, QLabel#AuthSubtitle,
                QLabel#StatLabel, QLabel#VersionLabel, QLabel#SectionCaption {
                    color: #64748B;
                }
                QLabel#HeroHeadline {
                    color: #0F172A;
                    font-size: 24px;
                    font-weight: 700;
                }
                QWidget#FeatureBox {
                    background-color: #F1F5F9;
                    border: 1px solid #E2E8F0;
                    border-radius: 14px;
                }
                QWidget#StatChip {
                    background-color: #F8FAFC;
                    border: 1px solid #E2E8F0;
                    border-radius: 14px;
                }
                QLabel#FeatureItem {
                    color: #1E3A8A;
                    font-size: 14px;
                    font-weight: 600;
                }
                QLabel#StatValue {
                    color: #2563EB;
                    font-size: 22px;
                    font-weight: 800;
                }
                QLabel#AuthTitle {
                    color: #0F172A;
                    font-size: 26px;
                    font-weight: 800;
                }
                QLabel#InlineError {
                    color: #B91C1C;
                    background-color: #FEF2F2;
                    border: 1px solid #FECACA;
                    border-radius: 8px;
                    padding: 8px 10px;
                }
                QLineEdit {
                    background: #FFFFFF;
                    color: #0F172A;
                    border: 1px solid #CBD5E1;
                    border-radius: 10px;
                    padding: 10px 12px;
                }
                QLineEdit:focus {
                    border: 1px solid #2563EB;
                }
                QTabWidget::pane {
                    border: none;
                    background: transparent;
                }
                QTabBar::tab {
                    background: #F1F5F9;
                    color: #334155;
                    padding: 12px 26px;
                    min-width: 120px;
                    border-radius: 10px;
                    margin-right: 8px;
                    font-weight: 700;
                }
                QTabBar::tab:selected {
                    background: #2563EB;
                    color: white;
                }
                QCheckBox, QRadioButton {
                    color: #334155;
                    spacing: 8px;
                }
                QPushButton#LinkButton {
                    background: transparent;
                    color: #2563EB;
                    border: none;
                    font-weight: 700;
                }
            """)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Return or event.key() == Qt.Key.Key_Enter:
            if self.tab_widget.currentIndex() == 0:
                self._handle_login()
            else:
                self._handle_register()
        super().keyPressEvent(event)
