"""Authentication and authorization service."""

from typing import Optional, Tuple
from database.db_manager import DatabaseManager
from database.models import User


class AuthService:
    """Handle user authentication, registration, and permission checks."""

    def __init__(self, db: DatabaseManager):
        self.db = db
        self._current_user: Optional[User] = None

    @property
    def current_user(self) -> Optional[User]:
        return self._current_user

    @property
    def is_logged_in(self) -> bool:
        return self._current_user is not None

    @property
    def is_teacher(self) -> bool:
        return self._current_user is not None and self._current_user.role == "teacher"

    @property
    def is_student(self) -> bool:
        return self._current_user is not None and self._current_user.role == "student"

    def login(self, username: str, password: str) -> Tuple[bool, str]:
        """Authenticate user. Returns (success, message)."""
        if not username.strip():
            return False, "Username cannot be empty."
        if not password.strip():
            return False, "Password cannot be empty."

        user = self.db.authenticate(username, password)
        if user is None:
            return False, "Invalid username or password."

        self._current_user = user
        self.db.log_operation(
            user.id, user.username, "login",
            f"User {user.display_name} ({user.role}) logged in."
        )
        return True, f"Welcome, {user.display_name}!"

    def register(self, username: str, password: str, confirm_password: str,
                 role: str, display_name: str, student_id: str = "",
                 class_name: str = "", email: str = "", phone: str = "") -> Tuple[bool, str]:
        """Register a new user. Returns (success, message)."""
        if not username.strip():
            return False, "Username cannot be empty."
        if len(username) < 3:
            return False, "Username must be at least 3 characters."
        if not password.strip():
            return False, "Password cannot be empty."
        if len(password) < 6:
            return False, "Password must be at least 6 characters."

        if password != confirm_password:
            return False, "Passwords do not match."
        if not display_name.strip():
            return False, "Display name cannot be empty."
        if role not in ("student", "teacher"):
            return False, "Invalid role selected."

        user = self.db.register_user(
            username=username.strip(),
            password=password,
            role=role,
            display_name=display_name.strip(),
            student_id=student_id.strip(),
            class_name=class_name.strip(),
            email=email.strip(),
            phone=phone.strip(),
        )
        if user is None:
            return False, "Username already exists. Please choose another."

        self.db.log_operation(
            user.id, user.username, "register",
            f"New {role} account created: {display_name}"
        )
        return True, "Registration successful! You can now log in."

    def logout(self):
        """Log out the current user."""
        if self._current_user:
            self.db.log_operation(
                self._current_user.id, self._current_user.username,
                "logout", f"User {self._current_user.display_name} logged out."
            )
        self._current_user = None

    def switch_role(self) -> bool:
        """Switch between student/teacher roles (for dual-role users)."""
        if not self._current_user:
            return False
        new_role = "teacher" if self._current_user.role == "student" else "student"
        self._current_user.role = new_role
        return True

    def check_report_permission(self, report_user_id: int) -> bool:
        """Check if current user can access a report."""
        if not self._current_user:
            return False
        if self._current_user.role == "student":
            return self._current_user.id == report_user_id
        return True  # teachers can view all

    def get_teacher_students(self) -> list:
        """Get list of students under the teacher's classes."""
        if not self.is_teacher:
            return []
        teacher = self._current_user
        if teacher.class_name:
            return self.db.get_students_by_class(teacher.class_name)
        # Teacher with no class assigned — get all classes
        all_students = []
        for cls in self.db.get_all_classes():
            all_students.extend(self.db.get_students_by_class(cls))
        return all_students
