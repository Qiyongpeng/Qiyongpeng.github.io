"""Shared/common UI widgets used across the application."""

from PyQt6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
    QComboBox, QLineEdit, QTextEdit, QDateEdit, QSpinBox,
    QDialog, QFormLayout, QGroupBox, QScrollArea, QFrame,
    QTabWidget, QSplitter, QListWidget, QListWidgetItem,
    QMenu, QFileDialog, QToolButton, QProgressBar
)
from PyQt6.QtCore import Qt, QSize, pyqtSignal
from PyQt6.QtGui import QFont, QIcon, QAction, QColor, QBrush


class StyledButton(QPushButton):
    """Standardized styled button."""

    def __init__(self, text: str, color: str = "primary", parent=None):
        super().__init__(text, parent)
        self.setMinimumHeight(36)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        colors = {
            "primary": "#2563EB",
            "ai": "#7C3AED",
            "secondary": "#6C7A89",
            "success": "#16A34A",
            "warning": "#F39C12",
            "danger": "#EF4444",
            "info": "#0EA5E9",
            "default": "#95A5A6",
        }
        bg = colors.get(color, colors["primary"])
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 9px 18px;
                font-size: 14px;
                font-weight: bold;
                min-height: 26px;
            }}
            QPushButton:hover {{
                background-color: {bg}DD;
            }}
            QPushButton:pressed {{
                background-color: {bg}BB;
            }}
            QPushButton:disabled {{
                background-color: #BDC3C7;
            }}
        """)


class SectionLabel(QLabel):
    """Section header label."""

    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet("""
            QLabel {
                font-size: 16px;
                font-weight: bold;
                color: #2C3E50;
                padding: 8px 0px;
                border-bottom: 2px solid #4A90D9;
            }
        """)
        self.setMinimumHeight(40)


class CardFrame(QFrame):
    """Card-style container frame."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            CardFrame, QFrame {
                background-color: white;
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 16px;
            }
        """)
        self.setMinimumHeight(60)


class StatusBadge(QLabel):
    """Colored status badge."""

    def __init__(self, status: str, parent=None):
        super().__init__(parent)
        status_colors = {
            "draft": ("#95A5A6", "Draft"),
            "submitted": ("#3498DB", "Submitted"),
            "reviewed": ("#F39C12", "Reviewed"),
            "approved": ("#27AE60", "Approved"),
            "rejected": ("#E74C3C", "Rejected"),
            "not_started": ("#95A5A6", "Not Started"),
            "in_progress": ("#3498DB", "In Progress"),
            "completed": ("#27AE60", "Completed"),
            "delayed": ("#E74C3C", "Delayed"),
        }
        color, label = status_colors.get(status, ("#95A5A6", status))
        self.setText(f" {label} ")
        self.setStyleSheet(f"""
            QLabel {{
                background-color: {color}22;
                color: {color};
                border: 1px solid {color};
                border-radius: 10px;
                padding: 2px 10px;
                font-size: 11px;
                font-weight: bold;
            }}
        """)


class ReadOnlyTable(QTableWidget):
    """Table widget with read-only cells and standardized appearance."""

    def __init__(self, headers: list, parent=None):
        super().__init__(parent)
        self.setColumnCount(len(headers))
        self.setHorizontalHeaderLabels(headers)
        self.horizontalHeader().setStretchLastSection(True)
        self.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.setAlternatingRowColors(True)
        self.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.verticalHeader().setVisible(False)
        self.setStyleSheet("""
            QTableWidget {
                border: 1px solid #E0E0E0;
                border-radius: 4px;
                gridline-color: #F0F0F0;
            }
            QHeaderView::section {
                background-color: #4A90D9;
                color: white;
                padding: 8px;
                border: none;
                font-weight: bold;
            }
            QTableWidget::item:alternate {
                background-color: #F8F9FA;
            }
            QTableWidget::item:selected {
                background-color: #4A90D944;
                color: #2C3E50;
            }
        """)

    def add_row(self, row_data: list):
        row = self.rowCount()
        self.insertRow(row)
        for col, data in enumerate(row_data):
            item = QTableWidgetItem(str(data))
            self.setItem(row, col, item)

    def clear_all(self):
        self.setRowCount(0)


class IconButton(QToolButton):
    """Tool button with icon-like appearance."""

    def __init__(self, text: str, parent=None):
        super().__init__(parent)
        self.setText(text)
        self.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        self.setMinimumSize(QSize(80, 32))
        self.setStyleSheet("""
            QToolButton {
                background-color: #F0F0F0;
                border: 1px solid #D0D0D0;
                border-radius: 4px;
                padding: 4px 12px;
                font-size: 12px;
            }
            QToolButton:hover {
                background-color: #E0E0E0;
            }
        """)
