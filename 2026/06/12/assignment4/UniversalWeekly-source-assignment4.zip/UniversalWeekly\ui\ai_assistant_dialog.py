"""Embedded DeepSeek chat assistant dialog."""

from __future__ import annotations

import html

from PyQt6.QtCore import QObject, QThread, Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from business.deepseek_client import DeepSeekClient
from database.db_manager import DatabaseManager
from ui.common_widgets import StyledButton


class DeepSeekChatWorker(QObject):
    """Run the blocking API call outside the UI thread."""

    finished = pyqtSignal(str)

    def __init__(
        self,
        client: DeepSeekClient,
        user_text: str,
        history: list[dict[str, str]],
        report_context: str,
    ):
        super().__init__()
        self.client = client
        self.user_text = user_text
        self.history = history
        self.report_context = report_context

    def run(self):
        reply = self.client.chat(self.user_text, self.history, self.report_context)
        self.finished.emit(reply)


class AIAssistantDialog(QDialog):
    """DeepSeek-powered chat window for weekly-report assistance."""

    def __init__(
        self,
        db: DatabaseManager,
        user_id: int,
        username: str = "",
        report_id: int | None = None,
        parent=None,
    ):
        super().__init__(parent)
        self.db = db
        self.user_id = user_id
        self.username = username
        self.report_id = report_id
        self.history: list[dict[str, str]] = []
        self.client = DeepSeekClient()
        self._thread: QThread | None = None
        self._worker: DeepSeekChatWorker | None = None
        self.report_context = self._build_report_context()
        self._init_ui()
        self._show_initial_message()

    def _init_ui(self):
        self.setWindowTitle("AI Weekly Report Assistant")
        self.setMinimumSize(760, 620)
        self.setStyleSheet("""
            QDialog { background: #F8FAFC; }
            QLabel { border: none; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        header = QFrame()
        header.setObjectName("AssistantHeader")
        header.setStyleSheet("""
            QFrame#AssistantHeader {
                background: #FFFFFF;
                border: 1px solid #EEF2F7;
                border-radius: 14px;
            }
        """)
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(20, 14, 20, 14)
        title = QLabel("AI Weekly Report Assistant")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #0F172A;")
        subtitle = QLabel("Ask DeepSeek to generate, polish, check, or revise your weekly report.")
        subtitle.setStyleSheet("font-size: 12px; color: #64748B;")
        header_layout.addWidget(title)
        header_layout.addWidget(subtitle)
        layout.addWidget(header)

        quick_row = QHBoxLayout()
        quick_row.setSpacing(8)
        quick_prompts = [
            ("Generate Report", "Please generate a complete weekly report from these keywords:\n"),
            ("Polish", "Please polish the following weekly-report content to make it clearer and more formal:\n"),
            ("Check", "Please check the completeness of this weekly report and give a percentage score with suggestions:\n"),
            ("Revise by Feedback", "Please revise the weekly report according to the teacher feedback.\n\nOriginal report:\n\nTeacher feedback:\n"),
        ]
        for text, prompt in quick_prompts:
            btn = QPushButton(text)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet("""
                QPushButton {
                    background: #FFFFFF;
                    color: #2563EB;
                    border: 1px solid #D7E3F5;
                    border-radius: 8px;
                    padding: 8px 12px;
                    font-weight: bold;
                }
                QPushButton:hover { background: #EFF6FF; }
            """)
            btn.clicked.connect(lambda checked=False, p=prompt: self._insert_prompt(p))
            quick_row.addWidget(btn)
        quick_row.addStretch()
        layout.addLayout(quick_row)

        self.chat_box = QTextEdit()
        self.chat_box.setReadOnly(True)
        self.chat_box.setStyleSheet("""
            QTextEdit {
                background: #FFFFFF;
                color: #0F172A;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
                padding: 12px;
                font-size: 13px;
            }
        """)
        layout.addWidget(self.chat_box, 1)

        input_row = QHBoxLayout()
        self.input_box = QTextEdit()
        self.input_box.setPlaceholderText("Type your request here...")
        self.input_box.setFixedHeight(96)
        self.input_box.setStyleSheet("""
            QTextEdit {
                background: #FFFFFF;
                color: #0F172A;
                border: 1px solid #CBD5E1;
                border-radius: 10px;
                padding: 10px;
                font-size: 13px;
            }
            QTextEdit:focus { border-color: #7C3AED; }
        """)
        input_row.addWidget(self.input_box, 1)

        button_col = QVBoxLayout()
        self.send_button = StyledButton("Send", "ai")
        self.send_button.clicked.connect(self._send_message)
        clear_button = StyledButton("Clear", "default")
        clear_button.clicked.connect(self._clear_chat)
        button_col.addWidget(self.send_button)
        button_col.addWidget(clear_button)
        button_col.addStretch()
        input_row.addLayout(button_col)
        layout.addLayout(input_row)

    def _show_initial_message(self):
        if self.client.is_configured:
            message = (
                "Hello, I am the embedded AI assistant for UniversalWeekly. "
                "I can help generate weekly reports, polish text, check completeness, "
                "or revise reports based on teacher feedback."
            )
        else:
            message = (
                "DeepSeek API key is not configured yet. Set DEEPSEEK_API_KEY in config.py "
                "or as an environment variable, then restart the app."
            )
        if self.report_context:
            message += "\n\nA selected report context has been loaded for this chat."
        self._append_message("AI", message)

    def _build_report_context(self) -> str:
        if not self.report_id:
            return ""
        report = self.db.get_report(self.report_id)
        if not report:
            return ""
        tasks = self.db.get_tasks_by_report(self.report_id, is_plan=False)
        plans = self.db.get_tasks_by_report(self.report_id, is_plan=True)
        problems = self.db.get_problems_by_report(self.report_id)
        comments = self.db.get_comments_by_report(self.report_id)

        task_text = "\n".join(
            f"- {task.name} ({task.status}, {task.progress}%): {task.description}"
            for task in tasks
        ) or "No task records."
        plan_text = "\n".join(f"- {plan.name}: {plan.description}" for plan in plans) or "No next-week plans."
        problem_text = "\n".join(
            f"- {problem.description}; attempted: {problem.attempted_solution}; unresolved: {problem.unresolved_reason}"
            for problem in problems
        ) or "No problem records."
        comment_text = "\n".join(f"- {item.get('content', '')}" for item in comments) or "No teacher feedback."

        return f"""Selected report:
Week: {report.week_number}
Period: {report.start_date} to {report.end_date}
Status: {report.status}

Highlights:
{report.highlights or "None"}

Shortcomings:
{report.shortcomings or "None"}

Improvements:
{report.improvements or "None"}

Next-week summary:
{report.next_plan_summary or "None"}

Tasks:
{task_text}

Problems:
{problem_text}

Plans:
{plan_text}

Teacher feedback:
{comment_text}
"""

    def _insert_prompt(self, prompt: str):
        self.input_box.setPlainText(prompt)
        self.input_box.setFocus()

    def _append_message(self, sender: str, message: str):
        safe_sender = html.escape(sender)
        safe_message = html.escape(message).replace("\n", "<br>")
        color = "#7C3AED" if sender == "AI" else "#2563EB"
        self.chat_box.append(
            f"""
            <div style="margin:10px 0;">
                <div style="font-weight:700;color:{color};">{safe_sender}</div>
                <div style="color:#0F172A;line-height:1.45;">{safe_message}</div>
            </div>
            <hr style="border:0;border-top:1px solid #E5E7EB;" />
            """
        )
        self.chat_box.verticalScrollBar().setValue(self.chat_box.verticalScrollBar().maximum())

    def _send_message(self):
        user_text = self.input_box.toPlainText().strip()
        if not user_text:
            QMessageBox.warning(self, "Input Required", "Please enter a message first.")
            return

        self.input_box.clear()
        self._append_message("You", user_text)
        self.send_button.setEnabled(False)
        self.send_button.setText("Thinking...")

        self._thread = QThread(self)
        self._worker = DeepSeekChatWorker(
            self.client,
            user_text,
            list(self.history),
            self.report_context,
        )
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.finished.connect(lambda reply, text=user_text: self._finish_response(text, reply))
        self._worker.finished.connect(self._thread.quit)
        self._worker.finished.connect(self._worker.deleteLater)
        self._thread.finished.connect(self._thread.deleteLater)
        self._thread.start()

    def _finish_response(self, user_text: str, reply: str):
        self._append_message("AI", reply)
        self.history.append({"role": "user", "content": user_text})
        self.history.append({"role": "assistant", "content": reply})
        if len(self.history) > 12:
            self.history = self.history[-12:]
        self.send_button.setEnabled(True)
        self.send_button.setText("Send")
        self._log_ai_call(user_text, reply)

    def _clear_chat(self):
        self.history = []
        self.chat_box.clear()
        self._show_initial_message()

    def _log_ai_call(self, user_text: str, reply: str):
        try:
            prompt_preview = user_text.replace("\n", " ")[:160]
            reply_preview = reply.replace("\n", " ")[:160]
            self.db.log_operation(
                self.user_id,
                self.username,
                "ai_deepseek_chat",
                f"DeepSeek chat | prompt: {prompt_preview} | reply: {reply_preview}",
            )
        except Exception:
            pass

    def closeEvent(self, event):
        if self._thread is not None and self._thread.isRunning():
            QMessageBox.information(
                self,
                "Request Running",
                "DeepSeek is still responding. Please wait until the current request finishes.",
            )
            event.ignore()
            return
        super().closeEvent(event)
