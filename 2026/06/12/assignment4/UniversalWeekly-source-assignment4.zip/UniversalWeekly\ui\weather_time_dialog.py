"""Weather forecast and time/date utility dialog."""

from __future__ import annotations

from PyQt6.QtCore import QDate, QTimer, Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication,
    QDateEdit,
    QDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from business.weather_time_service import WeatherTimeService
from ui.common_widgets import SectionLabel, StyledButton


class WeatherTimeDialog(QDialog):
    """Show live time, date calculations, and weather forecasts."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Weather & Time")
        self.setMinimumSize(980, 680)
        self._init_ui()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._update_clock)
        self._timer.start(1000)
        self._update_clock()

    def _init_ui(self):
        self.setStyleSheet("""
            QDialog { background-color: #F5F7FA; }
            QLineEdit, QDateEdit, QSpinBox {
                border: 1px solid #D9E1EC;
                border-radius: 6px;
                padding: 7px;
                background: white;
            }
            QTableWidget {
                background: white;
                border: 1px solid #D9E1EC;
                border-radius: 8px;
                gridline-color: #EEF2F7;
            }
            QHeaderView::section {
                background: #2C3E50;
                color: white;
                padding: 8px;
                border: none;
                font-weight: bold;
            }
        """)
        layout = QVBoxLayout()
        layout.setContentsMargins(14, 14, 14, 14)
        layout.addWidget(SectionLabel("Weather & Time"))

        subtitle = QLabel("Live local time, date calculations, and 7-day city weather forecast.")
        subtitle.setStyleSheet("color: #5D6D7E; padding-bottom: 8px;")
        layout.addWidget(subtitle)

        main_grid = QGridLayout()
        main_grid.addWidget(self._create_time_card(), 0, 0)
        main_grid.addWidget(self._create_date_card(), 1, 0)
        main_grid.addWidget(self._create_weather_card(), 0, 1, 2, 1)
        main_grid.setColumnStretch(0, 1)
        main_grid.setColumnStretch(1, 2)
        layout.addLayout(main_grid, 1)

        close_row = QHBoxLayout()
        close_row.addStretch()
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)
        close_row.addWidget(close_btn)
        layout.addLayout(close_row)

        self.setLayout(layout)

    def _create_time_card(self) -> QFrame:
        card = self._card("#4A90D9")
        layout = QVBoxLayout(card)
        title = QLabel("Local Time")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2C3E50;")
        self.time_label = QLabel("--:--:--")
        self.time_label.setStyleSheet("font-size: 42px; font-weight: bold; color: #4A90D9;")
        self.date_label = QLabel("--")
        self.date_label.setStyleSheet("font-size: 16px; color: #5D6D7E;")
        self.week_label = QLabel("--")
        self.week_label.setStyleSheet("font-size: 13px; color: #7F8C8D;")
        layout.addWidget(title)
        layout.addWidget(self.time_label)
        layout.addWidget(self.date_label)
        layout.addWidget(self.week_label)
        layout.addStretch()
        return card

    def _create_date_card(self) -> QFrame:
        card = self._card("#27AE60")
        layout = QVBoxLayout(card)
        title = QLabel("Date Calculator")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2C3E50;")
        layout.addWidget(title)

        form = QFormLayout()
        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDate(QDate.currentDate())
        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDate(QDate.currentDate().addDays(7))
        self.add_days_spin = QSpinBox()
        self.add_days_spin.setRange(-3650, 3650)
        self.add_days_spin.setValue(7)
        self.days_between_label = QLabel("")
        self.add_days_label = QLabel("")

        self.start_date.dateChanged.connect(self._update_date_calc)
        self.end_date.dateChanged.connect(self._update_date_calc)
        self.add_days_spin.valueChanged.connect(self._update_date_calc)

        form.addRow("Start Date:", self.start_date)
        form.addRow("End Date:", self.end_date)
        form.addRow("Add Days:", self.add_days_spin)
        form.addRow("Days Between:", self.days_between_label)
        form.addRow("Result Date:", self.add_days_label)
        layout.addLayout(form)
        self._update_date_calc()
        return card

    def _create_weather_card(self) -> QFrame:
        card = self._card("#F39C12")
        layout = QVBoxLayout(card)
        title = QLabel("Weather Forecast")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #2C3E50;")
        layout.addWidget(title)

        search_row = QHBoxLayout()
        self.city_edit = QLineEdit("Beijing")
        self.city_edit.setPlaceholderText("Enter city, e.g. Beijing, Shanghai, London")
        search_btn = StyledButton("Get Forecast", "primary")
        search_btn.clicked.connect(self._fetch_weather)
        search_row.addWidget(self.city_edit, 1)
        search_row.addWidget(search_btn)
        layout.addLayout(search_row)

        self.weather_summary = QLabel("Enter a city and click Get Forecast.")
        self.weather_summary.setWordWrap(True)
        self.weather_summary.setStyleSheet("""
            QLabel {
                background: #FFF7E6;
                border: 1px solid #FAD7A0;
                border-radius: 8px;
                padding: 12px;
                color: #2C3E50;
            }
        """)
        layout.addWidget(self.weather_summary)

        self.weather_table = QTableWidget()
        self.weather_table.setColumnCount(5)
        self.weather_table.setHorizontalHeaderLabels(["Date", "Weather", "Min", "Max", "Rain %"])
        self.weather_table.verticalHeader().setVisible(False)
        self.weather_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.weather_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.weather_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.weather_table.setAlternatingRowColors(True)
        layout.addWidget(self.weather_table, 1)

        return card

    def _update_clock(self):
        info = WeatherTimeService.current_time_info()
        self.time_label.setText(info["time"])
        self.date_label.setText(f"{info['date']}  {info['weekday']}")
        self.week_label.setText(
            f"{info['month']} | ISO Week {info['iso_week']} | Day {info['day_of_year']} of year"
        )

    def _update_date_calc(self):
        start = self.start_date.date().toPyDate()
        end = self.end_date.date().toPyDate()
        days = WeatherTimeService.days_between(start, end)
        result = WeatherTimeService.add_days(start, self.add_days_spin.value())
        self.days_between_label.setText(f"{days} days")
        self.add_days_label.setText(result.strftime("%Y-%m-%d (%A)"))

    def _fetch_weather(self):
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            ok, result = WeatherTimeService.fetch_weather(self.city_edit.text())
        finally:
            QApplication.restoreOverrideCursor()
        if not ok:
            QMessageBox.warning(self, "Weather Unavailable", str(result))
            self.weather_summary.setText(str(result))
            return

        location = result["location"]
        current = result["current"]
        place = ", ".join(part for part in [location.get("name"), location.get("admin1"), location.get("country")] if part)
        self.weather_summary.setText(
            f"{place}\n"
            f"Current: {current['temperature']} °C, feels like {current['apparent_temperature']} °C\n"
            f"Weather: {current['weather']} | Humidity: {current['humidity']}% | Wind: {current['wind_speed']} km/h\n"
            f"Updated: {current['time']} | Timezone: {result.get('timezone', '')}"
        )
        self.weather_table.setRowCount(0)
        for day in result["daily"]:
            row = self.weather_table.rowCount()
            self.weather_table.insertRow(row)
            values = [
                day["date"],
                day["weather"],
                f"{day['temp_min']} °C",
                f"{day['temp_max']} °C",
                f"{day['precipitation']}%",
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if row == 0:
                    item.setBackground(QColor("#FFF7E6"))
                self.weather_table.setItem(row, col, item)

    @staticmethod
    def _card(color: str) -> QFrame:
        card = QFrame()
        card.setObjectName("weatherTimeCard")
        card.setStyleSheet(f"""
            QFrame#weatherTimeCard {{
                background: white;
                border: 1px solid #D9E1EC;
                border-left: 6px solid {color};
                border-radius: 12px;
                padding: 12px;
            }}
        """)
        return card
