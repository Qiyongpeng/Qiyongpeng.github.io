"""Generate a date-limited presentation draft from a weekly report."""

from __future__ import annotations

from pathlib import Path

from PyQt6.QtCore import QDate, Qt
from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDateEdit,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
)

from business.local_llm_service import LocalLLMService
from business.presentation_report_service import PRESENTATION_ENGINE_OPTIONS, PresentationReportService
from database.db_manager import DatabaseManager
from ui.common_widgets import SectionLabel, StyledButton


class PresentationReportDialog(QDialog):
    """Student tool for generating a speech draft from a selected weekly report date."""

    def __init__(self, db: DatabaseManager, user_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.user_id = user_id
        self.current_report = None
        self.setWindowTitle("Date-Limited Weekly Presentation")
        self.setMinimumSize(900, 680)
        self._init_ui()
        self._load_report_preview()

    def _init_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(SectionLabel("Date-Limited Weekly Presentation"))

        description = QLabel(
            "Choose a date. The system will find the weekly report whose date range contains that date, "
            "then generate a presentation draft with the specified length."
        )
        description.setWordWrap(True)
        description.setStyleSheet("color: #5D6D7E; padding: 4px 0 10px 0;")
        layout.addWidget(description)

        form = QFormLayout()
        self.date_edit = QDateEdit()
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.dateChanged.connect(self._load_report_preview)

        self.target_count_spin = QSpinBox()
        self.target_count_spin.setRange(100, 5000)
        self.target_count_spin.setSingleStep(100)
        self.target_count_spin.setValue(600)
        self.target_count_spin.setSuffix(" chars")

        self.engine_combo = QComboBox()
        self.engine_combo.addItems(PRESENTATION_ENGINE_OPTIONS)
        self.engine_combo.setCurrentText("Local LLM (Ollama)")
        self.engine_combo.currentTextChanged.connect(self._update_engine_defaults)

        self.endpoint_edit = QLineEdit(LocalLLMService.DEFAULT_OLLAMA_URL)
        self.model_edit = QComboBox()
        self.model_edit.setEditable(True)
        self.model_edit.addItems(LocalLLMService.model_options())
        self.model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
        self.model_edit.lineEdit().setPlaceholderText("Example: qwen2.5:7b")

        form.addRow("Report Date:", self.date_edit)
        form.addRow("Target Length:", self.target_count_spin)
        form.addRow("Engine:", self.engine_combo)
        form.addRow("Local Endpoint:", self.endpoint_edit)
        form.addRow("Local Model:", self.model_edit)
        layout.addLayout(form)

        self.preview_label = QLabel("")
        self.preview_label.setWordWrap(True)
        self.preview_label.setStyleSheet("background: #F8F9FA; color: #2C3E50; padding: 8px; border-radius: 4px;")
        layout.addWidget(self.preview_label)

        layout.addWidget(QLabel("Generated Presentation Draft:"))
        self.output_edit = QTextEdit()
        self.output_edit.setPlaceholderText("Generated speech draft will appear here.")
        layout.addWidget(self.output_edit, 1)

        self.status_label = QLabel("Engine: ready")
        self.status_label.setStyleSheet("color: #5D6D7E; padding-top: 4px;")
        layout.addWidget(self.status_label)

        btn_row = QHBoxLayout()
        generate_btn = StyledButton("Generate Presentation", "primary")
        generate_btn.clicked.connect(self._generate_presentation)
        test_btn = StyledButton("Test Local Model", "default")
        test_btn.clicked.connect(self._test_local_model)
        copy_btn = StyledButton("Copy Result", "success")
        copy_btn.clicked.connect(self._copy_result)
        save_btn = StyledButton("Save Result", "info")
        save_btn.clicked.connect(self._save_result)
        clear_btn = StyledButton("Clear", "default")
        clear_btn.clicked.connect(self._clear)
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)

        for button in [generate_btn, test_btn, copy_btn, save_btn, clear_btn, close_btn]:
            btn_row.addWidget(button)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.setLayout(layout)
        self._update_engine_defaults(self.engine_combo.currentText())

    def _update_engine_defaults(self, engine: str):
        if engine == "Local LLM (Ollama)":
            self.endpoint_edit.setText(LocalLLMService.DEFAULT_OLLAMA_URL)
            self.model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
            self.endpoint_edit.setEnabled(True)
            self.model_edit.setEnabled(True)
        elif engine == "Local LLM (OpenAI-compatible)":
            self.endpoint_edit.setText(LocalLLMService.DEFAULT_OPENAI_COMPAT_URL)
            self.model_edit.setCurrentText("local-model")
            self.endpoint_edit.setEnabled(True)
            self.model_edit.setEnabled(True)
        else:
            self.endpoint_edit.clear()
            self.model_edit.setCurrentText("")
            self.endpoint_edit.setEnabled(False)
            self.model_edit.setEnabled(False)

    def _selected_date_text(self) -> str:
        return self.date_edit.date().toString("yyyy-MM-dd")

    def _load_report_preview(self):
        selected = self._selected_date_text()
        self.current_report = PresentationReportService.find_report_by_date(self.db, self.user_id, selected)
        if not self.current_report:
            self.preview_label.setText(f"No weekly report found for {selected}. Please choose a date covered by an existing report.")
            return
        self.preview_label.setText(
            f"Matched report: Week {self.current_report.week_number} | "
            f"{self.current_report.start_date} ~ {self.current_report.end_date} | "
            f"Status: {self.current_report.status}"
        )

    def _generate_presentation(self):
        self._load_report_preview()
        if not self.current_report:
            QMessageBox.warning(self, "No Report", "No weekly report was found for the selected date.")
            return
        try:
            self.setCursor(Qt.CursorShape.WaitCursor)
            context = PresentationReportService.build_context(self.db, self.current_report)
            ok, result, engine = PresentationReportService.generate_presentation(
                context,
                self.target_count_spin.value(),
                self.engine_combo.currentText(),
                self.endpoint_edit.text().strip(),
                self.model_edit.currentText().strip(),
            )
        except Exception as exc:
            QMessageBox.critical(self, "Generation Failed", str(exc))
            return
        finally:
            self.unsetCursor()

        self.output_edit.setPlainText(result)
        self.status_label.setText(f"Engine: {engine} | Length: {len(result)} chars")
        self._log_generation(engine)
        if not ok:
            QMessageBox.warning(self, "Generation Failed", result)

    def _test_local_model(self):
        engine = self.engine_combo.currentText()
        if engine == "Offline Template":
            QMessageBox.information(self, "Local Model", "Offline Template does not need a local model.")
            return
        provider = "Ollama" if engine == "Local LLM (Ollama)" else "OpenAI-compatible"
        ok, message = LocalLLMService.test_connection(
            provider,
            self.endpoint_edit.text().strip(),
            self.model_edit.currentText().strip(),
        )
        self.status_label.setText(message)
        if ok:
            QMessageBox.information(self, "Local Model", message)
        else:
            QMessageBox.warning(self, "Local Model", message)

    def _copy_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please generate a presentation draft first.")
            return
        QApplication.clipboard().setText(text)
        QMessageBox.information(self, "Copied", "Presentation draft copied to clipboard.")

    def _save_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please generate a presentation draft first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save Presentation Draft", "weekly_presentation.txt", "Text File (*.txt)")
        if not path:
            return
        Path(path).write_text(text, encoding="utf-8")
        QMessageBox.information(self, "Saved", f"Presentation draft saved to:\n{path}")

    def _clear(self):
        self.output_edit.clear()
        self.status_label.setText("Engine: ready")

    def _log_generation(self, engine: str):
        try:
            user = self.db.get_user_by_id(self.user_id)
            username = user.username if user else ""
            report_id = self.current_report.id if self.current_report else ""
            desc = (
                f"date={self._selected_date_text()}; report_id={report_id}; "
                f"target_length={self.target_count_spin.value()}; engine={engine}"
            )
            self.db.log_operation(self.user_id, username, "ai_generate_presentation", desc)
        except Exception:
            pass
