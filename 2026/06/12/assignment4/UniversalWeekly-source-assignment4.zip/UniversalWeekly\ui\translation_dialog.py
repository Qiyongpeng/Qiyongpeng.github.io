"""Translation tool dialog."""

from __future__ import annotations

from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTextEdit,
    QVBoxLayout,
)

from business.translation_service import ENGINE_OPTIONS, LANGUAGE_MAP, TranslationService
from business.local_llm_service import LocalLLMService
from ui.common_widgets import SectionLabel, StyledButton


class TranslationDialog(QDialog):
    """Translate academic paragraphs, literature excerpts, words, and phrases."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Translation Tool")
        self.setMinimumSize(860, 680)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(SectionLabel("Translation Tool"))

        description = QLabel(
            "Translate literature excerpts, paper abstracts, academic paragraphs, words, and phrases. "
            "The default engine uses your local large language model, such as Ollama or an OpenAI-compatible local endpoint."
        )
        description.setWordWrap(True)
        description.setStyleSheet("color: #5D6D7E; padding: 4px 0 10px 0;")
        layout.addWidget(description)

        form = QFormLayout()
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["Literature Translation", "Word / Phrase Translation"])
        self.engine_combo = QComboBox()
        self.engine_combo.addItems(ENGINE_OPTIONS)
        self.engine_combo.setCurrentText("Local LLM (Ollama)")
        self.engine_combo.currentTextChanged.connect(self._update_engine_defaults)
        self.source_combo = QComboBox()
        self.source_combo.addItems(list(LANGUAGE_MAP.keys()))
        self.source_combo.setCurrentText("English")
        self.target_combo = QComboBox()
        self.target_combo.addItems(list(LANGUAGE_MAP.keys())[1:])
        self.target_combo.setCurrentText("Chinese (Simplified)")

        form.addRow("Mode:", self.mode_combo)
        form.addRow("Engine:", self.engine_combo)
        self.endpoint_edit = QLineEdit(LocalLLMService.DEFAULT_OLLAMA_URL)
        self.model_edit = QComboBox()
        self.model_edit.setEditable(True)
        self.model_edit.addItems(LocalLLMService.model_options())
        self.model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
        self.model_edit.lineEdit().setPlaceholderText("Example: qwen2.5:7b")
        form.addRow("Local Endpoint:", self.endpoint_edit)
        form.addRow("Local Model:", self.model_edit)
        form.addRow("Source Language:", self.source_combo)
        form.addRow("Target Language:", self.target_combo)
        layout.addLayout(form)

        io_layout = QHBoxLayout()
        input_col = QVBoxLayout()
        output_col = QVBoxLayout()

        input_col.addWidget(QLabel("Input Text:"))
        self.input_edit = QTextEdit()
        self.input_edit.setPlaceholderText("Paste an abstract, paragraph, term, or phrase here.")
        input_col.addWidget(self.input_edit, 1)

        output_col.addWidget(QLabel("Translation Result:"))
        self.output_edit = QTextEdit()
        self.output_edit.setReadOnly(True)
        self.output_edit.setPlaceholderText("Translation result will appear here.")
        output_col.addWidget(self.output_edit, 1)

        io_layout.addLayout(input_col, 1)
        io_layout.addLayout(output_col, 1)
        layout.addLayout(io_layout, 1)

        self.status_label = QLabel("Engine: ready")
        self.status_label.setStyleSheet("color: #5D6D7E; padding-top: 4px;")
        layout.addWidget(self.status_label)

        btn_row = QHBoxLayout()
        translate_btn = StyledButton("Translate", "primary")
        translate_btn.clicked.connect(self._translate)
        test_btn = StyledButton("Test Local Model", "default")
        test_btn.clicked.connect(self._test_local_model)
        load_file_btn = StyledButton("Open Text / DOCX", "info")
        load_file_btn.clicked.connect(self._open_file)
        sample_btn = StyledButton("Load Sample", "info")
        sample_btn.clicked.connect(self._load_sample)
        copy_btn = StyledButton("Copy Result", "success")
        copy_btn.clicked.connect(self._copy_result)
        save_btn = StyledButton("Save Result", "info")
        save_btn.clicked.connect(self._save_result)
        clear_btn = StyledButton("Clear", "default")
        clear_btn.clicked.connect(self._clear)
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)

        for button in [translate_btn, test_btn, load_file_btn, sample_btn, copy_btn, save_btn, clear_btn, close_btn]:
            btn_row.addWidget(button)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.setLayout(layout)
        self._update_engine_defaults(self.engine_combo.currentText())

    def _update_engine_defaults(self, engine: str):
        if engine == "Local LLM (Ollama)":
            self.endpoint_edit.setText(LocalLLMService.DEFAULT_OLLAMA_URL)
            self.model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
            self.endpoint_edit.setEnabled(True)
            self.model_edit.setEnabled(True)
        elif engine == "Local LLM (OpenAI-compatible)":
            self.endpoint_edit.setText(LocalLLMService.DEFAULT_OPENAI_COMPAT_URL)
            self.model_edit.setCurrentText("local-model")
            self.endpoint_edit.setEnabled(True)
            self.model_edit.setEnabled(True)
        else:
            self.endpoint_edit.clear()
            self.model_edit.setCurrentText("")
            self.endpoint_edit.setEnabled(False)
            self.model_edit.setEnabled(False)

    def _translate(self):
        ok, result, engine = TranslationService.translate(
            self.input_edit.toPlainText(),
            self.source_combo.currentText(),
            self.target_combo.currentText(),
            self.mode_combo.currentText(),
            self.engine_combo.currentText(),
            self.endpoint_edit.text().strip(),
            self.model_edit.currentText().strip(),
        )
        self.output_edit.setPlainText(result)
        self.status_label.setText(f"Engine: {engine}")
        if not ok:
            QMessageBox.warning(self, "Translation Failed", result)

    def _test_local_model(self):
        engine = self.engine_combo.currentText()
        if engine == "Offline Academic Fallback":
            QMessageBox.information(self, "Local Model", "Offline Academic Fallback does not need a local model.")
            return
        provider = "Ollama" if engine == "Local LLM (Ollama)" else "OpenAI-compatible"
        ok, message = LocalLLMService.test_connection(
            provider,
            self.endpoint_edit.text().strip(),
            self.model_edit.currentText().strip(),
        )
        self.status_label.setText(message)
        if ok:
            QMessageBox.information(self, "Local Model", message)
        else:
            QMessageBox.warning(self, "Local Model", message)

    def _open_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Text for Translation",
            "",
            "Readable Files (*.txt *.md *.docx);;All Files (*)",
        )
        if not path:
            return
        try:
            self.input_edit.setPlainText(self._read_text_file(Path(path)))
        except Exception as exc:
            QMessageBox.warning(self, "Open Failed", f"Could not read file:\n{exc}")

    def _read_text_file(self, path: Path) -> str:
        ext = path.suffix.lower()
        if ext in {".txt", ".md"}:
            return path.read_text(encoding="utf-8", errors="ignore")
        if ext == ".docx":
            from docx import Document

            doc = Document(str(path))
            return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        return path.read_text(encoding="utf-8", errors="ignore")

    def _load_sample(self):
        self.mode_combo.setCurrentText("Literature Translation")
        self.engine_combo.setCurrentText("Local LLM (Ollama)")
        self.source_combo.setCurrentText("English")
        self.target_combo.setCurrentText("Chinese (Simplified)")
        self.input_edit.setPlainText(
            "This paper proposes a digital twin-driven fault diagnosis method for rolling bearings. "
            "However, existing data-driven methods still suffer from domain gap under variable working conditions. "
            "Experimental results show that the proposed framework improves classification accuracy and robustness."
        )

    def _copy_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please translate text first.")
            return
        QApplication.clipboard().setText(text)
        QMessageBox.information(self, "Copied", "Translation result copied to clipboard.")

    def _save_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please translate text first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save Translation", "translation.txt", "Text File (*.txt)")
        if not path:
            return
        Path(path).write_text(text, encoding="utf-8")
        QMessageBox.information(self, "Saved", f"Translation saved to:\n{path}")

    def _clear(self):
        self.input_edit.clear()
        self.output_edit.clear()
        self.status_label.setText("Engine: ready")
