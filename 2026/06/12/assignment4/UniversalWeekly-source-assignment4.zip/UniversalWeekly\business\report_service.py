"""Weekly report business logic service."""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Tuple
from database.db_manager import DatabaseManager
from database.models import WeeklyReport, Task, ProblemRecord


class ReportService:
    """Handle weekly report CRUD and business logic."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    def create_report(self, user_id: int, class_name: str, week_number: int,
                      start_date: str, end_date: str) -> Optional[int]:
        report = WeeklyReport(
            user_id=user_id,
            class_name=class_name,
            week_number=week_number,
            start_date=start_date,
            end_date=end_date,
            status="draft"
        )
        return self.db.create_report(report)

    def submit_report(self, report_id: int) -> Tuple[bool, str]:
        report = self.db.get_report(report_id)
        if not report:
            return False, "Report not found."
        tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
        plans = self.db.get_tasks_by_report(report_id, is_plan=True)
        if not tasks:
            return False, "Please add at least one task before submitting."
        if not plans:
            return False, "Please add at least one next-week plan before submitting."
        self.db.update_report(report_id, status="submitted")
        return True, "Report submitted successfully."

    def get_report_tasks(self, report_id: int) -> Tuple[List[Task], List[Task]]:
        tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
        plans = self.db.get_tasks_by_report(report_id, is_plan=True)
        return tasks, plans

    def get_report_problems(self, report_id: int) -> List[ProblemRecord]:
        return self.db.get_problems_by_report(report_id)

    def add_task_to_report(self, report_id: int, category: str, name: str,
                           description: str = "", status: str = "not_started",
                           progress: int = 0, tags: str = "",
                           is_plan: bool = False) -> Optional[int]:
        task = Task(
            report_id=report_id,
            category=category,
            name=name,
            description=description,
            status=status,
            progress=progress,
            tags=tags,
            is_plan=is_plan,
        )
        return self.db.add_task(task)

    def carry_over_tasks(self, report_id: int, source_report_id: int) -> int:
        """Copy unfinished tasks from a previous report as planning tasks."""
        tasks, _ = self.get_report_tasks(source_report_id)
        count = 0
        for task in tasks:
            if task.status in ("not_started", "in_progress", "delayed"):
                new_task = Task(
                    report_id=report_id,
                    category=task.category,
                    name=task.name,
                    description=task.description,
                    status="not_started",
                    progress=0,
                    tags=task.tags,
                    is_plan=True,
                    source_task_id=task.id,
                )
                self.db.add_task(new_task)
                count += 1
        return count

    def add_problem_to_report(self, report_id: int, description: str,
                               problem_type: str = "other",
                               attempted_solution: str = "",
                               unresolved_reason: str = "") -> Optional[int]:
        problem = ProblemRecord(
            report_id=report_id,
            description=description,
            problem_type=problem_type,
            attempted_solution=attempted_solution,
            unresolved_reason=unresolved_reason,
        )
        return self.db.add_problem(problem)

    def get_current_week_number(self) -> int:
        """Calculate ISO week number."""
        return datetime.now().isocalendar()[1]

    def get_week_date_range(self, year: int = None, week: int = None) -> Tuple[str, str]:
        """Get start and end dates for a given week."""
        if year is None:
            year = datetime.now().year
        if week is None:
            week = self.get_current_week_number()
        jan4 = datetime(year, 1, 4)
        start_of_jan4_week = jan4 - timedelta(days=jan4.weekday())
        week_start = start_of_jan4_week + timedelta(weeks=week - 1)
        week_end = week_start + timedelta(days=6)
        return week_start.strftime("%Y-%m-%d"), week_end.strftime("%Y-%m-%d")

    def copy_report_from_template(self, user_id: int, template_id: int) -> Optional[int]:
        """Create a report from a template."""
        templates = self.db.get_templates(user_id, "report")
        template = None
        for t in templates:
            if t.id == template_id:
                template = t
                break
        if not template:
            return None
        try:
            config = json.loads(template.content)
        except json.JSONDecodeError:
            return None

        week = self.get_current_week_number()
        start_date, end_date = self.get_week_date_range()

        user = self.db.get_user_by_id(user_id)
        if not user:
            return None

        report_id = self.create_report(
            user_id=user_id,
            class_name=user.class_name,
            week_number=week,
            start_date=start_date,
            end_date=end_date,
        )
        if not report_id:
            return None

        # Add template tasks
        for task_config in config.get("tasks", []):
            self.add_task_to_report(
                report_id=report_id,
                category=task_config.get("category", "study"),
                name=task_config.get("name", ""),
                description=task_config.get("description", ""),
            )

        for task_config in config.get("plans", []):
            self.add_task_to_report(
                report_id=report_id,
                category=task_config.get("category", "study"),
                name=task_config.get("name", ""),
                description=task_config.get("description", ""),
                is_plan=True,
            )

        return report_id

    def delete_report(self, report_id: int) -> bool:
        return self.db.delete_report(report_id)

    def get_previous_report_id(self, user_id: int, current_week: int) -> Optional[int]:
        reports = self.db.get_reports_by_user(user_id)
        for r in reports:
            if r.week_number < current_week:
                return r.id
        return None
