"""Beautiful memo manager dialog."""

from __future__ import annotations

from PyQt6.QtCore import QDate, Qt
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from business.memo_service import MemoService
from database.db_manager import DatabaseManager
from ui.common_widgets import SectionLabel, StyledButton


CATEGORIES = ["Research", "Coursework", "Experiment", "Meeting", "Writing", "Personal", "Other"]
PRIORITIES = ["Low", "Medium", "High", "Urgent"]
STATUSES = ["Open", "Done"]
COLORS = ["Blue", "Green", "Orange", "Red", "Purple", "Gray"]

COLOR_MAP = {
    "Blue": "#4A90D9",
    "Green": "#27AE60",
    "Orange": "#F39C12",
    "Red": "#E74C3C",
    "Purple": "#8E44AD",
    "Gray": "#7F8C8D",
}

PRIORITY_COLOR = {
    "Low": "#7F8C8D",
    "Medium": "#4A90D9",
    "High": "#F39C12",
    "Urgent": "#E74C3C",
}


class MemoDialog(QDialog):
    """A polished memo manager with filters, preview, and quick actions."""

    def __init__(self, db: DatabaseManager, user_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.user_id = user_id
        self.memo_service = MemoService(db)
        self._memos: list[dict] = []
        self.setWindowTitle("Memo Board")
        self.setMinimumSize(1050, 700)
        self._init_ui()
        self._load_memos()

    def _init_ui(self):
        self.setStyleSheet("""
            QDialog { background-color: #F5F7FA; }
            QLineEdit, QComboBox, QDateEdit, QTextEdit {
                border: 1px solid #D9E1EC;
                border-radius: 6px;
                padding: 7px;
                background: white;
            }
            QTableWidget {
                background: white;
                border: 1px solid #D9E1EC;
                border-radius: 8px;
                gridline-color: #EEF2F7;
            }
            QHeaderView::section {
                background: #2C3E50;
                color: white;
                padding: 8px;
                border: none;
                font-weight: bold;
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(14, 14, 14, 14)
        layout.addWidget(SectionLabel("Memo Board"))

        stats_layout = QGridLayout()
        self.total_card = self._stat_card("Total", "0", "#4A90D9")
        self.open_card = self._stat_card("Open", "0", "#F39C12")
        self.done_card = self._stat_card("Done", "0", "#27AE60")
        self.pinned_card = self._stat_card("Pinned", "0", "#8E44AD")
        for index, card in enumerate([self.total_card, self.open_card, self.done_card, self.pinned_card]):
            stats_layout.addWidget(card, 0, index)
        layout.addLayout(stats_layout)

        filter_bar = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search memo title or content...")
        self.search_edit.textChanged.connect(self._load_memos)
        self.category_filter = QComboBox()
        self.category_filter.addItems(["All"] + CATEGORIES)
        self.category_filter.currentTextChanged.connect(self._load_memos)
        self.status_filter = QComboBox()
        self.status_filter.addItems(["All"] + STATUSES)
        self.status_filter.currentTextChanged.connect(self._load_memos)
        self.priority_filter = QComboBox()
        self.priority_filter.addItems(["All"] + PRIORITIES)
        self.priority_filter.currentTextChanged.connect(self._load_memos)

        filter_bar.addWidget(QLabel("Search:"))
        filter_bar.addWidget(self.search_edit, 2)
        filter_bar.addWidget(QLabel("Category:"))
        filter_bar.addWidget(self.category_filter)
        filter_bar.addWidget(QLabel("Status:"))
        filter_bar.addWidget(self.status_filter)
        filter_bar.addWidget(QLabel("Priority:"))
        filter_bar.addWidget(self.priority_filter)
        layout.addLayout(filter_bar)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(self._create_table_panel())
        splitter.addWidget(self._create_detail_panel())
        splitter.setSizes([650, 360])
        layout.addWidget(splitter, 1)

        btn_row = QHBoxLayout()
        new_btn = StyledButton("+ New Memo", "primary")
        new_btn.clicked.connect(self._new_memo)
        edit_btn = StyledButton("Edit", "info")
        edit_btn.clicked.connect(self._edit_memo)
        done_btn = StyledButton("Toggle Done", "success")
        done_btn.clicked.connect(self._toggle_done)
        pin_btn = StyledButton("Pin / Unpin", "warning")
        pin_btn.clicked.connect(self._toggle_pin)
        delete_btn = StyledButton("Delete", "danger")
        delete_btn.clicked.connect(self._delete_memo)
        refresh_btn = StyledButton("Refresh", "default")
        refresh_btn.clicked.connect(self._load_memos)
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)

        for button in [new_btn, edit_btn, done_btn, pin_btn, delete_btn, refresh_btn, close_btn]:
            btn_row.addWidget(button)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.setLayout(layout)

    def _create_table_panel(self) -> QWidget:
        panel = QWidget()
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(0, 0, 8, 0)
        panel_layout.addWidget(QLabel("Memo List"))

        self.memo_table = QTableWidget()
        self.memo_table.setColumnCount(8)
        self.memo_table.setHorizontalHeaderLabels(["Pin", "Title", "Category", "Priority", "Status", "Due", "Updated", "ID"])
        self.memo_table.setColumnHidden(7, True)
        self.memo_table.verticalHeader().setVisible(False)
        self.memo_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.memo_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.memo_table.setAlternatingRowColors(True)
        self.memo_table.itemSelectionChanged.connect(self._show_selected_detail)
        self.memo_table.itemDoubleClicked.connect(self._edit_memo)
        self.memo_table.horizontalHeader().setStretchLastSection(True)
        panel_layout.addWidget(self.memo_table, 1)
        return panel

    def _create_detail_panel(self) -> QWidget:
        self.detail_card = QFrame()
        self.detail_card.setStyleSheet("""
            QFrame {
                background: white;
                border: 1px solid #D9E1EC;
                border-radius: 12px;
                padding: 12px;
            }
        """)
        detail_layout = QVBoxLayout(self.detail_card)
        self.detail_title = QLabel("Select a memo")
        self.detail_title.setWordWrap(True)
        self.detail_title.setStyleSheet("font-size: 20px; font-weight: bold; color: #2C3E50;")
        self.detail_meta = QLabel("No memo selected.")
        self.detail_meta.setWordWrap(True)
        self.detail_meta.setStyleSheet("color: #5D6D7E;")
        self.detail_content = QTextEdit()
        self.detail_content.setReadOnly(True)
        self.detail_content.setPlaceholderText("Memo details will appear here.")
        detail_layout.addWidget(self.detail_title)
        detail_layout.addWidget(self.detail_meta)
        detail_layout.addWidget(self.detail_content, 1)
        return self.detail_card

    def _stat_card(self, title: str, value: str, color: str) -> QFrame:
        card = QFrame()
        card.setObjectName("memoStatCard")
        card.setStyleSheet(f"""
            QFrame#memoStatCard {{
                background: white;
                border-left: 5px solid {color};
                border-radius: 10px;
                padding: 10px;
            }}
        """)
        layout = QVBoxLayout(card)
        label = QLabel(title)
        label.setStyleSheet("color: #7F8C8D; font-size: 12px;")
        number = QLabel(value)
        number.setObjectName("valueLabel")
        number.setStyleSheet(f"color: {color}; font-size: 26px; font-weight: bold;")
        layout.addWidget(label)
        layout.addWidget(number)
        return card

    def _load_memos(self):
        self._memos = self.memo_service.list_memos(
            self.user_id,
            self.search_edit.text() if hasattr(self, "search_edit") else "",
            self.category_filter.currentText() if hasattr(self, "category_filter") else "All",
            self.status_filter.currentText() if hasattr(self, "status_filter") else "All",
            self.priority_filter.currentText() if hasattr(self, "priority_filter") else "All",
        )
        self._refresh_stats()
        self.memo_table.setRowCount(0)
        for memo in self._memos:
            self._add_table_row(memo)
        if self._memos:
            self.memo_table.selectRow(0)
        else:
            self._clear_detail()

    def _refresh_stats(self):
        stats = self.memo_service.stats(self.user_id)
        cards = [
            (self.total_card, stats["total"]),
            (self.open_card, stats["open"]),
            (self.done_card, stats["done"]),
            (self.pinned_card, stats["pinned"]),
        ]
        for card, value in cards:
            card.findChild(QLabel, "valueLabel").setText(str(value))

    def _add_table_row(self, memo: dict):
        row = self.memo_table.rowCount()
        self.memo_table.insertRow(row)
        values = [
            "★" if memo["is_pinned"] else "",
            memo["title"],
            memo["category"],
            memo["priority"],
            memo["status"],
            memo["due_date"] or "-",
            memo["updated_at"],
            str(memo["id"]),
        ]
        for col, value in enumerate(values):
            item = QTableWidgetItem(value)
            if col == 0:
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if col == 3:
                item.setForeground(Qt.GlobalColor.white)
                item.setBackground(Qt.GlobalColor.transparent)
            self.memo_table.setItem(row, col, item)

        priority_item = self.memo_table.item(row, 3)
        priority_item.setBackground(self._qcolor(PRIORITY_COLOR.get(memo["priority"], "#4A90D9")))
        status_item = self.memo_table.item(row, 4)
        status_item.setBackground(self._qcolor("#D5F5E3" if memo["status"] == "Done" else "#FCF3CF"))

    def _show_selected_detail(self):
        memo = self._selected_memo()
        if not memo:
            self._clear_detail()
            return
        color = COLOR_MAP.get(memo["color"], "#4A90D9")
        self.detail_card.setStyleSheet(f"""
            QFrame {{
                background: white;
                border: 1px solid #D9E1EC;
                border-left: 7px solid {color};
                border-radius: 12px;
                padding: 12px;
            }}
        """)
        pin = "★ " if memo["is_pinned"] else ""
        self.detail_title.setText(f"{pin}{memo['title']}")
        due = memo["due_date"] or "No due date"
        self.detail_meta.setText(
            f"Category: {memo['category']}  |  Priority: {memo['priority']}  |  "
            f"Status: {memo['status']}  |  Due: {due}\n"
            f"Updated: {memo['updated_at']}"
        )
        self.detail_content.setPlainText(memo["content"] or "(No content)")

    def _clear_detail(self):
        self.detail_title.setText("No memo")
        self.detail_meta.setText("Create a memo to start capturing ideas, tasks, and reminders.")
        self.detail_content.clear()

    def _selected_memo(self) -> dict | None:
        row = self.memo_table.currentRow()
        if row < 0:
            return None
        item = self.memo_table.item(row, 7)
        if not item:
            return None
        memo_id = int(item.text())
        return next((memo for memo in self._memos if memo["id"] == memo_id), None)

    def _selected_memo_id(self) -> int | None:
        memo = self._selected_memo()
        return int(memo["id"]) if memo else None

    def _new_memo(self):
        dialog = MemoEditDialog(self)
        if dialog.exec():
            self.memo_service.create_memo(self.user_id, dialog.get_data())
            self._load_memos()

    def _edit_memo(self):
        memo = self._selected_memo()
        if not memo:
            QMessageBox.information(self, "No Memo", "Please select a memo first.")
            return
        dialog = MemoEditDialog(self, memo)
        if dialog.exec():
            self.memo_service.update_memo(memo["id"], dialog.get_data())
            self._load_memos()

    def _toggle_done(self):
        memo_id = self._selected_memo_id()
        if memo_id:
            self.memo_service.toggle_done(memo_id)
            self._load_memos()

    def _toggle_pin(self):
        memo_id = self._selected_memo_id()
        if memo_id:
            self.memo_service.toggle_pin(memo_id)
            self._load_memos()

    def _delete_memo(self):
        memo = self._selected_memo()
        if not memo:
            return
        reply = QMessageBox.question(
            self,
            "Delete Memo",
            f"Delete memo '{memo['title']}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.memo_service.delete_memo(memo["id"])
            self._load_memos()

    @staticmethod
    def _qcolor(hex_color: str):
        from PyQt6.QtGui import QColor

        return QColor(hex_color)


class MemoEditDialog(QDialog):
    """Create or edit a memo."""

    def __init__(self, parent=None, memo: dict | None = None):
        super().__init__(parent)
        self.memo = memo or {}
        self.setWindowTitle("Edit Memo" if memo else "New Memo")
        self.setMinimumSize(620, 560)
        self._init_ui()
        self._load_data()

    def _init_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(SectionLabel("Memo Editor"))

        form = QFormLayout()
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Memo title")
        self.category_combo = QComboBox()
        self.category_combo.addItems(CATEGORIES)
        self.priority_combo = QComboBox()
        self.priority_combo.addItems(PRIORITIES)
        self.status_combo = QComboBox()
        self.status_combo.addItems(STATUSES)
        self.color_combo = QComboBox()
        self.color_combo.addItems(COLORS)
        self.pinned_check = QCheckBox("Pin this memo")
        self.has_due_check = QCheckBox("Set due date")
        self.due_edit = QDateEdit()
        self.due_edit.setCalendarPopup(True)
        self.due_edit.setDate(QDate.currentDate())

        form.addRow("Title:", self.title_edit)
        form.addRow("Category:", self.category_combo)
        form.addRow("Priority:", self.priority_combo)
        form.addRow("Status:", self.status_combo)
        form.addRow("Color:", self.color_combo)
        form.addRow("Pinned:", self.pinned_check)
        form.addRow("Due Date:", self.has_due_check)
        form.addRow("", self.due_edit)
        layout.addLayout(form)

        layout.addWidget(QLabel("Content:"))
        self.content_edit = QTextEdit()
        self.content_edit.setPlaceholderText("Write ideas, reminders, meeting notes, deadlines, or next steps here.")
        layout.addWidget(self.content_edit, 1)

        btn_row = QHBoxLayout()
        save_btn = StyledButton("Save", "primary")
        save_btn.clicked.connect(self._save)
        cancel_btn = StyledButton("Cancel", "default")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(save_btn)
        btn_row.addWidget(cancel_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _load_data(self):
        if not self.memo:
            self.priority_combo.setCurrentText("Medium")
            self.color_combo.setCurrentText("Blue")
            return
        self.title_edit.setText(self.memo.get("title", ""))
        self.content_edit.setPlainText(self.memo.get("content", ""))
        self.category_combo.setCurrentText(self.memo.get("category", "Research"))
        self.priority_combo.setCurrentText(self.memo.get("priority", "Medium"))
        self.status_combo.setCurrentText(self.memo.get("status", "Open"))
        self.color_combo.setCurrentText(self.memo.get("color", "Blue"))
        self.pinned_check.setChecked(bool(self.memo.get("is_pinned")))
        due = self.memo.get("due_date", "")
        if due:
            self.has_due_check.setChecked(True)
            self.due_edit.setDate(QDate.fromString(due, "yyyy-MM-dd"))

    def _save(self):
        if not self.title_edit.text().strip():
            QMessageBox.warning(self, "Missing Title", "Please enter a memo title.")
            return
        self.accept()

    def get_data(self) -> dict:
        return {
            "title": self.title_edit.text().strip(),
            "content": self.content_edit.toPlainText().strip(),
            "category": self.category_combo.currentText(),
            "priority": self.priority_combo.currentText(),
            "status": self.status_combo.currentText(),
            "due_date": self.due_edit.date().toString("yyyy-MM-dd") if self.has_due_check.isChecked() else "",
            "color": self.color_combo.currentText(),
            "is_pinned": self.pinned_check.isChecked(),
        }
