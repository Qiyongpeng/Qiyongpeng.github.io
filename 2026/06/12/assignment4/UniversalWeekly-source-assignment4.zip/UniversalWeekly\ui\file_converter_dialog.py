"""General file converter dialog."""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTextEdit,
    QVBoxLayout,
)

from business.file_conversion_service import FileConversionService
from ui.common_widgets import SectionLabel, StyledButton


class FileConverterDialog(QDialog):
    """Convert common document, table, and image files."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("File Format Converter")
        self.setMinimumSize(760, 520)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(SectionLabel("File Format Converter"))

        description = QLabel(
            "Convert common research files without leaving UniversalWeekly. "
            "Supported groups: TXT/Markdown/Word/HTML/PDF/PPTX, CSV/Excel, and PNG/JPEG/BMP/WebP images."
        )
        description.setWordWrap(True)
        description.setStyleSheet("color: #5D6D7E; padding: 4px 0 10px 0;")
        layout.addWidget(description)

        form = QFormLayout()

        input_row = QHBoxLayout()
        self.input_edit = QLineEdit()
        self.input_edit.setPlaceholderText("Select a file to convert")
        browse_input_btn = StyledButton("Browse", "info")
        browse_input_btn.clicked.connect(self._browse_input)
        input_row.addWidget(self.input_edit, 1)
        input_row.addWidget(browse_input_btn)
        form.addRow("Input File:", input_row)

        self.target_combo = QComboBox()
        self.target_combo.currentTextChanged.connect(self._refresh_output_path)
        form.addRow("Target Format:", self.target_combo)

        output_row = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText("Choose or auto-generate an output path")
        browse_output_btn = StyledButton("Save As", "info")
        browse_output_btn.clicked.connect(self._browse_output)
        output_row.addWidget(self.output_edit, 1)
        output_row.addWidget(browse_output_btn)
        form.addRow("Output File:", output_row)

        layout.addLayout(form)

        btn_row = QHBoxLayout()
        convert_btn = StyledButton("Convert", "primary")
        convert_btn.clicked.connect(self._convert)
        clear_btn = StyledButton("Clear", "default")
        clear_btn.clicked.connect(self._clear)
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(convert_btn)
        btn_row.addWidget(clear_btn)
        btn_row.addWidget(close_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        layout.addWidget(QLabel("Status:"))
        self.status_edit = QTextEdit()
        self.status_edit.setReadOnly(True)
        self.status_edit.setPlaceholderText("Conversion status will appear here.")
        self.status_edit.setMinimumHeight(140)
        layout.addWidget(self.status_edit, 1)

        self.setLayout(layout)
        self._set_empty_targets()

    def _browse_input(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Input File",
            "",
            "Supported Files (*.txt *.md *.docx *.html *.htm *.csv *.xlsx *.png *.jpg *.jpeg *.bmp *.webp);;All Files (*)",
        )
        if path:
            self.input_edit.setText(path)
            self._update_target_formats()

    def _browse_output(self):
        target_ext = self._current_target_ext()
        if not target_ext:
            QMessageBox.information(self, "No Target Format", "Please choose an input file and target format first.")
            return
        filters = {
            ".txt": "Text File (*.txt)",
            ".md": "Markdown File (*.md)",
            ".docx": "Word Document (*.docx)",
            ".html": "HTML File (*.html)",
            ".xlsx": "Excel Workbook (*.xlsx)",
            ".csv": "CSV File (*.csv)",
            ".pdf": "PDF Document (*.pdf)",
            ".pptx": "PowerPoint Presentation (*.pptx)",
            ".png": "PNG Image (*.png)",
            ".jpg": "JPEG Image (*.jpg)",
            ".bmp": "BMP Image (*.bmp)",
            ".webp": "WebP Image (*.webp)",
        }
        default_path = self.output_edit.text() or self._suggest_output_path()
        path, _ = QFileDialog.getSaveFileName(self, "Choose Output File", default_path, filters.get(target_ext, "All Files (*)"))
        if path:
            if not path.lower().endswith(target_ext):
                path += target_ext
            self.output_edit.setText(path)

    def _update_target_formats(self):
        labels = FileConversionService.available_targets(self.input_edit.text())
        self.target_combo.blockSignals(True)
        self.target_combo.clear()
        if labels:
            self.target_combo.addItems(labels)
            self.target_combo.setEnabled(True)
        else:
            self._set_empty_targets(blocked=True)
        self.target_combo.blockSignals(False)
        self._refresh_output_path()

    def _set_empty_targets(self, blocked: bool = False):
        if not blocked:
            self.target_combo.clear()
        self.target_combo.addItem("No supported target format")
        self.target_combo.setEnabled(False)

    def _refresh_output_path(self):
        suggested = self._suggest_output_path()
        if suggested:
            self.output_edit.setText(suggested)

    def _suggest_output_path(self) -> str:
        input_path = self.input_edit.text().strip()
        target_ext = self._current_target_ext()
        if not input_path or not target_ext:
            return ""
        return FileConversionService.default_output_path(input_path, target_ext)

    def _current_target_ext(self) -> str:
        if not self.target_combo.isEnabled():
            return ""
        return FileConversionService.extension_from_label(self.target_combo.currentText())

    def _convert(self):
        input_path = self.input_edit.text().strip()
        output_path = self.output_edit.text().strip()
        if not input_path:
            QMessageBox.warning(self, "Missing Input", "Please select an input file.")
            return
        if not output_path:
            output_path = self._suggest_output_path()
            self.output_edit.setText(output_path)
        success, message = FileConversionService.convert(input_path, output_path)
        self.status_edit.setPlainText(message)
        if success:
            QMessageBox.information(self, "Conversion Complete", message)
        else:
            QMessageBox.warning(self, "Conversion Failed", message)

    def _clear(self):
        self.input_edit.clear()
        self.output_edit.clear()
        self.status_edit.clear()
        self.target_combo.clear()
        self._set_empty_targets()
