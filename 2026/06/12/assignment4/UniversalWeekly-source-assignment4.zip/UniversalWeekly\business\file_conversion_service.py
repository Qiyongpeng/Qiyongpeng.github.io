"""General file format conversion service."""

from __future__ import annotations

import csv
import html
import re
import shutil
from html.parser import HTMLParser
from pathlib import Path


class _HTMLTextExtractor(HTMLParser):
    """Small HTML-to-text helper used to avoid adding another dependency."""

    def __init__(self):
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str):
        text = data.strip()
        if text:
            self.parts.append(text)

    def get_text(self) -> str:
        return "\n".join(self.parts)


class FileConversionService:
    """Convert common research files between document, table, and image formats."""

    TEXT_INPUTS = {".txt", ".md", ".docx", ".html", ".htm"}
    TEXT_OUTPUTS = {".txt", ".md", ".docx", ".html"}
    TABLE_INPUTS = {".csv", ".xlsx"}
    TABLE_OUTPUTS = {".csv", ".xlsx"}
    IMAGE_INPUTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
    IMAGE_OUTPUTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
    PRESENTATION_OUTPUTS = {".pptx"}
    PDF_OUTPUTS = {".pdf"}

    FORMAT_LABELS = {
        ".txt": "Text (.txt)",
        ".md": "Markdown (.md)",
        ".docx": "Word Document (.docx)",
        ".html": "HTML (.html)",
        ".xlsx": "Excel Workbook (.xlsx)",
        ".csv": "CSV (.csv)",
        ".pdf": "PDF Document (.pdf)",
        ".pptx": "PowerPoint Presentation (.pptx)",
        ".png": "PNG Image (.png)",
        ".jpg": "JPEG Image (.jpg)",
        ".bmp": "BMP Image (.bmp)",
        ".webp": "WebP Image (.webp)",
    }

    @classmethod
    def available_targets(cls, input_path: str) -> list[str]:
        source = Path(input_path).suffix.lower()
        if source in cls.TEXT_INPUTS:
            targets = [".txt", ".md", ".docx", ".html", ".pdf", ".pptx"]
        elif source in cls.TABLE_INPUTS:
            targets = [".xlsx"] if source == ".csv" else [".csv"]
            targets.extend([".pdf", ".pptx"])
        elif source in cls.IMAGE_INPUTS:
            targets = [ext for ext in [".png", ".jpg", ".bmp", ".webp"] if ext != cls._normalize_image_ext(source)]
            targets.extend([".pdf", ".pptx"])
        else:
            targets = []
        targets = [ext for ext in targets if ext != source]
        return [cls.FORMAT_LABELS[ext] for ext in targets]

    @classmethod
    def extension_from_label(cls, label: str) -> str:
        match = re.search(r"\((\.[^)]+)\)", label)
        return match.group(1).lower() if match else ""

    @classmethod
    def default_output_path(cls, input_path: str, target_ext: str) -> str:
        source = Path(input_path)
        return str(source.with_name(f"{source.stem}_converted{target_ext}"))

    @classmethod
    def convert(cls, input_path: str, output_path: str) -> tuple[bool, str]:
        source = Path(input_path)
        target = Path(output_path)
        if not source.exists():
            return False, "Input file does not exist."
        if not target.suffix:
            return False, "Output file must include a target extension."

        input_ext = source.suffix.lower()
        output_ext = target.suffix.lower()
        if output_ext == ".jpeg":
            output_ext = ".jpg"

        target.parent.mkdir(parents=True, exist_ok=True)

        try:
            if input_ext == output_ext:
                shutil.copyfile(source, target)
            elif input_ext in cls.TEXT_INPUTS and output_ext in cls.TEXT_OUTPUTS:
                text = cls._read_document_text(source)
                cls._write_document_text(text, target, output_ext, input_ext)
            elif input_ext in cls.TABLE_INPUTS and output_ext in cls.TABLE_OUTPUTS:
                cls._convert_table(source, target, input_ext, output_ext)
            elif input_ext in cls.IMAGE_INPUTS and output_ext in cls.IMAGE_OUTPUTS:
                cls._convert_image(source, target, output_ext)
            elif output_ext == ".pdf":
                cls._convert_to_pdf(source, target, input_ext)
            elif output_ext == ".pptx":
                cls._convert_to_pptx(source, target, input_ext)
            else:
                return False, f"Unsupported conversion: {input_ext} -> {target.suffix.lower()}"
        except Exception as exc:
            return False, f"Conversion failed: {exc}"

        return True, f"Converted successfully:\n{target}"

    @classmethod
    def _read_document_text(cls, path: Path) -> str:
        ext = path.suffix.lower()
        if ext in {".txt", ".md"}:
            return path.read_text(encoding="utf-8", errors="ignore")
        if ext in {".html", ".htm"}:
            parser = _HTMLTextExtractor()
            parser.feed(path.read_text(encoding="utf-8", errors="ignore"))
            return parser.get_text()
        if ext == ".docx":
            from docx import Document

            doc = Document(str(path))
            return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        raise ValueError(f"Unsupported document input: {ext}")

    @classmethod
    def _write_document_text(cls, text: str, path: Path, output_ext: str, input_ext: str = ""):
        if output_ext in {".txt", ".md"}:
            path.write_text(text, encoding="utf-8")
            return
        if output_ext == ".html":
            if input_ext == ".md":
                import markdown

                body = markdown.markdown(text, extensions=["tables", "fenced_code"])
            else:
                body = html.escape(text).replace("\n", "<br>\n")
            html_doc = f"<!doctype html>\n<html><head><meta charset=\"utf-8\"></head><body>{body}</body></html>\n"
            path.write_text(html_doc, encoding="utf-8")
            return
        if output_ext == ".docx":
            from docx import Document

            doc = Document()
            for paragraph in text.splitlines():
                doc.add_paragraph(paragraph)
            doc.save(str(path))
            return
        raise ValueError(f"Unsupported document output: {output_ext}")

    @classmethod
    def _convert_table(cls, source: Path, target: Path, input_ext: str, output_ext: str):
        if input_ext == ".csv" and output_ext == ".xlsx":
            from openpyxl import Workbook

            wb = Workbook()
            ws = wb.active
            ws.title = source.stem[:31] or "Sheet1"
            with source.open("r", encoding="utf-8-sig", newline="") as f:
                for row in csv.reader(f):
                    ws.append(row)
            wb.save(str(target))
            return
        if input_ext == ".xlsx" and output_ext == ".csv":
            from openpyxl import load_workbook

            wb = load_workbook(str(source), read_only=True, data_only=True)
            ws = wb.active
            with target.open("w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                for row in ws.iter_rows(values_only=True):
                    writer.writerow(["" if value is None else value for value in row])
            wb.close()
            return
        raise ValueError(f"Unsupported table conversion: {input_ext} -> {output_ext}")

    @classmethod
    def _convert_to_pdf(cls, source: Path, target: Path, input_ext: str):
        if input_ext in cls.TEXT_INPUTS:
            text = cls._read_document_text(source)
            cls._write_text_pdf(text, target, source.stem)
            return
        if input_ext in cls.TABLE_INPUTS:
            rows = cls._read_table_rows(source)
            text = cls._table_to_plain_text(rows, max_rows=100, max_cols=8)
            cls._write_text_pdf(text, target, f"{source.stem} table preview")
            return
        if input_ext in cls.IMAGE_INPUTS:
            cls._write_image_pdf(source, target)
            return
        raise ValueError(f"Unsupported PDF conversion input: {input_ext}")

    @classmethod
    def _convert_to_pptx(cls, source: Path, target: Path, input_ext: str):
        if input_ext in cls.TEXT_INPUTS:
            text = cls._read_document_text(source)
            cls._write_text_pptx(text, target, source.stem)
            return
        if input_ext in cls.TABLE_INPUTS:
            rows = cls._read_table_rows(source)
            cls._write_table_pptx(rows, target, source.stem)
            return
        if input_ext in cls.IMAGE_INPUTS:
            cls._write_image_pptx(source, target, source.stem)
            return
        raise ValueError(f"Unsupported PowerPoint conversion input: {input_ext}")

    @classmethod
    def _read_table_rows(cls, path: Path) -> list[list[str]]:
        ext = path.suffix.lower()
        if ext == ".csv":
            with path.open("r", encoding="utf-8-sig", newline="") as f:
                return [[str(value) for value in row] for row in csv.reader(f)]
        if ext == ".xlsx":
            from openpyxl import load_workbook

            wb = load_workbook(str(path), read_only=True, data_only=True)
            ws = wb.active
            rows = [["" if value is None else str(value) for value in row] for row in ws.iter_rows(values_only=True)]
            wb.close()
            return rows
        raise ValueError(f"Unsupported table input: {ext}")

    @classmethod
    def _table_to_plain_text(cls, rows: list[list[str]], max_rows: int = 80, max_cols: int = 8) -> str:
        if not rows:
            return "No table data."
        clipped = [row[:max_cols] for row in rows[:max_rows]]
        widths = []
        for col_index in range(max(len(row) for row in clipped)):
            width = max(len(row[col_index]) if col_index < len(row) else 0 for row in clipped)
            widths.append(min(max(width, 6), 24))
        lines = []
        for row in clipped:
            cells = []
            for index, width in enumerate(widths):
                value = row[index] if index < len(row) else ""
                cells.append(value[:width].ljust(width))
            lines.append(" | ".join(cells))
        if len(rows) > max_rows:
            lines.append(f"... {len(rows) - max_rows} more rows omitted.")
        return "\n".join(lines)

    @classmethod
    def _write_text_pdf(cls, text: str, target: Path, title: str):
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        from reportlab.lib.units import inch

        font_name = cls._pdf_font_name()
        doc = SimpleDocTemplate(
            str(target),
            pagesize=A4,
            leftMargin=0.65 * inch,
            rightMargin=0.65 * inch,
            topMargin=0.65 * inch,
            bottomMargin=0.65 * inch,
        )
        styles = getSampleStyleSheet()
        title_style = styles["Title"]
        body_style = styles["BodyText"]
        title_style.fontName = font_name
        body_style.fontName = font_name
        body_style.fontSize = 10
        body_style.leading = 14

        story = [Paragraph(html.escape(title), title_style), Spacer(1, 0.2 * inch)]
        lines = text.splitlines() or ["No content."]
        for line in lines:
            if line.strip():
                story.append(Paragraph(html.escape(line), body_style))
            else:
                story.append(Spacer(1, 0.12 * inch))
        doc.build(story)

    @classmethod
    def _write_image_pdf(cls, source: Path, target: Path):
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.utils import ImageReader
        from reportlab.pdfgen import canvas
        from PIL import Image

        page_w, page_h = A4
        margin = 42
        with Image.open(str(source)) as image:
            width, height = image.size
        max_w = page_w - 2 * margin
        max_h = page_h - 2 * margin
        scale = min(max_w / width, max_h / height)
        draw_w = width * scale
        draw_h = height * scale
        x = (page_w - draw_w) / 2
        y = (page_h - draw_h) / 2

        pdf = canvas.Canvas(str(target), pagesize=A4)
        pdf.drawImage(ImageReader(str(source)), x, y, width=draw_w, height=draw_h, preserveAspectRatio=True, mask="auto")
        pdf.save()

    @classmethod
    def _write_text_pptx(cls, text: str, target: Path, title: str):
        from pptx import Presentation
        from pptx.util import Inches, Pt

        prs = Presentation()
        title_slide = prs.slides.add_slide(prs.slide_layouts[0])
        title_slide.shapes.title.text = title
        title_slide.placeholders[1].text = "Converted by UniversalWeekly"

        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if not lines:
            lines = ["No content."]
        for index, chunk in enumerate(cls._chunks(lines, 8), start=1):
            slide = prs.slides.add_slide(prs.slide_layouts[1])
            slide.shapes.title.text = f"Content {index}"
            body = slide.shapes.placeholders[1].text_frame
            body.clear()
            for line in chunk:
                para = body.add_paragraph()
                para.text = line[:220]
                para.font.size = Pt(18)
                para.level = 0
        prs.save(str(target))

    @classmethod
    def _write_table_pptx(cls, rows: list[list[str]], target: Path, title: str):
        from pptx import Presentation
        from pptx.util import Inches, Pt

        prs = Presentation()
        title_slide = prs.slides.add_slide(prs.slide_layouts[0])
        title_slide.shapes.title.text = title
        title_slide.placeholders[1].text = "Table converted by UniversalWeekly"

        if not rows:
            rows = [["No data"]]
        max_cols = min(max(len(row) for row in rows), 6)
        header = rows[0][:max_cols]
        body_rows = rows[1:] if len(rows) > 1 else []
        for slide_index, chunk in enumerate(cls._chunks(body_rows[:60], 10), start=1):
            slide = prs.slides.add_slide(prs.slide_layouts[5])
            slide.shapes.title.text = f"Table Preview {slide_index}"
            table_rows = [header] + [row[:max_cols] for row in chunk]
            table = slide.shapes.add_table(
                len(table_rows),
                max_cols,
                Inches(0.45),
                Inches(1.35),
                Inches(9.1),
                Inches(4.9),
            ).table
            for row_index, row in enumerate(table_rows):
                for col_index in range(max_cols):
                    cell = table.cell(row_index, col_index)
                    cell.text = (row[col_index] if col_index < len(row) else "")[:55]
                    for paragraph in cell.text_frame.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(9)
        prs.save(str(target))

    @classmethod
    def _write_image_pptx(cls, source: Path, target: Path, title: str):
        from pptx import Presentation
        from pptx.util import Inches
        from PIL import Image

        prs = Presentation()
        slide = prs.slides.add_slide(prs.slide_layouts[5])
        slide.shapes.title.text = title
        with Image.open(str(source)) as image:
            width, height = image.size
        max_w = 8.8
        max_h = 5.2
        scale = min(max_w / width, max_h / height)
        draw_w = width * scale
        draw_h = height * scale
        left = (10 - draw_w) / 2
        top = 1.35 + (5.2 - draw_h) / 2
        slide.shapes.add_picture(str(source), Inches(left), Inches(top), width=Inches(draw_w), height=Inches(draw_h))
        prs.save(str(target))

    @classmethod
    def _convert_image(cls, source: Path, target: Path, output_ext: str):
        from PIL import Image

        with Image.open(str(source)) as image:
            if output_ext in {".jpg", ".jpeg"} and image.mode not in {"RGB", "L"}:
                image = image.convert("RGB")
            format_name = {
                ".jpg": "JPEG",
                ".jpeg": "JPEG",
                ".png": "PNG",
                ".bmp": "BMP",
                ".webp": "WEBP",
            }[output_ext]
            image.save(str(target), format=format_name)

    @classmethod
    def _pdf_font_name(cls) -> str:
        try:
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.cidfonts import UnicodeCIDFont

            if "STSong-Light" not in pdfmetrics.getRegisteredFontNames():
                pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
            return "STSong-Light"
        except Exception:
            return "Helvetica"

    @staticmethod
    def _chunks(values: list, size: int):
        for index in range(0, len(values), size):
            yield values[index:index + size]

    @staticmethod
    def _normalize_image_ext(ext: str) -> str:
        return ".jpg" if ext == ".jpeg" else ext
