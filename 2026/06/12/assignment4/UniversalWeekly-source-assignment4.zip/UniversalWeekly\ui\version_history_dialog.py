"""Version history dialog based on report timestamps and operation logs."""

from __future__ import annotations

from PyQt6.QtWidgets import QDialog, QLabel, QVBoxLayout

from database.db_manager import DatabaseManager
from ui.common_widgets import ReadOnlyTable, StyledButton


class VersionHistoryDialog(QDialog):
    """Show a lightweight version history for a weekly report."""

    def __init__(self, db: DatabaseManager, user_id: int, report_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.user_id = user_id
        self.report_id = report_id
        self._init_ui()
        self._load_versions()

    def _init_ui(self):
        self.setWindowTitle("Version History")
        self.setMinimumSize(780, 500)
        self.setStyleSheet("QDialog { background: #F8FAFC; } QLabel { color: #0F172A; }")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        title = QLabel("Version History")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        subtitle = QLabel("Lightweight history generated from report timestamps and operation logs.")
        subtitle.setStyleSheet("color: #64748B;")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        self.table = ReadOnlyTable(["Version", "Time", "Action", "Details"])
        layout.addWidget(self.table, 1)

        close_btn = StyledButton("Close", "primary")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _load_versions(self):
        self.table.clear_all()
        report = self.db.get_report(self.report_id)
        if not report:
            self.table.add_row(["-", "-", "Not found", "Report not found."])
            return

        rows = [
            ["V1", report.created_at, "Draft created", f"Week {report.week_number} report created."],
        ]
        if report.updated_at and report.updated_at != report.created_at:
            rows.append(["V2", report.updated_at, "Content updated", f"Current status: {report.status}."])

        logs = self.db.get_operation_logs(user_id=self.user_id, limit=100)
        week_token = f"week {report.week_number}".lower()
        matched_logs = [
            log for log in logs
            if week_token in (log.description or "").lower()
            or str(self.report_id) in (log.description or "")
        ]
        for log in matched_logs:
            rows.append(["", log.created_at, log.operation_type, log.description])

        rows = sorted(rows, key=lambda row: row[1] or "", reverse=True)
        for index, row in enumerate(rows, start=1):
            version = row[0] or f"V{index}"
            self.table.add_row([version, row[1], row[2], row[3]])
