#!/usr/bin/env python3
"""
UniversalWeekly - Dual-Role Weekly Report Management System
==========================================================
A PyQt6 application for managing weekly reports with student and teacher interfaces.

Features:
- Dual-role (student/teacher) login and permission management
- Weekly report creation, editing, submission
- Task management with categories, progress tracking, tags
- Problem recording and reflection
- Next-week planning with carry-over
- Teacher commenting (single and batch)
- Statistics and data visualization
- Multi-format export (Markdown, Word, Text, Excel)
- Template system for reports and comments
- Data backup and restore
"""

import sys
import os

# Ensure the application root is in the Python path
_app_root = os.path.dirname(os.path.abspath(__file__))
if _app_root not in sys.path:
    sys.path.insert(0, _app_root)

from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

from database.db_manager import DatabaseManager
from business.auth_service import AuthService
from ui.login_window import LoginWindow
from ui.student_main import StudentMainWindow
from ui.teacher_main import TeacherMainWindow


class Application:
    """Main application controller managing windows and state."""

    def __init__(self):
        self.db = DatabaseManager()
        self.auth = AuthService(self.db)
        self.login_window: LoginWindow = None
        self.main_window = None

    def run(self):
        """Start the application."""
        self._show_login()

    def _show_login(self):
        """Display the login/registration window."""
        if self.main_window:
            self.main_window.close()
            self.main_window = None
        self.login_window = LoginWindow(self.db)
        self.login_window.login_successful.connect(self._on_login_success)
        self.login_window.show()

    def _on_login_success(self, auth_service, is_teacher):
        """Handle successful login - open the appropriate main window."""
        self.login_window.close()
        if is_teacher:
            self.main_window = TeacherMainWindow(self.db, auth_service)
        else:
            self.main_window = StudentMainWindow(self.db, auth_service)

        self.main_window.logout_requested.connect(self._on_logout)
        self.main_window.show()

    def _on_logout(self):
        """Handle logout - return to login screen."""
        if self.main_window:
            self.main_window.close()
            self.main_window = None
        self._show_login()


def main():
    """Application entry point."""
    # Enable High DPI support
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("UniversalWeekly")
    app.setOrganizationName("UniversalWeekly")

    # Set default font
    font = QFont("Segoe UI", 10)
    app.setFont(font)

    # Load stylesheet
    qss_path = os.path.join(_app_root, "resources", "styles.qss")
    if os.path.exists(qss_path):
        with open(qss_path, "r", encoding="utf-8") as f:
            app.setStyleSheet(f.read())

    # Create demo data if needed
    _ensure_demo_data()

    # Start application
    application = Application()
    application.run()

    sys.exit(app.exec())


def _ensure_demo_data():
    """Create demo accounts if they don't exist."""
    db = DatabaseManager()

    # Check if demo accounts exist
    existing = db.authenticate("student1", "123456")
    if existing:
        return

    # Create demo student
    db.register_user(
        username="student1",
        password="123456",
        role="student",
        display_name="Alice Wang",
        student_id="ST2024001",
        class_name="CS2024-A",
        email="alice@example.com"
    )

    # Create demo teacher
    db.register_user(
        username="teacher1",
        password="123456",
        role="teacher",
        display_name="Dr. Chen",
        student_id="TC2024001",
        class_name="CS2024-A",
        email="chen@example.com"
    )

    # Create a second demo student
    db.register_user(
        username="student2",
        password="123456",
        role="student",
        display_name="Bob Li",
        student_id="ST2024002",
        class_name="CS2024-A",
    )

    print("[Demo] Demo accounts created: student1/123456, teacher1/123456")


if __name__ == "__main__":
    main()
