"""Reference converter dialog."""

from __future__ import annotations

from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTextEdit,
    QVBoxLayout,
)

from business.reference_service import ReferenceFormatter, ReferenceItem
from ui.common_widgets import SectionLabel, StyledButton


class ReferenceConverterDialog(QDialog):
    """Convert bibliographic fields into common citation formats."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Reference Format Converter")
        self.setMinimumSize(820, 640)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout()

        layout.addWidget(SectionLabel("Reference Format Converter"))
        help_label = QLabel(
            "Enter one paper's bibliographic information, choose a target format, "
            "then generate a formatted reference for reports and assignments."
        )
        help_label.setWordWrap(True)
        help_label.setStyleSheet("color: #5D6D7E; padding: 4px 0 10px 0;")
        layout.addWidget(help_label)

        form = QFormLayout()
        self.authors_edit = QLineEdit()
        self.authors_edit.setPlaceholderText("Example: John Smith; Li Wang; Maria Garcia")
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Paper title")
        self.venue_edit = QLineEdit()
        self.venue_edit.setPlaceholderText("Journal or conference name")
        self.year_edit = QLineEdit()
        self.year_edit.setPlaceholderText("2026")
        self.volume_edit = QLineEdit()
        self.volume_edit.setPlaceholderText("Volume")
        self.issue_edit = QLineEdit()
        self.issue_edit.setPlaceholderText("Issue")
        self.pages_edit = QLineEdit()
        self.pages_edit.setPlaceholderText("1-15")
        self.doi_edit = QLineEdit()
        self.doi_edit.setPlaceholderText("10.xxxx/xxxxx")
        self.format_combo = QComboBox()
        self.format_combo.addItems(["All Formats", "APA 7th", "IEEE", "GB/T 7714", "BibTeX"])

        form.addRow("Authors:", self.authors_edit)
        form.addRow("Title:", self.title_edit)
        form.addRow("Journal / Venue:", self.venue_edit)
        form.addRow("Year:", self.year_edit)
        form.addRow("Volume:", self.volume_edit)
        form.addRow("Issue:", self.issue_edit)
        form.addRow("Pages:", self.pages_edit)
        form.addRow("DOI:", self.doi_edit)
        form.addRow("Output Format:", self.format_combo)
        layout.addLayout(form)

        btn_row = QHBoxLayout()
        convert_btn = StyledButton("Convert", "primary")
        convert_btn.clicked.connect(self._convert)
        sample_btn = StyledButton("Load Sample", "info")
        sample_btn.clicked.connect(self._load_sample)
        copy_btn = StyledButton("Copy Result", "success")
        copy_btn.clicked.connect(self._copy_result)
        save_btn = StyledButton("Save as TXT", "info")
        save_btn.clicked.connect(self._save_result)
        clear_btn = StyledButton("Clear", "default")
        clear_btn.clicked.connect(self._clear)
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)

        for button in [convert_btn, sample_btn, copy_btn, save_btn, clear_btn, close_btn]:
            btn_row.addWidget(button)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        layout.addWidget(QLabel("Formatted Reference:"))
        self.output_edit = QTextEdit()
        self.output_edit.setPlaceholderText("Generated citation text will appear here.")
        self.output_edit.setMinimumHeight(220)
        layout.addWidget(self.output_edit, 1)

        self.setLayout(layout)

    def _collect_item(self) -> ReferenceItem:
        return ReferenceItem(
            authors=self.authors_edit.text(),
            title=self.title_edit.text(),
            venue=self.venue_edit.text(),
            year=self.year_edit.text(),
            volume=self.volume_edit.text(),
            issue=self.issue_edit.text(),
            pages=self.pages_edit.text(),
            doi=self.doi_edit.text(),
        )

    def _convert(self):
        item = self._collect_item()
        if not item.title.strip():
            QMessageBox.warning(self, "Missing Title", "Please enter at least the paper title.")
            return
        fmt = self.format_combo.currentText()
        if fmt == "All Formats":
            results = ReferenceFormatter.format_all(item)
            text = "\n\n".join(f"[{name}]\n{value}" for name, value in results.items())
        else:
            text = ReferenceFormatter.format_all(item)[fmt]
        self.output_edit.setPlainText(text)

    def _load_sample(self):
        self.authors_edit.setText("John Smith; Li Wang; Maria Garcia")
        self.title_edit.setText("Digital twin-driven fault diagnosis for rotating machinery")
        self.venue_edit.setText("Mechanical Systems and Signal Processing")
        self.year_edit.setText("2026")
        self.volume_edit.setText("210")
        self.issue_edit.setText("1")
        self.pages_edit.setText("1-15")
        self.doi_edit.setText("10.1016/j.ymssp.2026.100001")
        self.format_combo.setCurrentText("All Formats")
        self._convert()

    def _copy_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please convert a reference first.")
            return
        QApplication.clipboard().setText(text)
        QMessageBox.information(self, "Copied", "Formatted reference copied to clipboard.")

    def _save_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please convert a reference first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save Reference", "reference.txt", "Text File (*.txt)")
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        QMessageBox.information(self, "Saved", f"Reference saved to:\n{path}")

    def _clear(self):
        for widget in [
            self.authors_edit,
            self.title_edit,
            self.venue_edit,
            self.year_edit,
            self.volume_edit,
            self.issue_edit,
            self.pages_edit,
            self.doi_edit,
        ]:
            widget.clear()
        self.output_edit.clear()
