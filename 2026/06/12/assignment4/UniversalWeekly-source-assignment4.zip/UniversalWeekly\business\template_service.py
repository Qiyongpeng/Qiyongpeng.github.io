"""Template management service."""

import json
from typing import List, Optional, Tuple
from database.db_manager import DatabaseManager
from database.models import Template


class TemplateService:
    """Handle report templates, comment templates, and sharing."""

    CATEGORY_OPTIONS = ["study", "homework", "project", "club", "personal", "other"]
    PROBLEM_TYPE_OPTIONS = ["time_management", "difficulty", "resource", "other"]

    def __init__(self, db: DatabaseManager):
        self.db = db

    def get_system_templates(self, template_type: str = "report") -> List[Template]:
        return self.db.get_templates(user_id=None, template_type=template_type)

    def get_user_templates(self, user_id: int, template_type: str = "report") -> List[Template]:
        return self.db.get_templates(user_id, template_type)

    def get_all_available_templates(self, user_id: int, template_type: str = "report") -> List[Template]:
        return self.db.get_templates(user_id, template_type)

    def save_template(self, user_id: Optional[int], name: str,
                      template_type: str, content: dict, is_shared: bool = False) -> Optional[int]:
        template = Template(
            user_id=user_id,
            name=name,
            template_type=template_type,
            content=json.dumps(content, ensure_ascii=False),
            is_shared=is_shared,
        )
        return self.db.add_template(template)

    def delete_template(self, template_id: int) -> bool:
        return self.db.delete_template(template_id)

    def create_default_report_template(self, user_id: int) -> int:
        """Create a default report template for a student."""
        content = {
            "tasks": [
                {"category": "study", "name": "Course study and review", "description": ""},
                {"category": "homework", "name": "Complete course assignments", "description": ""},
            ],
            "plans": [
                {"category": "study", "name": "Preview next week's courses", "description": ""},
            ],
        }
        tid = self.save_template(user_id, "Default Study Template", "report", content)
        return tid or 0

    def create_default_comment_template(self, teacher_id: int) -> int:
        """Create a default comment template for a teacher."""
        content = {
            "templates": [
                "Good progress this week. Keep up the good work!",
                "Task completion rate needs improvement. Please plan your time better.",
                "The next-week plan is not detailed enough. Please add specific goals.",
                "Good reflection on problems. Try to propose concrete solutions.",
            ]
        }
        tid = self.save_template(teacher_id, "Default Comment Template", "comment", content)
        return tid or 0

    @staticmethod
    def get_category_label(category: str) -> str:
        labels = {
            "study": "Study Task",
            "homework": "Homework",
            "project": "Project Task",
            "club": "Club Activity",
            "personal": "Personal Task",
            "other": "Other",
        }
        return labels.get(category, category)

    @staticmethod
    def get_problem_type_label(ptype: str) -> str:
        labels = {
            "time_management": "Time Management",
            "difficulty": "Task Difficulty",
            "resource": "Resource Shortage",
            "other": "Other",
        }
        return labels.get(ptype, ptype)

    @staticmethod
    def get_status_label(status: str) -> str:
        labels = {
            "not_started": "Not Started",
            "in_progress": "In Progress",
            "completed": "Completed",
            "delayed": "Delayed",
        }
        return labels.get(status, status)
