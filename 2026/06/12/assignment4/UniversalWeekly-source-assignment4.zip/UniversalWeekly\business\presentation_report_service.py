"""Generate date-limited presentation drafts from weekly reports."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any

from business.local_llm_service import LocalLLMService
from database.db_manager import DatabaseManager
from database.models import WeeklyReport


PRESENTATION_ENGINE_OPTIONS = [
    "Local LLM (Ollama)",
    "Local LLM (OpenAI-compatible)",
    "Offline Template",
]


class PresentationReportService:
    """Find a weekly report by date and generate a speech draft."""

    @classmethod
    def find_report_by_date(cls, db: DatabaseManager, user_id: int, selected_date: str) -> WeeklyReport | None:
        try:
            target = datetime.strptime(selected_date, "%Y-%m-%d").date()
        except ValueError:
            return None
        for report in db.get_reports_by_user(user_id):
            try:
                start = datetime.strptime(report.start_date, "%Y-%m-%d").date()
                end = datetime.strptime(report.end_date, "%Y-%m-%d").date()
            except ValueError:
                continue
            if start <= target <= end:
                return report
        return None

    @classmethod
    def build_context(cls, db: DatabaseManager, report: WeeklyReport) -> dict[str, Any]:
        tasks = db.get_tasks_by_report(report.id, is_plan=False) if report.id else []
        plans = db.get_tasks_by_report(report.id, is_plan=True) if report.id else []
        problems = db.get_problems_by_report(report.id) if report.id else []
        return {
            "report": {
                "id": report.id,
                "week_number": report.week_number,
                "period": f"{report.start_date} ~ {report.end_date}",
                "status": report.status,
                "highlights": report.highlights,
                "shortcomings": report.shortcomings,
                "improvements": report.improvements,
                "next_plan_summary": report.next_plan_summary,
            },
            "tasks": [
                {
                    "category": item.category,
                    "name": item.name,
                    "description": item.description,
                    "status": item.status,
                    "progress": item.progress,
                    "result": item.result,
                    "tags": item.tags,
                }
                for item in tasks
            ],
            "problems": [
                {
                    "description": item.description,
                    "problem_type": item.problem_type,
                    "attempted_solution": item.attempted_solution,
                    "unresolved_reason": item.unresolved_reason,
                }
                for item in problems
            ],
            "plans": [
                {
                    "category": item.category,
                    "name": item.name,
                    "description": item.description,
                    "tags": item.tags,
                }
                for item in plans
            ],
        }

    @classmethod
    def generate_presentation(
        cls,
        context: dict[str, Any],
        target_count: int,
        engine_label: str = "Local LLM (Ollama)",
        endpoint: str = "",
        model: str = "",
    ) -> tuple[bool, str, str]:
        target_count = max(80, min(int(target_count or 600), 5000))
        if engine_label == "Offline Template":
            return True, cls._offline_generate(context, target_count), "Offline Template"

        provider = "Ollama" if engine_label == "Local LLM (Ollama)" else "OpenAI-compatible"
        prompt = cls._build_prompt(context, target_count)
        try:
            if provider == "Ollama":
                text = LocalLLMService._call_ollama(
                    endpoint or LocalLLMService.DEFAULT_OLLAMA_URL,
                    model or LocalLLMService.DEFAULT_MODEL,
                    prompt,
                )
                engine = f"Ollama / {model or LocalLLMService.DEFAULT_MODEL}"
            else:
                text = LocalLLMService._call_openai_compatible(
                    endpoint or LocalLLMService.DEFAULT_OPENAI_COMPAT_URL,
                    model or "local-model",
                    prompt,
                )
                engine = f"OpenAI-compatible / {model or 'local-model'}"
            cleaned = cls._clean_output(text)
            if not cls._is_grounded_in_report(cleaned, context):
                fallback = cls._offline_generate(context, target_count)
                return True, fallback, f"Strict Report Template fallback ({engine} ignored report content)"
            return True, cleaned, engine
        except Exception as exc:
            fallback = cls._offline_generate(context, target_count)
            fallback += f"\n\n注：本地大模型调用失败，已使用离线模板兜底。原因：{exc}"
            return True, fallback, "Offline Template fallback"

    @staticmethod
    def _build_prompt(context: dict[str, Any], target_count: int) -> str:
        return f"""
你是一个研究生日常周报汇报稿写作助手。请根据给定周报内容，生成一份中文口头汇报稿。

要求：
1. 严格依据周报内容写，不要编造周报中没有的课程、项目、数据或成果。
2. 字数控制在约 {target_count} 个中文字符，允许上下浮动 15%。
3. 适合 1 人口头汇报，语气自然、正式、清楚。
4. 结构包括：本周完成工作、遇到的问题与反思、改进措施、下周计划。
5. 不要输出 Markdown 标题，不要列项目符号，直接输出连贯汇报稿。
6. 必须覆盖周报中的具体任务名称、问题描述和下周计划；禁止写周报数据中没有出现的主题。
7. 如果周报中没有“数据结构、算法、课程学习”等内容，就绝对不要提到这些内容。

周报数据：
{context}
""".strip()

    @classmethod
    def _offline_generate(cls, context: dict[str, Any], target_count: int) -> str:
        report = context.get("report", {})
        tasks = context.get("tasks", [])
        problems = context.get("problems", [])
        plans = context.get("plans", [])

        task_text = cls._join_items(
            [f"{item.get('name', '')}（进度{item.get('progress', 0)}%）" for item in tasks if item.get("name")]
        )
        problem_text = cls._join_items([item.get("description", "") for item in problems if item.get("description")])
        plan_text = cls._join_items([item.get("name", "") for item in plans if item.get("name")])

        paragraphs = [
            f"各位老师好，我汇报的是第 {report.get('week_number', '')} 周周报，时间范围为 {report.get('period', '')}。",
            f"本周主要完成的工作包括：{task_text or report.get('highlights') or '对本周学习和科研任务进行了整理与推进'}。"
            f"{report.get('highlights') or ''}",
            f"在推进过程中，主要问题集中在：{problem_text or report.get('shortcomings') or '时间安排、资料整理和阶段复盘仍需加强'}。"
            f"{report.get('shortcomings') or ''}",
            f"针对这些问题，我后续会按照任务优先级细化计划，补充过程记录和结果证据，并定期复盘。{report.get('improvements') or ''}",
            f"下周计划重点推进：{plan_text or report.get('next_plan_summary') or '继续完善未完成任务并形成阶段成果'}。"
            f"{report.get('next_plan_summary') or ''}",
        ]
        text = "\n\n".join(part.strip() for part in paragraphs if part.strip())
        return cls._fit_length(text, target_count)

    @staticmethod
    def _join_items(items: list[str], limit: int = 5) -> str:
        cleaned = [item.strip() for item in items if item and item.strip()]
        return "、".join(cleaned[:limit])

    @staticmethod
    def _fit_length(text: str, target_count: int) -> str:
        text = text.strip()
        upper = int(target_count * 1.25)
        if len(text) <= upper:
            return text
        clipped = text[:upper]
        last_punc = max(clipped.rfind("。"), clipped.rfind("；"), clipped.rfind("，"))
        if last_punc > target_count * 0.7:
            return clipped[: last_punc + 1]
        return clipped.rstrip("，；、") + "。"

    @staticmethod
    def _clean_output(text: str) -> str:
        text = (text or "").strip()
        for prefix in ["```text", "```markdown", "```"]:
            if text.startswith(prefix):
                text = text[len(prefix):].strip()
        if text.endswith("```"):
            text = text[:-3].strip()
        return text

    @classmethod
    def _is_grounded_in_report(cls, text: str, context: dict[str, Any]) -> bool:
        phrases = cls._report_phrases(context)
        if not phrases:
            return True
        covered = [phrase for phrase in phrases if cls._mentions_phrase(text, phrase)]
        required = max(1, min(len(phrases), round(len(phrases) * 0.35)))
        return len(covered) >= required

    @staticmethod
    def _report_phrases(context: dict[str, Any]) -> list[str]:
        phrases: list[str] = []
        report = context.get("report", {})
        for key in ["highlights", "shortcomings", "improvements", "next_plan_summary"]:
            value = str(report.get(key, "")).strip()
            if value:
                phrases.extend(part.strip() for part in re.split(r"[。；;，,\n]+", value) if len(part.strip()) >= 4)
        for item in context.get("tasks", []):
            name = str(item.get("name", "")).strip()
            if len(name) >= 4:
                phrases.append(name)
        for item in context.get("problems", []):
            desc = str(item.get("description", "")).strip()
            if len(desc) >= 4:
                phrases.append(desc)
        for item in context.get("plans", []):
            name = str(item.get("name", "")).strip()
            if len(name) >= 4:
                phrases.append(name)
        return phrases[:12]

    @staticmethod
    def _mentions_phrase(text: str, phrase: str) -> bool:
        text_norm = re.sub(r"\s+", "", text.lower())
        phrase_norm = re.sub(r"\s+", "", phrase.lower())
        if phrase_norm in text_norm:
            return True
        tokens = [token for token in re.split(r"[\s,，;；、/|_-]+", phrase.lower()) if len(token) >= 2]
        if not tokens:
            return False
        hits = sum(1 for token in tokens if token in text.lower())
        return hits >= max(1, round(len(tokens) * 0.6))
