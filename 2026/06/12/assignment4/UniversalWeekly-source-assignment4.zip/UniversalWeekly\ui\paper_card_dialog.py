"""Paper reading card generator dialog."""

from __future__ import annotations

from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTextEdit,
    QVBoxLayout,
)

from business.local_llm_service import LocalLLMService
from business.paper_card_service import PAPER_CARD_ENGINE_OPTIONS, PaperCardService
from ui.common_widgets import SectionLabel, StyledButton


class PaperCardDialog(QDialog):
    """Generate a Chinese academic paper reading card from title and abstract."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Paper Reading Card")
        self.setMinimumSize(900, 720)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout()
        layout.addWidget(SectionLabel("Paper Reading Card Generator"))

        description = QLabel(
            "Paste a paper title and abstract, then generate a structured Chinese reading card with one click."
        )
        description.setWordWrap(True)
        description.setStyleSheet("color: #5D6D7E; padding: 4px 0 10px 0;")
        layout.addWidget(description)

        form = QFormLayout()
        self.engine_combo = QComboBox()
        self.engine_combo.addItems(PAPER_CARD_ENGINE_OPTIONS)
        self.engine_combo.setCurrentText("Local LLM (Ollama)")
        self.engine_combo.currentTextChanged.connect(self._update_engine_defaults)

        self.endpoint_edit = QLineEdit(LocalLLMService.DEFAULT_OLLAMA_URL)
        self.model_edit = QComboBox()
        self.model_edit.setEditable(True)
        self.model_edit.addItems(LocalLLMService.model_options())
        self.model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
        self.model_edit.lineEdit().setPlaceholderText("Example: qwen2.5:7b")

        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Paste paper title here.")
        form.addRow("Engine:", self.engine_combo)
        form.addRow("Local Endpoint:", self.endpoint_edit)
        form.addRow("Local Model:", self.model_edit)
        form.addRow("Paper Title:", self.title_edit)
        layout.addLayout(form)

        io_layout = QHBoxLayout()
        input_col = QVBoxLayout()
        output_col = QVBoxLayout()

        input_col.addWidget(QLabel("Abstract:"))
        self.abstract_edit = QTextEdit()
        self.abstract_edit.setPlaceholderText("Paste paper abstract here.")
        input_col.addWidget(self.abstract_edit, 1)

        output_col.addWidget(QLabel("Reading Card:"))
        self.output_edit = QTextEdit()
        self.output_edit.setReadOnly(True)
        self.output_edit.setPlaceholderText(
            "Research Problem:\nResearch Method:\nExperimental Object:\nMain Conclusions:\nInnovation:\nLimitations:\nCitation Value:"
        )
        output_col.addWidget(self.output_edit, 1)

        io_layout.addLayout(input_col, 1)
        io_layout.addLayout(output_col, 1)
        layout.addLayout(io_layout, 1)

        self.status_label = QLabel("Engine: ready")
        self.status_label.setStyleSheet("color: #5D6D7E; padding-top: 4px;")
        layout.addWidget(self.status_label)

        btn_row = QHBoxLayout()
        generate_btn = StyledButton("Generate Card", "primary")
        generate_btn.clicked.connect(self._generate_card)
        test_btn = StyledButton("Test Local Model", "default")
        test_btn.clicked.connect(self._test_local_model)
        sample_btn = StyledButton("Load Sample", "info")
        sample_btn.clicked.connect(self._load_sample)
        copy_btn = StyledButton("Copy Result", "success")
        copy_btn.clicked.connect(self._copy_result)
        save_btn = StyledButton("Save Result", "info")
        save_btn.clicked.connect(self._save_result)
        clear_btn = StyledButton("Clear", "default")
        clear_btn.clicked.connect(self._clear)
        close_btn = StyledButton("Close", "default")
        close_btn.clicked.connect(self.accept)

        for button in [generate_btn, test_btn, sample_btn, copy_btn, save_btn, clear_btn, close_btn]:
            btn_row.addWidget(button)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.setLayout(layout)
        self._update_engine_defaults(self.engine_combo.currentText())

    def _update_engine_defaults(self, engine: str):
        if engine == "Local LLM (Ollama)":
            self.endpoint_edit.setText(LocalLLMService.DEFAULT_OLLAMA_URL)
            self.model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
            self.endpoint_edit.setEnabled(True)
            self.model_edit.setEnabled(True)
        elif engine == "Local LLM (OpenAI-compatible)":
            self.endpoint_edit.setText(LocalLLMService.DEFAULT_OPENAI_COMPAT_URL)
            self.model_edit.setCurrentText("local-model")
            self.endpoint_edit.setEnabled(True)
            self.model_edit.setEnabled(True)
        else:
            self.endpoint_edit.clear()
            self.model_edit.setCurrentText("")
            self.endpoint_edit.setEnabled(False)
            self.model_edit.setEnabled(False)

    def _generate_card(self):
        ok, result, engine = PaperCardService.generate_card(
            self.title_edit.text(),
            self.abstract_edit.toPlainText(),
            self.engine_combo.currentText(),
            self.endpoint_edit.text().strip(),
            self.model_edit.currentText().strip(),
        )
        self.output_edit.setPlainText(result)
        self.status_label.setText(f"Engine: {engine}")
        if not ok:
            QMessageBox.warning(self, "Generation Failed", result)

    def _test_local_model(self):
        engine = self.engine_combo.currentText()
        if engine == "Offline Template":
            QMessageBox.information(self, "Local Model", "Offline Template does not need a local model.")
            return
        provider = "Ollama" if engine == "Local LLM (Ollama)" else "OpenAI-compatible"
        ok, message = LocalLLMService.test_connection(
            provider,
            self.endpoint_edit.text().strip(),
            self.model_edit.currentText().strip(),
        )
        self.status_label.setText(message)
        if ok:
            QMessageBox.information(self, "Local Model", message)
        else:
            QMessageBox.warning(self, "Local Model", message)

    def _load_sample(self):
        self.engine_combo.setCurrentText("Local LLM (Ollama)")
        self.title_edit.setText("Digital twin-driven fault diagnosis method for rolling bearings")
        self.abstract_edit.setPlainText(
            "This paper proposes a digital twin-driven fault diagnosis method for rolling bearings. "
            "However, existing data-driven methods still suffer from domain gap under variable working conditions. "
            "Experimental results show that the proposed framework improves classification accuracy and robustness."
        )

    def _copy_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please generate a reading card first.")
            return
        QApplication.clipboard().setText(text)
        QMessageBox.information(self, "Copied", "Reading card copied to clipboard.")

    def _save_result(self):
        text = self.output_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "No Output", "Please generate a reading card first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save Reading Card", "paper_reading_card.txt", "Text File (*.txt)")
        if not path:
            return
        Path(path).write_text(text, encoding="utf-8")
        QMessageBox.information(self, "Saved", f"Reading card saved to:\n{path}")

    def _clear(self):
        self.title_edit.clear()
        self.abstract_edit.clear()
        self.output_edit.clear()
        self.status_label.setText("Engine: ready")
