"""Memo management service."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from database.db_manager import DatabaseManager


class MemoService:
    """Store and query personal memos for students and teachers."""

    def __init__(self, db: DatabaseManager):
        self.db = db
        self._init_table()

    def _init_table(self):
        with self.db._get_db() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS memo (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT DEFAULT '',
                    category TEXT DEFAULT 'Research',
                    priority TEXT DEFAULT 'Medium',
                    status TEXT DEFAULT 'Open',
                    due_date TEXT DEFAULT '',
                    color TEXT DEFAULT 'Blue',
                    is_pinned INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES user_info(id) ON DELETE CASCADE
                )
                """
            )

    def create_memo(self, user_id: int, data: dict[str, Any]) -> int:
        now = self._now()
        with self.db._get_db() as conn:
            conn.execute(
                """
                INSERT INTO memo (
                    user_id, title, content, category, priority, status,
                    due_date, color, is_pinned, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    data.get("title", "").strip() or "Untitled Memo",
                    data.get("content", ""),
                    data.get("category", "Research"),
                    data.get("priority", "Medium"),
                    data.get("status", "Open"),
                    data.get("due_date", ""),
                    data.get("color", "Blue"),
                    1 if data.get("is_pinned") else 0,
                    now,
                    now,
                ),
            )
            return int(conn.execute("SELECT last_insert_rowid()").fetchone()[0])

    def update_memo(self, memo_id: int, data: dict[str, Any]) -> bool:
        allowed = {"title", "content", "category", "priority", "status", "due_date", "color", "is_pinned"}
        updates = {key: data[key] for key in allowed if key in data}
        if not updates:
            return False
        updates["updated_at"] = self._now()
        if "is_pinned" in updates:
            updates["is_pinned"] = 1 if updates["is_pinned"] else 0
        set_clause = ", ".join(f"{key} = ?" for key in updates)
        values = list(updates.values()) + [memo_id]
        with self.db._get_db() as conn:
            conn.execute(f"UPDATE memo SET {set_clause} WHERE id = ?", values)
            return True

    def delete_memo(self, memo_id: int) -> bool:
        with self.db._get_db() as conn:
            conn.execute("DELETE FROM memo WHERE id = ?", (memo_id,))
            return True

    def toggle_done(self, memo_id: int) -> bool:
        memo = self.get_memo(memo_id)
        if not memo:
            return False
        new_status = "Open" if memo["status"] == "Done" else "Done"
        return self.update_memo(memo_id, {"status": new_status})

    def toggle_pin(self, memo_id: int) -> bool:
        memo = self.get_memo(memo_id)
        if not memo:
            return False
        return self.update_memo(memo_id, {"is_pinned": not bool(memo["is_pinned"])})

    def get_memo(self, memo_id: int) -> dict[str, Any] | None:
        with self.db._get_db() as conn:
            row = conn.execute("SELECT * FROM memo WHERE id = ?", (memo_id,)).fetchone()
            return dict(row) if row else None

    def list_memos(
        self,
        user_id: int,
        keyword: str = "",
        category: str = "All",
        status: str = "All",
        priority: str = "All",
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM memo WHERE user_id = ?"
        params: list[Any] = [user_id]
        if keyword.strip():
            query += " AND (title LIKE ? OR content LIKE ?)"
            key = f"%{keyword.strip()}%"
            params.extend([key, key])
        if category != "All":
            query += " AND category = ?"
            params.append(category)
        if status != "All":
            query += " AND status = ?"
            params.append(status)
        if priority != "All":
            query += " AND priority = ?"
            params.append(priority)
        query += """
            ORDER BY is_pinned DESC,
                     CASE priority WHEN 'Urgent' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END,
                     CASE WHEN due_date = '' THEN 1 ELSE 0 END,
                     due_date ASC,
                     updated_at DESC
        """
        with self.db._get_db() as conn:
            return [dict(row) for row in conn.execute(query, params).fetchall()]

    def stats(self, user_id: int) -> dict[str, int]:
        with self.db._get_db() as conn:
            row = conn.execute(
                """
                SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN status = 'Open' THEN 1 ELSE 0 END) AS open_count,
                    SUM(CASE WHEN status = 'Done' THEN 1 ELSE 0 END) AS done_count,
                    SUM(CASE WHEN is_pinned = 1 THEN 1 ELSE 0 END) AS pinned_count
                FROM memo WHERE user_id = ?
                """,
                (user_id,),
            ).fetchone()
            return {
                "total": int(row["total"] or 0),
                "open": int(row["open_count"] or 0),
                "done": int(row["done_count"] or 0),
                "pinned": int(row["pinned_count"] or 0),
            }

    @staticmethod
    def _now() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
