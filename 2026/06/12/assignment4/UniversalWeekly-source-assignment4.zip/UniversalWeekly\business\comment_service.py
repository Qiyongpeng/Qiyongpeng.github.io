"""Comment and feedback business logic."""

from typing import List, Optional, Dict, Tuple
from database.db_manager import DatabaseManager
from database.models import Comment


class CommentService:
    """Handle teacher comments, batch comments, and student replies."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    def add_comment(self, report_id: int, teacher_id: int, content: str,
                    comment_type: str = "general") -> Optional[int]:
        comment = Comment(
            report_id=report_id,
            teacher_id=teacher_id,
            content=content,
            comment_type=comment_type,
        )
        cid = self.db.add_comment(comment)
        if cid:
            self.db.update_report(report_id, status="reviewed")
        return cid

    def batch_comment(self, report_ids: List[int], teacher_id: int,
                      content: str) -> int:
        count = self.db.add_batch_comments(report_ids, teacher_id, content)
        for rid in report_ids:
            self.db.update_report(rid, status="reviewed")
        return count

    def get_comments(self, report_id: int) -> List[Dict]:
        return self.db.get_comments_by_report(report_id)

    def mark_read(self, comment_id: int) -> bool:
        return self.db.mark_comment_read(comment_id)

    def student_reply(self, comment_id: int, reply: str) -> bool:
        return self.db.reply_to_comment(comment_id, reply, is_teacher=False)

    def teacher_reply(self, comment_id: int, reply: str) -> bool:
        return self.db.reply_to_comment(comment_id, reply, is_teacher=True)

    def get_unread_count(self, user_id: int) -> int:
        return self.db.get_unread_comment_count(user_id)

    def get_comment_templates(self, teacher_id: int) -> list:
        return self.db.get_templates(teacher_id, "comment")
