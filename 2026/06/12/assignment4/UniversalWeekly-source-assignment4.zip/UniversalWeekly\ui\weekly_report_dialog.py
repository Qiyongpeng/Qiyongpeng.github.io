"""Weekly report editor dialog - for creating and editing reports."""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QTextEdit, QPushButton, QFormLayout, QGroupBox,
    QComboBox, QSpinBox, QDateEdit, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox,
    QScrollArea, QWidget, QTabWidget, QFileDialog,
    QGridLayout, QSplitter, QListWidget, QListWidgetItem,
    QCheckBox, QProgressBar, QFrame
)
from PyQt6.QtCore import Qt, QDate, pyqtSignal
from PyQt6.QtGui import QFont

from datetime import datetime, timedelta
from typing import Optional, List

from database.db_manager import DatabaseManager
from database.models import WeeklyReport, Task, ProblemRecord
from business.report_service import ReportService
from business.template_service import TemplateService
from business.local_llm_service import LocalLLMService
from ui.common_widgets import (
    StyledButton, SectionLabel, CardFrame, StatusBadge,
    ReadOnlyTable, IconButton
)


CATEGORIES = ["study", "homework", "project", "club", "personal", "other"]
CATEGORY_LABELS = {
    "study": "Study", "homework": "Homework", "project": "Project",
    "club": "Club", "personal": "Personal", "other": "Other"
}
STATUS_OPTIONS = ["not_started", "in_progress", "completed", "delayed"]
PROBLEM_TYPES = ["time_management", "difficulty", "resource", "other"]


class WeeklyReportDialog(QDialog):
    """Create or edit a weekly report."""

    report_saved = pyqtSignal(int)

    def __init__(self, db: DatabaseManager, user_id: int, class_name: str,
                 report_id: Optional[int] = None):
        super().__init__()
        self.db = db
        self.user_id = user_id
        self.class_name = class_name
        self.report_id = report_id
        self.report_service = ReportService(db)
        self.template_service = TemplateService(db)
        self._editing = report_id is not None
        self._init_ui()
        self._setup_charts()
        if self._editing:
            self._load_report()

    def _init_ui(self):
        self.setWindowTitle("Edit Weekly Report" if self._editing else "New Weekly Report")
        self.setMinimumSize(900, 700)
        self.setStyleSheet("""
            QDialog {
                background-color: #F5F7FA;
            }
            QGroupBox {
                font-weight: bold;
                border: 1px solid #E0E0E0;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 16px;
                background: white;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 6px;
                color: #2C3E50;
            }
            QLineEdit, QTextEdit, QComboBox, QSpinBox {
                padding: 8px;
                border: 1px solid #D0D0D0;
                border-radius: 4px;
                background: white;
            }
        """)

        main_layout = QVBoxLayout()

        # Top info bar
        info_bar = QWidget()
        info_bar.setStyleSheet("background: white; border-radius: 8px; padding: 8px;")
        info_layout = QHBoxLayout()

        week = self.report_service.get_current_week_number()
        start_date, end_date = self.report_service.get_week_date_range()

        info_layout.addWidget(QLabel(f"Week:"))
        self.week_spin = QSpinBox()
        self.week_spin.setRange(1, 53)
        self.week_spin.setValue(week)
        info_layout.addWidget(self.week_spin)

        info_layout.addWidget(QLabel("  Period:"))
        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDate(QDate.fromString(start_date, "yyyy-MM-dd"))
        info_layout.addWidget(self.start_date)

        info_layout.addWidget(QLabel("~"))
        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDate(QDate.fromString(end_date, "yyyy-MM-dd"))
        info_layout.addWidget(self.end_date)

        info_layout.addWidget(QLabel("  Class:"))
        self.class_label = QLabel(self.class_name)
        self.class_label.setStyleSheet("font-weight: bold;")
        info_layout.addWidget(self.class_label)

        info_layout.addStretch()
        info_bar.setLayout(info_layout)
        main_layout.addWidget(info_bar)

        # Tab widget for sections
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { background: white; border-radius: 6px; }
            QTabBar::tab { padding: 10px 24px; font-size: 13px; }
            QTabBar::tab:selected { border-bottom: 3px solid #4A90D9; color: #4A90D9; font-weight: bold; }
        """)

        # Tab 1: Tasks
        self.tasks_tab = self._create_tasks_tab()
        self.tabs.addTab(self.tasks_tab, "Tasks")

        # Tab 2: Problems & Reflection
        self.problems_tab = self._create_problems_tab()
        self.tabs.addTab(self.problems_tab, "Problems & Reflection")

        # Tab 3: Next Week Plan
        self.plans_tab = self._create_plans_tab()
        self.tabs.addTab(self.plans_tab, "Next Week Plan")

        # Tab 4: Summary
        self.summary_tab = self._create_summary_tab()
        self.tabs.addTab(self.summary_tab, "Summary")

        main_layout.addWidget(self.tabs, 1)

        # Bottom buttons
        btn_bar = QWidget()
        btn_layout = QHBoxLayout()
        self.save_draft_btn = StyledButton("Save Draft", "default")
        self.submit_btn = StyledButton("Submit Report", "primary")
        self.cancel_btn = StyledButton("Cancel", "danger")

        self.save_draft_btn.clicked.connect(lambda: self._save_report(draft=True))
        self.submit_btn.clicked.connect(lambda: self._save_report(draft=False))
        self.cancel_btn.clicked.connect(self.reject)

        btn_layout.addWidget(self.save_draft_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(self.submit_btn)
        btn_layout.addWidget(self.cancel_btn)
        btn_bar.setLayout(btn_layout)
        main_layout.addWidget(btn_bar)

        self.setLayout(main_layout)

    def _create_tasks_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()

        # Instruction
        instr = QLabel("Add the tasks you completed this week. Use the 'Carry Over' button to copy unfinished tasks from last week.")
        instr.setWordWrap(True)
        instr.setStyleSheet("color: #7F8C8D; padding: 4px;")
        layout.addWidget(instr)

        # Task table
        self.task_table = QTableWidget()
        self.task_table.setColumnCount(7)
        self.task_table.setHorizontalHeaderLabels(
            ["Category", "Task Name", "Status", "Task Progress", "Tags", "Description", "ID"]
        )
        self.task_table.setColumnHidden(6, True)
        self.task_table.horizontalHeader().setStretchLastSection(True)
        self.task_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.task_table.setAlternatingRowColors(True)
        self.task_table.setStyleSheet("""
            QTableWidget { border: 1px solid #E0E0E0; gridline-color: #F0F0F0; }
            QHeaderView::section { background: #4A90D9; color: white; padding: 6px; font-weight: bold; }
        """)
        layout.addWidget(self.task_table)

        # Task buttons
        btn_row = QHBoxLayout()
        self.add_task_btn = StyledButton("+ Add Task", "success")
        self.edit_task_btn = StyledButton("Edit Task", "info")
        self.delete_task_btn = StyledButton("Delete Task", "danger")
        self.carry_over_btn = StyledButton("Carry Over", "warning")
        self.add_task_btn.clicked.connect(self._add_task)
        self.edit_task_btn.clicked.connect(self._edit_task)
        self.delete_task_btn.clicked.connect(self._delete_task)
        self.carry_over_btn.clicked.connect(self._carry_over)

        btn_row.addWidget(self.add_task_btn)
        btn_row.addWidget(self.edit_task_btn)
        btn_row.addWidget(self.delete_task_btn)
        btn_row.addWidget(self.carry_over_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        # Category summary
        self.summary_label = QLabel("Task summary will appear here.")
        self.summary_label.setStyleSheet("color: #7F8C8D; padding: 8px;")
        layout.addWidget(self.summary_label)

        widget.setLayout(layout)
        return widget

    def _create_problems_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()

        instr = QLabel("Record any problems you encountered this week and your reflection.")
        instr.setWordWrap(True)
        instr.setStyleSheet("color: #7F8C8D; padding: 4px;")
        layout.addWidget(instr)

        # Problem table
        self.problem_table = QTableWidget()
        self.problem_table.setColumnCount(5)
        self.problem_table.setHorizontalHeaderLabels(
            ["Description", "Type", "Attempted Solution", "Unresolved Reason", "ID"]
        )
        self.problem_table.setColumnHidden(4, True)
        self.problem_table.horizontalHeader().setStretchLastSection(True)
        self.problem_table.setAlternatingRowColors(True)
        self.problem_table.setStyleSheet(self.task_table.styleSheet())
        layout.addWidget(self.problem_table)

        btn_row = QHBoxLayout()
        self.add_prob_btn = StyledButton("+ Add Problem", "success")
        self.edit_prob_btn = StyledButton("Edit", "info")
        self.delete_prob_btn = StyledButton("Delete", "danger")
        self.add_prob_btn.clicked.connect(self._add_problem)
        self.edit_prob_btn.clicked.connect(self._edit_problem)
        self.delete_prob_btn.clicked.connect(self._delete_problem)

        btn_row.addWidget(self.add_prob_btn)
        btn_row.addWidget(self.edit_prob_btn)
        btn_row.addWidget(self.delete_prob_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        widget.setLayout(layout)
        return widget

    def _create_plans_tab(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()

        instr = QLabel("Plan your tasks for next week. You can also add a summary below.")
        instr.setWordWrap(True)
        instr.setStyleSheet("color: #7F8C8D; padding: 4px;")
        layout.addWidget(instr)

        self.plan_table = QTableWidget()
        self.plan_table.setColumnCount(5)
        self.plan_table.setHorizontalHeaderLabels(
            ["Category", "Plan Name", "Description", "Tags", "ID"]
        )
        self.plan_table.setColumnHidden(4, True)
        self.plan_table.horizontalHeader().setStretchLastSection(True)
        self.plan_table.setAlternatingRowColors(True)
        self.plan_table.setStyleSheet(self.task_table.styleSheet())
        layout.addWidget(self.plan_table)

        btn_row = QHBoxLayout()
        self.add_plan_btn = StyledButton("+ Add Plan", "success")
        self.edit_plan_btn = StyledButton("Edit", "info")
        self.delete_plan_btn = StyledButton("Delete", "danger")
        self.add_plan_btn.clicked.connect(self._add_plan)
        self.edit_plan_btn.clicked.connect(self._edit_plan)
        self.delete_plan_btn.clicked.connect(self._delete_plan)

        btn_row.addWidget(self.add_plan_btn)
        btn_row.addWidget(self.edit_plan_btn)
        btn_row.addWidget(self.delete_plan_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self._add_ai_text_area(
            layout,
            "Next Week Plan Summary:",
            "plan_summary",
            "AI will generate this from the Next Week Plan tab. You can still edit it manually.",
            "next_plan_summary",
            100,
        )

        widget.setLayout(layout)
        return widget

    def _add_ai_text_area(self, layout: QVBoxLayout, label: str, attr_name: str,
                          placeholder: str, section_key: str, max_height: int):
        header = QHBoxLayout()
        header.addWidget(QLabel(label))
        header.addStretch()
        layout.addLayout(header)

        edit = QTextEdit()
        edit.setPlaceholderText(placeholder)
        edit.setMaximumHeight(max_height)
        setattr(self, attr_name, edit)
        layout.addWidget(edit)

    def _create_summary_tab(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        ai_group = QGroupBox("AI Full Weekly Report Builder")
        ai_layout = QVBoxLayout()

        tip = QLabel(
            "Enter keywords here. The assistant will first fill the Tasks, Problems & Reflection, "
            "and Next Week Plan tabs, then generate the Summary fields from those generated rows."
        )
        tip.setWordWrap(True)
        tip.setStyleSheet("color: #7F8C8D;")
        ai_layout.addWidget(tip)

        input_layout = QGridLayout()
        input_layout.addWidget(QLabel("Task Keywords:"), 0, 0)
        self.ai_completed_edit = QTextEdit()
        self.ai_completed_edit.setPlaceholderText(
            "Generate Tasks tab. Example: read digital twin papers; finish statistics homework; complete Python experiment"
        )
        self.ai_completed_edit.setMaximumHeight(58)
        input_layout.addWidget(self.ai_completed_edit, 0, 1)

        input_layout.addWidget(QLabel("Problem Keywords:"), 1, 0)
        self.ai_problem_edit = QTextEdit()
        self.ai_problem_edit.setPlaceholderText(
            "Generate Problems & Reflection tab. Example: literature notes are not systematic enough; experiment evidence is weak"
        )
        self.ai_problem_edit.setMaximumHeight(58)
        input_layout.addWidget(self.ai_problem_edit, 1, 1)

        input_layout.addWidget(QLabel("Plan Keywords:"), 2, 0)
        self.ai_next_plan_edit = QTextEdit()
        self.ai_next_plan_edit.setPlaceholderText(
            "Generate Next Week Plan tab. Example: organize related papers; improve experiment chart; prepare weekly presentation"
        )
        self.ai_next_plan_edit.setMaximumHeight(58)
        input_layout.addWidget(self.ai_next_plan_edit, 2, 1)
        input_layout.setColumnStretch(1, 1)
        ai_layout.addLayout(input_layout)

        option_layout = QHBoxLayout()
        option_layout.addWidget(QLabel("Output Language:"))
        self.ai_language_combo = QComboBox()
        self.ai_language_combo.addItems(["English", "Chinese"])
        self.ai_language_combo.setCurrentText("Chinese")
        option_layout.addWidget(self.ai_language_combo)

        option_layout.addWidget(QLabel("Fill Mode:"))
        self.ai_fill_mode_combo = QComboBox()
        self.ai_fill_mode_combo.addItems([
            "Refresh Tasks/Problems/Plans + Summary",
            "Append Tasks/Problems/Plans + Summary",
            "Summary Only",
        ])
        self.ai_fill_mode_combo.setCurrentText("Refresh Tasks/Problems/Plans + Summary")
        option_layout.addWidget(self.ai_fill_mode_combo)
        option_layout.addStretch()
        ai_layout.addLayout(option_layout)

        advanced_group = QGroupBox("Advanced Local Model Settings")
        advanced_group.setCheckable(True)
        advanced_group.setChecked(False)
        advanced_group_layout = QVBoxLayout()
        advanced_group_layout.setContentsMargins(8, 8, 8, 8)
        self.ai_advanced_content = QWidget()
        advanced_layout = QGridLayout()
        advanced_layout.addWidget(QLabel("Provider:"), 0, 0)
        self.ai_provider_combo = QComboBox()
        self.ai_provider_combo.addItems(["Ollama", "OpenAI-compatible", "Offline Template"])
        self.ai_provider_combo.currentTextChanged.connect(self._update_ai_defaults)
        advanced_layout.addWidget(self.ai_provider_combo, 0, 1)

        advanced_layout.addWidget(QLabel("Endpoint:"), 0, 2)
        self.ai_endpoint_edit = QLineEdit(LocalLLMService.DEFAULT_OLLAMA_URL)
        advanced_layout.addWidget(self.ai_endpoint_edit, 0, 3)

        advanced_layout.addWidget(QLabel("Model:"), 1, 0)
        self.ai_model_edit = QComboBox()
        self.ai_model_edit.setEditable(True)
        self.ai_model_edit.addItems(LocalLLMService.model_options())
        self.ai_model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
        self.ai_model_edit.lineEdit().setPlaceholderText("Example: qwen2.5:7b")
        advanced_layout.addWidget(self.ai_model_edit, 1, 1)

        test_btn = StyledButton("Test Local Model", "info")
        test_btn.clicked.connect(self._test_local_llm)
        advanced_layout.addWidget(test_btn, 1, 3)
        self.ai_advanced_content.setLayout(advanced_layout)
        self.ai_advanced_content.setVisible(False)
        advanced_group.toggled.connect(self.ai_advanced_content.setVisible)
        advanced_group_layout.addWidget(self.ai_advanced_content)
        advanced_group.setLayout(advanced_group_layout)
        ai_layout.addWidget(advanced_group)

        ai_btn_row = QHBoxLayout()
        generate_btn = StyledButton("Generate Tabs and Summary", "primary")
        generate_btn.clicked.connect(self._generate_weekly_report_with_ai)
        clear_ai_btn = StyledButton("Clear AI Inputs", "secondary")
        clear_ai_btn.clicked.connect(self._clear_ai_inputs)
        ai_btn_row.addWidget(generate_btn)
        ai_btn_row.addWidget(clear_ai_btn)
        ai_btn_row.addStretch()
        ai_layout.addLayout(ai_btn_row)

        self.ai_status_label = QLabel("Engine: not used yet")
        self.ai_status_label.setStyleSheet("color: #7F8C8D; padding: 4px;")
        ai_layout.addWidget(self.ai_status_label)

        ai_group.setLayout(ai_layout)
        layout.addWidget(ai_group)

        self._add_ai_text_area(
            layout,
            "Highlights:",
            "highlights_edit",
            "AI will generate this after filling the Tasks tab. You can still edit it manually.",
            "highlights",
            82,
        )

        self._add_ai_text_area(
            layout,
            "Shortcomings:",
            "shortcomings_edit",
            "AI will generate this after filling the Problems & Reflection tab. You can still edit it manually.",
            "shortcomings",
            82,
        )

        self._add_ai_text_area(
            layout,
            "Improvement Measures:",
            "improvements_edit",
            "AI will generate this after filling the Problems & Reflection tab. You can still edit it manually.",
            "improvements",
            82,
        )

        self.task_count_label = QLabel("Current tasks: 0 | Problems: 0 | Plans: 0")
        self.task_count_label.setStyleSheet("color: #7F8C8D; padding: 8px;")
        layout.addWidget(self.task_count_label)

        layout.addStretch()
        widget.setLayout(layout)
        scroll.setWidget(widget)
        return scroll

    def _update_ai_defaults(self):
        provider = self.ai_provider_combo.currentText()
        if provider == "Ollama":
            self.ai_endpoint_edit.setText(LocalLLMService.DEFAULT_OLLAMA_URL)
            self.ai_model_edit.setCurrentText(LocalLLMService.DEFAULT_MODEL)
            self.ai_endpoint_edit.setEnabled(True)
            self.ai_model_edit.setEnabled(True)
        elif provider == "OpenAI-compatible":
            self.ai_endpoint_edit.setText(LocalLLMService.DEFAULT_OPENAI_COMPAT_URL)
            self.ai_model_edit.setCurrentText("local-model")
            self.ai_endpoint_edit.setEnabled(True)
            self.ai_model_edit.setEnabled(True)
        else:
            self.ai_endpoint_edit.clear()
            self.ai_model_edit.setCurrentText("")
            self.ai_endpoint_edit.setEnabled(False)
            self.ai_model_edit.setEnabled(False)

    def _test_local_llm(self):
        provider = self.ai_provider_combo.currentText()
        ok, message = LocalLLMService.test_connection(
            provider,
            self.ai_endpoint_edit.text().strip(),
            self.ai_model_edit.currentText().strip(),
        )
        self.ai_status_label.setText(message)
        if ok:
            QMessageBox.information(self, "Local Model", message)
        else:
            QMessageBox.warning(self, "Local Model", message)

    def _clear_ai_inputs(self):
        self.ai_completed_edit.clear()
        self.ai_problem_edit.clear()
        self.ai_next_plan_edit.clear()
        self.ai_status_label.setText("Engine: not used yet")

    def _collect_structured_ai_inputs(self) -> dict:
        def text_of(attr: str) -> str:
            widget = getattr(self, attr, None)
            return widget.toPlainText().strip() if widget else ""

        return {
            "completed": text_of("ai_completed_edit"),
            "problems": text_of("ai_problem_edit"),
            "next_plan": text_of("ai_next_plan_edit"),
        }

    def _keywords_for_summary_section(self, section_key: str, target_text: str) -> str:
        if target_text:
            return target_text

        ai_inputs = self._collect_structured_ai_inputs()
        if section_key == "highlights":
            if ai_inputs["completed"]:
                return ai_inputs["completed"]
            tasks = self._collect_tasks_from_table(self.task_table, False)
            return "; ".join(
                " - ".join(part for part in [task.get("name", ""), task.get("description", "")] if part)
                for task in tasks
            )

        if section_key in {"shortcomings", "improvements"}:
            if ai_inputs["problems"]:
                return ai_inputs["problems"]
            problems = self._collect_ai_report_context().get("problems", [])
            return "; ".join(
                " - ".join(
                    part for part in [
                        problem.get("description", ""),
                        problem.get("attempted_solution", ""),
                        problem.get("unresolved_reason", ""),
                    ]
                    if part
                )
                for problem in problems
            )

        if section_key == "next_plan_summary":
            if ai_inputs["next_plan"]:
                return ai_inputs["next_plan"]
            plans = self._collect_tasks_from_table(self.plan_table, True)
            return "; ".join(
                " - ".join(part for part in [plan.get("name", ""), plan.get("description", "")] if part)
                for plan in plans
            )

        return target_text

    def _generate_single_summary_field(self, section_key: str):
        target_map = {
            "highlights": self.highlights_edit,
            "shortcomings": self.shortcomings_edit,
            "improvements": self.improvements_edit,
            "next_plan_summary": self.plan_summary,
        }
        target = target_map.get(section_key)
        if target is None:
            return

        current_text = target.toPlainText().strip()
        keywords = self._keywords_for_summary_section(section_key, current_text)
        if not keywords:
            QMessageBox.warning(
                self,
                "Missing Keywords",
                "Please enter keywords in this field, the AI assistant inputs, or the related report table first.",
            )
            return

        try:
            self.setCursor(Qt.CursorShape.WaitCursor)
            context = self._collect_ai_report_context()
            context["ai_inputs"] = self._collect_structured_ai_inputs()
            result = LocalLLMService.generate_section(
                section=section_key,
                keywords=keywords,
                context=context,
                provider=self.ai_provider_combo.currentText(),
                endpoint=self.ai_endpoint_edit.text().strip(),
                model=self.ai_model_edit.currentText().strip(),
                output_language=self.ai_language_combo.currentText(),
            )
        except Exception as exc:
            self._log_ai_call("ai_generate_section_failed", f"{section_key}: {exc}", keywords)
            QMessageBox.critical(self, "Generation Failed", str(exc))
            return
        finally:
            self.unsetCursor()

        target.setPlainText(result.get("text", ""))
        self.ai_status_label.setText(f"Engine: {result.get('engine', 'unknown')}")
        self._log_ai_call("ai_generate_section", f"{section_key}; {result.get('engine', 'unknown')}", keywords)

    def _generate_weekly_report_with_ai(self):
        ai_inputs = self._collect_structured_ai_inputs()
        completed = ai_inputs["completed"] or self._keywords_for_summary_section("highlights", "")
        problems = ai_inputs["problems"] or self._keywords_for_summary_section("shortcomings", "")
        next_plan = ai_inputs["next_plan"] or self._keywords_for_summary_section("next_plan_summary", "")
        keywords = "; ".join(part for part in [completed, problems, next_plan] if part)
        if not keywords:
            QMessageBox.warning(
                self,
                "Missing Notes",
                "Please enter completed work, problems, or next-week plan notes first.",
            )
            return
        try:
            self.setCursor(Qt.CursorShape.WaitCursor)
            context = self._collect_ai_report_context()
            context["ai_inputs"] = {
                "completed": completed,
                "problems": problems,
                "next_plan": next_plan,
            }
            result = LocalLLMService.generate_weekly_report(
                keywords=keywords,
                context=context,
                provider=self.ai_provider_combo.currentText(),
                endpoint=self.ai_endpoint_edit.text().strip(),
                model=self.ai_model_edit.currentText().strip(),
                output_language=self.ai_language_combo.currentText(),
            )
        except Exception as exc:
            self._log_ai_call("ai_generate_failed", str(exc), keywords)
            QMessageBox.critical(self, "Generation Failed", str(exc))
            return
        finally:
            self.unsetCursor()

        fill_mode = self.ai_fill_mode_combo.currentText()
        if fill_mode != "Summary Only":
            if fill_mode.startswith("Refresh"):
                self._clear_ai_generated_rows()
            self._append_generated_tasks(result.get("tasks", []))
            self._append_generated_problems(result.get("problems", []))
            self._append_generated_plans(result.get("plans", []))

        self.highlights_edit.setPlainText(result.get("highlights", ""))
        self.shortcomings_edit.setPlainText(result.get("shortcomings", ""))
        self.improvements_edit.setPlainText(result.get("improvements", ""))
        self.plan_summary.setPlainText(result.get("next_plan_summary", ""))

        self.ai_status_label.setText(f"Engine: {result.get('engine', 'unknown')}")
        self._log_ai_call("ai_generate_weekly_report", result.get("engine", "unknown"), keywords)
        self._update_summary()
        QMessageBox.information(self, "Generated", "Tasks, problems, plans, and summary have been generated.")

    def _log_ai_call(self, operation_type: str, engine: str, keywords: str):
        try:
            user = self.db.get_user_by_id(self.user_id)
            username = user.username if user else ""
            model = self.ai_model_edit.currentText().strip() or "-"
            provider = self.ai_provider_combo.currentText()
            description = (
                f"Week {self.week_spin.value()}; "
                f"provider={provider}; model={model}; "
                f"language={self.ai_language_combo.currentText()}; "
                f"mode={self.ai_fill_mode_combo.currentText()}; "
                f"engine={engine}; notes={keywords[:300]}"
            )
            self.db.log_operation(self.user_id, username, operation_type, description[:900])
        except Exception:
            pass

    def _collect_ai_report_context(self) -> dict:
        return {
            "week": self.week_spin.value(),
            "period": {
                "start": self.start_date.date().toString("yyyy-MM-dd"),
                "end": self.end_date.date().toString("yyyy-MM-dd"),
            },
            "class": self.class_name,
            "tasks": self._collect_tasks_from_table(self.task_table, False),
            "plans": self._collect_tasks_from_table(self.plan_table, True),
            "problems": [
                {
                    "description": self.problem_table.item(row, 0).text() if self.problem_table.item(row, 0) else "",
                    "type": self.problem_table.item(row, 1).text() if self.problem_table.item(row, 1) else "other",
                    "attempted_solution": self.problem_table.item(row, 2).text() if self.problem_table.item(row, 2) else "",
                    "unresolved_reason": self.problem_table.item(row, 3).text() if self.problem_table.item(row, 3) else "",
                }
                for row in range(self.problem_table.rowCount())
            ],
        }

    def _append_generated_tasks(self, tasks: list[dict]):
        for task in tasks:
            if not task.get("name"):
                continue
            row = self.task_table.rowCount()
            self.task_table.insertRow(row)
            self.task_table.setItem(row, 0, QTableWidgetItem(task.get("category", "study")))
            self.task_table.setItem(row, 1, QTableWidgetItem(task.get("name", "Generated task")))
            self.task_table.setItem(row, 2, QTableWidgetItem(task.get("status", "completed")))
            self.task_table.setItem(row, 3, QTableWidgetItem(str(task.get("progress", 100))))
            self.task_table.setItem(row, 4, QTableWidgetItem("ai-generated"))
            self.task_table.setItem(row, 5, QTableWidgetItem(task.get("description", "")))
            self.task_table.setItem(row, 6, QTableWidgetItem("-1"))

    def _clear_ai_generated_rows(self):
        for table, tag_col, id_col in [
            (self.task_table, 4, 6),
            (self.plan_table, 3, 4),
        ]:
            for row in range(table.rowCount() - 1, -1, -1):
                tag = table.item(row, tag_col).text() if table.item(row, tag_col) else ""
                row_id = table.item(row, id_col).text() if table.item(row, id_col) else ""
                if tag == "ai-generated" or row_id == "ai-generated":
                    table.removeRow(row)

        for row in range(self.problem_table.rowCount() - 1, -1, -1):
            row_id = self.problem_table.item(row, 4).text() if self.problem_table.item(row, 4) else ""
            if row_id == "ai-generated":
                self.problem_table.removeRow(row)

    def _append_generated_problems(self, problems: list[dict]):
        for problem in problems:
            description = problem.get("description", "")
            if not description:
                continue
            row = self.problem_table.rowCount()
            self.problem_table.insertRow(row)
            self.problem_table.setItem(row, 0, QTableWidgetItem(description))
            self.problem_table.setItem(row, 1, QTableWidgetItem(problem.get("problem_type", "other")))
            self.problem_table.setItem(row, 2, QTableWidgetItem(problem.get("attempted_solution", "")))
            self.problem_table.setItem(row, 3, QTableWidgetItem(problem.get("unresolved_reason", "")))
            self.problem_table.setItem(row, 4, QTableWidgetItem("ai-generated"))

    def _append_generated_plans(self, plans: list[dict]):
        for plan in plans:
            if not plan.get("name"):
                continue
            row = self.plan_table.rowCount()
            self.plan_table.insertRow(row)
            self.plan_table.setItem(row, 0, QTableWidgetItem(plan.get("category", "study")))
            self.plan_table.setItem(row, 1, QTableWidgetItem(plan.get("name", "Generated plan")))
            self.plan_table.setItem(row, 2, QTableWidgetItem(plan.get("description", "")))
            self.plan_table.setItem(row, 3, QTableWidgetItem("ai-generated"))
            self.plan_table.setItem(row, 4, QTableWidgetItem("-1"))

    def _setup_charts(self):
        pass  # Charts rendered via matplotlib in the main view

    # ─── Task CRUD ───────────────────────────────────────────────────────────

    def _add_task(self):
        dialog = TaskEditDialog(self)
        if dialog.exec():
            data = dialog.get_data()
            row = self.task_table.rowCount()
            self.task_table.insertRow(row)
            self.task_table.setItem(row, 0, QTableWidgetItem(data["category"]))
            self.task_table.setItem(row, 1, QTableWidgetItem(data["name"]))
            self.task_table.setItem(row, 2, QTableWidgetItem(data["status"]))
            self.task_table.setItem(row, 3, QTableWidgetItem(str(data["progress"])))
            self.task_table.setItem(row, 4, QTableWidgetItem(data.get("tags", "")))
            self.task_table.setItem(row, 5, QTableWidgetItem(data.get("description", "")))
            self.task_table.setItem(row, 6, QTableWidgetItem("-1"))  # temp ID
            self._update_summary()

    def _edit_task(self):
        row = self.task_table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a task first.")
            return
        data = {
            "category": self.task_table.item(row, 0).text(),
            "name": self.task_table.item(row, 1).text(),
            "status": self.task_table.item(row, 2).text(),
            "progress": int(self.task_table.item(row, 3).text()),
            "tags": self.task_table.item(row, 4).text(),
            "description": self.task_table.item(row, 5).text(),
        }
        dialog = TaskEditDialog(self, data)
        if dialog.exec():
            data = dialog.get_data()
            self.task_table.item(row, 0).setText(data["category"])
            self.task_table.item(row, 1).setText(data["name"])
            self.task_table.item(row, 2).setText(data["status"])
            self.task_table.item(row, 3).setText(str(data["progress"]))
            self.task_table.item(row, 4).setText(data.get("tags", ""))
            self.task_table.item(row, 5).setText(data.get("description", ""))

    def _delete_task(self):
        row = self.task_table.currentRow()
        if row < 0:
            return
        self.task_table.removeRow(row)
        self._update_summary()

    def _carry_over(self):
        if self._editing:
            prev_id = self.report_service.get_previous_report_id(self.user_id, self.week_spin.value())
            if prev_id:
                count = self.report_service.carry_over_tasks(self.report_id, prev_id)
                QMessageBox.information(self, "Carry Over", f"{count} unfinished tasks carried over.")
                self._load_tasks()
                return
        QMessageBox.information(self, "Info", "No previous report found to carry over from.")

    # ─── Problem CRUD ───────────────────────────────────────────────────────

    def _add_problem(self):
        dialog = ProblemEditDialog(self)
        if dialog.exec():
            data = dialog.get_data()
            row = self.problem_table.rowCount()
            self.problem_table.insertRow(row)
            self.problem_table.setItem(row, 0, QTableWidgetItem(data["description"]))
            self.problem_table.setItem(row, 1, QTableWidgetItem(data["problem_type"]))
            self.problem_table.setItem(row, 2, QTableWidgetItem(data.get("attempted_solution", "")))
            self.problem_table.setItem(row, 3, QTableWidgetItem(data.get("unresolved_reason", "")))
            self.problem_table.setItem(row, 4, QTableWidgetItem("-1"))

    def _edit_problem(self):
        row = self.problem_table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a problem first.")
            return
        data = {
            "description": self.problem_table.item(row, 0).text(),
            "problem_type": self.problem_table.item(row, 1).text(),
            "attempted_solution": self.problem_table.item(row, 2).text(),
            "unresolved_reason": self.problem_table.item(row, 3).text(),
        }
        dialog = ProblemEditDialog(self, data)
        if dialog.exec():
            data = dialog.get_data()
            self.problem_table.item(row, 0).setText(data["description"])
            self.problem_table.item(row, 1).setText(data["problem_type"])
            self.problem_table.item(row, 2).setText(data.get("attempted_solution", ""))
            self.problem_table.item(row, 3).setText(data.get("unresolved_reason", ""))

    def _delete_problem(self):
        row = self.problem_table.currentRow()
        if row >= 0:
            self.problem_table.removeRow(row)

    # ─── Plan CRUD ───────────────────────────────────────────────────────────

    def _add_plan(self):
        dialog = PlanEditDialog(self)
        if dialog.exec():
            data = dialog.get_data()
            row = self.plan_table.rowCount()
            self.plan_table.insertRow(row)
            self.plan_table.setItem(row, 0, QTableWidgetItem(data["category"]))
            self.plan_table.setItem(row, 1, QTableWidgetItem(data["name"]))
            self.plan_table.setItem(row, 2, QTableWidgetItem(data.get("description", "")))
            self.plan_table.setItem(row, 3, QTableWidgetItem(data.get("tags", "")))
            self.plan_table.setItem(row, 4, QTableWidgetItem("-1"))

    def _edit_plan(self):
        row = self.plan_table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Warning", "Please select a plan first.")
            return
        data = {
            "category": self.plan_table.item(row, 0).text(),
            "name": self.plan_table.item(row, 1).text(),
            "description": self.plan_table.item(row, 2).text(),
            "tags": self.plan_table.item(row, 3).text(),
        }
        dialog = PlanEditDialog(self, data)
        if dialog.exec():
            data = dialog.get_data()
            self.plan_table.item(row, 0).setText(data["category"])
            self.plan_table.item(row, 1).setText(data["name"])
            self.plan_table.item(row, 2).setText(data.get("description", ""))
            self.plan_table.item(row, 3).setText(data.get("tags", ""))

    def _delete_plan(self):
        row = self.plan_table.currentRow()
        if row >= 0:
            self.plan_table.removeRow(row)

    # ─── Save / Load ─────────────────────────────────────────────────────────

    def _collect_tasks_from_table(self, table: QTableWidget, is_plan: bool) -> list:
        tasks = []
        for row in range(table.rowCount()):
            task_data = {
                "category": table.item(row, 0).text() if table.item(row, 0) else "other",
                "name": table.item(row, 1).text() if table.item(row, 1) else "",
            }
            if not is_plan:
                task_data.update({
                    "status": table.item(row, 2).text() if table.item(row, 2) else "not_started",
                    "progress": int(table.item(row, 3).text()) if table.item(row, 3) else 0,
                    "tags": table.item(row, 4).text() if table.item(row, 4) else "",
                    "description": table.item(row, 5).text() if table.item(row, 5) else "",
                })
            else:
                task_data.update({
                    "description": table.item(row, 2).text() if table.item(row, 2) else "",
                    "tags": table.item(row, 3).text() if table.item(row, 3) else "",
                })
            tasks.append(task_data)
        return tasks

    def _save_report(self, draft: bool = True):
        try:
            week = self.week_spin.value()
            sdate = self.start_date.date().toString("yyyy-MM-dd")
            edate = self.end_date.date().toString("yyyy-MM-dd")

            tasks_data = self._collect_tasks_from_table(self.task_table, False)
            plans_data = self._collect_tasks_from_table(self.plan_table, True)

            if not draft:
                if not tasks_data:
                    QMessageBox.warning(self, "Validation Error",
                                        "Please add at least one task before submitting.")
                    return
                if not plans_data:
                    QMessageBox.warning(self, "Validation Error",
                                        "Please add at least one next-week plan before submitting.")
                    return

            # Create or update report
            if self._editing:
                self.db.update_report(
                    self.report_id,
                    status="draft" if draft else "submitted",
                    highlights=self.highlights_edit.toPlainText(),
                    shortcomings=self.shortcomings_edit.toPlainText(),
                    improvements=self.improvements_edit.toPlainText(),
                    next_plan_summary=self.plan_summary.toPlainText(),
                )
                # Delete existing tasks and re-add
                existing_tasks = self.db.get_tasks_by_report(self.report_id, False)
                existing_plans = self.db.get_tasks_by_report(self.report_id, True)
                for t in existing_tasks + existing_plans:
                    self.db.delete_task(t.id)
            else:
                report_id = self.report_service.create_report(
                    self.user_id, self.class_name, week, sdate, edate
                )
                if report_id is None:
                    QMessageBox.critical(self, "Error", "Failed to create report.")
                    return
                self.report_id = report_id
                self._editing = True

                if not draft:
                    self.db.update_report(self.report_id, status="submitted")

                # Save summary
                self.db.update_report(
                    self.report_id,
                    highlights=self.highlights_edit.toPlainText(),
                    shortcomings=self.shortcomings_edit.toPlainText(),
                    improvements=self.improvements_edit.toPlainText(),
                    next_plan_summary=self.plan_summary.toPlainText(),
                )

            # Save tasks
            for td in tasks_data:
                task = Task(
                    report_id=self.report_id,
                    category=td["category"],
                    name=td["name"],
                    description=td.get("description", ""),
                    status=td.get("status", "not_started"),
                    progress=td.get("progress", 0),
                    tags=td.get("tags", ""),
                    is_plan=False,
                )
                self.db.add_task(task)

            # Save plans
            for pd in plans_data:
                task = Task(
                    report_id=self.report_id,
                    category=pd["category"],
                    name=pd["name"],
                    description=pd.get("description", ""),
                    tags=pd.get("tags", ""),
                    is_plan=True,
                )
                self.db.add_task(task)

            # Save problems
            if not self._editing or True:  # Always re-sync problems
                existing_problems = self.db.get_problems_by_report(self.report_id)
                for p in existing_problems:
                    self.db.delete_problem(p.id)

                for row in range(self.problem_table.rowCount()):
                    problem = ProblemRecord(
                        report_id=self.report_id,
                        description=self.problem_table.item(row, 0).text() if self.problem_table.item(row, 0) else "",
                        problem_type=self.problem_table.item(row, 1).text() if self.problem_table.item(row, 1) else "other",
                        attempted_solution=self.problem_table.item(row, 2).text() if self.problem_table.item(row, 2) else "",
                        unresolved_reason=self.problem_table.item(row, 3).text() if self.problem_table.item(row, 3) else "",
                    )
                    self.db.add_problem(problem)

            self.db.log_operation(
                self.user_id, "", "save_report",
                f"{'Draft saved' if draft else 'Submitted'} week {week} report"
            )

            msg = "Report saved as draft." if draft else "Report submitted successfully!"
            QMessageBox.information(self, "Success", msg)
            self.report_saved.emit(self.report_id)
            self.accept()

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save report: {str(e)}")

    def _load_report(self):
        report = self.db.get_report(self.report_id)
        if not report:
            return
        self.week_spin.setValue(report.week_number)
        self.start_date.setDate(QDate.fromString(report.start_date, "yyyy-MM-dd"))
        self.end_date.setDate(QDate.fromString(report.end_date, "yyyy-MM-dd"))
        self.highlights_edit.setPlainText(report.highlights or "")
        self.shortcomings_edit.setPlainText(report.shortcomings or "")
        self.improvements_edit.setPlainText(report.improvements or "")
        self.plan_summary.setPlainText(report.next_plan_summary or "")
        self._load_tasks()
        self._load_problems()
        self._load_plans()
        self._update_summary()

    def _load_tasks(self):
        tasks, _ = self.report_service.get_report_tasks(self.report_id)
        self.task_table.setRowCount(0)
        for task in tasks:
            row = self.task_table.rowCount()
            self.task_table.insertRow(row)
            self.task_table.setItem(row, 0, QTableWidgetItem(task.category))
            self.task_table.setItem(row, 1, QTableWidgetItem(task.name))
            self.task_table.setItem(row, 2, QTableWidgetItem(task.status))
            self.task_table.setItem(row, 3, QTableWidgetItem(str(task.progress)))
            self.task_table.setItem(row, 4, QTableWidgetItem(task.tags))
            self.task_table.setItem(row, 5, QTableWidgetItem(task.description))
            self.task_table.setItem(row, 6, QTableWidgetItem(str(task.id)))

    def _load_problems(self):
        problems = self.report_service.get_report_problems(self.report_id)
        self.problem_table.setRowCount(0)
        for p in problems:
            row = self.problem_table.rowCount()
            self.problem_table.insertRow(row)
            self.problem_table.setItem(row, 0, QTableWidgetItem(p.description))
            self.problem_table.setItem(row, 1, QTableWidgetItem(p.problem_type))
            self.problem_table.setItem(row, 2, QTableWidgetItem(p.attempted_solution or ""))
            self.problem_table.setItem(row, 3, QTableWidgetItem(p.unresolved_reason or ""))
            self.problem_table.setItem(row, 4, QTableWidgetItem(str(p.id)))

    def _load_plans(self):
        _, plans = self.report_service.get_report_tasks(self.report_id)
        self.plan_table.setRowCount(0)
        for plan in plans:
            row = self.plan_table.rowCount()
            self.plan_table.insertRow(row)
            self.plan_table.setItem(row, 0, QTableWidgetItem(plan.category))
            self.plan_table.setItem(row, 1, QTableWidgetItem(plan.name))
            self.plan_table.setItem(row, 2, QTableWidgetItem(plan.description))
            self.plan_table.setItem(row, 3, QTableWidgetItem(plan.tags))
            self.plan_table.setItem(row, 4, QTableWidgetItem(str(plan.id)))

    def _update_summary(self):
        task_count = self.task_table.rowCount()
        problem_count = self.problem_table.rowCount()
        plan_count = self.plan_table.rowCount()
        self.task_count_label.setText(f"Current tasks: {task_count} | Problems: {problem_count} | Plans: {plan_count}")

        # Summary by category
        cats = {}
        for row in range(task_count):
            cat = self.task_table.item(row, 0).text() if self.task_table.item(row, 0) else "other"
            cats[cat] = cats.get(cat, 0) + 1
        cat_summary = " | ".join(f"{CATEGORY_LABELS.get(k, k)}: {v}" for k, v in cats.items())
        self.summary_label.setText(f"Task breakdown: {cat_summary}" if cat_summary else "No tasks yet.")


# ─── Helper Dialogs ──────────────────────────────────────────────────────────

class TaskEditDialog(QDialog):
    """Dialog for editing a task."""

    def __init__(self, parent=None, data: dict = None):
        super().__init__(parent)
        self.data = data or {}
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("Edit Task" if self.data else "Add Task")
        self.setMinimumWidth(450)

        layout = QFormLayout()

        self.cat_combo = QComboBox()
        for c in CATEGORIES:
            self.cat_combo.addItem(CATEGORY_LABELS.get(c, c), c)
        if self.data.get("category"):
            idx = self.cat_combo.findData(self.data["category"])
            if idx >= 0:
                self.cat_combo.setCurrentIndex(idx)
        layout.addRow("Category:", self.cat_combo)

        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Task name")
        self.name_edit.setText(self.data.get("name", ""))
        layout.addRow("Task Name:", self.name_edit)

        self.desc_edit = QTextEdit()
        self.desc_edit.setPlaceholderText("Description (optional)")
        self.desc_edit.setMaximumHeight(80)
        self.desc_edit.setText(self.data.get("description", ""))
        layout.addRow("Description:", self.desc_edit)

        self.status_combo = QComboBox()
        for s in STATUS_OPTIONS:
            self.status_combo.addItem(TemplateService.get_status_label(s), s)
        if self.data.get("status"):
            idx = self.status_combo.findData(self.data["status"])
            if idx >= 0:
                self.status_combo.setCurrentIndex(idx)
        layout.addRow("Status:", self.status_combo)

        self.progress_spin = QSpinBox()
        self.progress_spin.setRange(0, 100)
        self.progress_spin.setSuffix("%")
        self.progress_spin.setValue(self.data.get("progress", 0))
        layout.addRow("Task Progress:", self.progress_spin)

        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("e.g., urgent,important,review")
        self.tags_edit.setText(self.data.get("tags", ""))
        layout.addRow("Tags:", self.tags_edit)

        btn_layout = QHBoxLayout()
        save_btn = StyledButton("Save", "primary")
        cancel_btn = StyledButton("Cancel", "default")
        save_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addRow(btn_layout)

        self.setLayout(layout)

    def get_data(self) -> dict:
        return {
            "category": self.cat_combo.currentData(),
            "name": self.name_edit.text(),
            "description": self.desc_edit.toPlainText(),
            "status": self.status_combo.currentData(),
            "progress": self.progress_spin.value(),
            "tags": self.tags_edit.text(),
        }


class ProblemEditDialog(QDialog):
    """Dialog for editing a problem record."""

    def __init__(self, parent=None, data: dict = None):
        super().__init__(parent)
        self.data = data or {}
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("Edit Problem" if self.data else "Add Problem")
        self.setMinimumWidth(450)

        layout = QFormLayout()

        self.desc_edit = QTextEdit()
        self.desc_edit.setPlaceholderText("Describe the problem...")
        self.desc_edit.setMaximumHeight(80)
        self.desc_edit.setText(self.data.get("description", ""))
        layout.addRow("Description:", self.desc_edit)

        self.type_combo = QComboBox()
        for pt in PROBLEM_TYPES:
            self.type_combo.addItem(TemplateService.get_problem_type_label(pt), pt)
        if self.data.get("problem_type"):
            idx = self.type_combo.findData(self.data["problem_type"])
            if idx >= 0:
                self.type_combo.setCurrentIndex(idx)
        layout.addRow("Problem Type:", self.type_combo)

        self.solution_edit = QTextEdit()
        self.solution_edit.setPlaceholderText("What have you tried?")
        self.solution_edit.setMaximumHeight(80)
        self.solution_edit.setText(self.data.get("attempted_solution", ""))
        layout.addRow("Attempted Solution:", self.solution_edit)

        self.reason_edit = QTextEdit()
        self.reason_edit.setPlaceholderText("Why is it still unresolved?")
        self.reason_edit.setMaximumHeight(80)
        self.reason_edit.setText(self.data.get("unresolved_reason", ""))
        layout.addRow("Unresolved Reason:", self.reason_edit)

        btn_layout = QHBoxLayout()
        save_btn = StyledButton("Save", "primary")
        cancel_btn = StyledButton("Cancel", "default")
        save_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addRow(btn_layout)

        self.setLayout(layout)

    def get_data(self) -> dict:
        return {
            "description": self.desc_edit.toPlainText(),
            "problem_type": self.type_combo.currentData(),
            "attempted_solution": self.solution_edit.toPlainText(),
            "unresolved_reason": self.reason_edit.toPlainText(),
        }


class PlanEditDialog(QDialog):
    """Dialog for editing a next-week plan."""

    def __init__(self, parent=None, data: dict = None):
        super().__init__(parent)
        self.data = data or {}
        self._init_ui()

    def _init_ui(self):
        self.setWindowTitle("Edit Plan" if self.data else "Add Plan")
        self.setMinimumWidth(450)

        layout = QFormLayout()

        self.cat_combo = QComboBox()
        for c in CATEGORIES:
            self.cat_combo.addItem(CATEGORY_LABELS.get(c, c), c)
        if self.data.get("category"):
            idx = self.cat_combo.findData(self.data["category"])
            if idx >= 0:
                self.cat_combo.setCurrentIndex(idx)
        layout.addRow("Category:", self.cat_combo)

        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Plan name")
        self.name_edit.setText(self.data.get("name", ""))
        layout.addRow("Plan Name:", self.name_edit)

        self.desc_edit = QTextEdit()
        self.desc_edit.setPlaceholderText("Description (optional)")
        self.desc_edit.setMaximumHeight(80)
        self.desc_edit.setText(self.data.get("description", ""))
        layout.addRow("Description:", self.desc_edit)

        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("Tags (comma-separated)")
        self.tags_edit.setText(self.data.get("tags", ""))
        layout.addRow("Tags:", self.tags_edit)

        btn_layout = QHBoxLayout()
        save_btn = StyledButton("Save", "primary")
        cancel_btn = StyledButton("Cancel", "default")
        save_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addRow(btn_layout)

        self.setLayout(layout)

    def get_data(self) -> dict:
        return {
            "category": self.cat_combo.currentData(),
            "name": self.name_edit.text(),
            "description": self.desc_edit.toPlainText(),
            "tags": self.tags_edit.text(),
        }
