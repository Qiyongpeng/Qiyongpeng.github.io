"""Report export service - supports Markdown, Word, PDF, Excel, TXT formats."""

import os
import tempfile
from datetime import datetime
from typing import List, Optional
from database.db_manager import DatabaseManager
from business.template_service import TemplateService


class ExportService:
    """Export weekly reports to various formats."""

    def __init__(self, db: DatabaseManager):
        self.db = db
        self.template_service = TemplateService(db)

    def export_to_markdown(self, report_id: int, output_path: str) -> bool:
        """Export a single report to Markdown."""
        try:
            report = self.db.get_report_with_student(report_id)
            if not report:
                return False
            tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
            plans = self.db.get_tasks_by_report(report_id, is_plan=True)
            problems = self.db.get_problems_by_report(report_id)
            comments = self.db.get_comments_by_report(report_id)

            lines = [
                f"# Weekly Report - Week {report['week_number']}",
                f"",
                f"**Student**: {report.get('student_name', 'N/A')}",
                f"**Class**: {report['class_name']}",
                f"**Period**: {report['start_date']} ~ {report['end_date']}",
                f"**Status**: {report['status']}",
                f"",
                f"---",
                f"",
                f"## Tasks This Week",
                f"",
            ]

            if tasks:
                for i, task in enumerate(tasks, 1):
                    cat_label = self.template_service.get_category_label(task.category)
                    status_label = self.template_service.get_status_label(task.status)
                    lines.extend([
                        f"### {i}. [{cat_label}] {task.name}",
                        f"- **Status**: {status_label} | **Progress**: {task.progress}%",
                        f"- **Description**: {task.description or 'N/A'}",
                        f"- **Tags**: {task.tags or 'N/A'}",
                        f"",
                    ])
            else:
                lines.append("*No tasks recorded.*\n")

            lines.extend(["## Problems & Reflection", ""])
            if problems:
                for p in problems:
                    ptype = self.template_service.get_problem_type_label(p.problem_type)
                    lines.extend([
                        f"- **Problem**: {p.description}",
                        f"  - **Type**: {ptype}",
                        f"  - **Attempted Solution**: {p.attempted_solution or 'N/A'}",
                        f"  - **Unresolved Reason**: {p.unresolved_reason or 'N/A'}",
                        f"",
                    ])
            else:
                lines.append("*No problems recorded.*\n")

            if report.get("highlights"):
                lines.extend(["**Highlights**:", report["highlights"], ""])
            if report.get("shortcomings"):
                lines.extend(["**Shortcomings**:", report["shortcomings"], ""])
            if report.get("improvements"):
                lines.extend(["**Improvements**:", report["improvements"], ""])

            lines.extend(["## Next Week Plan", ""])
            if plans:
                for i, plan in enumerate(plans, 1):
                    cat_label = self.template_service.get_category_label(plan.category)
                    lines.extend([
                        f"### {i}. [{cat_label}] {plan.name}",
                        f"- **Description**: {plan.description or 'N/A'}",
                        f"",
                    ])
            else:
                lines.append("*No plans recorded.*\n")

            if report.get("next_plan_summary"):
                lines.extend(["**Plan Summary**:", report["next_plan_summary"], ""])

            if comments:
                lines.extend(["## Teacher Comments", ""])
                for c in comments:
                    lines.extend([
                        f"- **{c.get('teacher_name', 'Teacher')}**: {c['content']}",
                        f"  *{c['created_at']}*",
                        f"",
                    ])
                    if c.get("student_reply"):
                        lines.append(f"  - **Student Reply**: {c['student_reply']}\n")
                    if c.get("teacher_reply"):
                        lines.append(f"  - **Teacher Reply**: {c['teacher_reply']}\n")

            content = "\n".join(lines)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Export MD error: {e}")
            return False

    def export_to_txt(self, report_id: int, output_path: str) -> bool:
        """Export to plain text (simplified markdown without formatting)."""
        try:
            report = self.db.get_report_with_student(report_id)
            if not report:
                return False
            tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
            plans = self.db.get_tasks_by_report(report_id, is_plan=True)
            problems = self.db.get_problems_by_report(report_id)

            lines = [
                f"Weekly Report - Week {report['week_number']}",
                f"=" * 40,
                f"Student: {report.get('student_name', 'N/A')}",
                f"Class: {report['class_name']}",
                f"Period: {report['start_date']} - {report['end_date']}",
                f"Status: {report['status']}",
                f"",
                f"Tasks This Week:",
                f"-" * 30,
            ]
            if tasks:
                for task in tasks:
                    cat = self.template_service.get_category_label(task.category)
                    status = self.template_service.get_status_label(task.status)
                    lines.append(f"  [{cat}] {task.name} - {status} ({task.progress}%)")
            else:
                lines.append("  (none)")

            if problems:
                lines.extend(["", f"Problems:", "-" * 30])
                for p in problems:
                    lines.append(f"  [{p.problem_type}] {p.description}")

            lines.extend(["", f"Next Week Plan:", "-" * 30])
            if plans:
                for plan in plans:
                    cat = self.template_service.get_category_label(plan.category)
                    lines.append(f"  [{cat}] {plan.name}")
            else:
                lines.append("  (none)")

            if report.get("next_plan_summary"):
                lines.extend(["", f"Plan Summary:", report["next_plan_summary"]])

            content = "\n".join(lines)
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Export TXT error: {e}")
            return False

    def export_to_docx(self, report_id: int, output_path: str) -> bool:
        """Export to Word document."""
        try:
            from docx import Document
            from docx.shared import Inches, Pt, RGBColor
            from docx.enum.text import WD_ALIGN_PARAGRAPH
        except ImportError:
            return False

        try:
            report = self.db.get_report_with_student(report_id)
            if not report:
                return False
            tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
            plans = self.db.get_tasks_by_report(report_id, is_plan=True)
            problems = self.db.get_problems_by_report(report_id)
            comments = self.db.get_comments_by_report(report_id)

            doc = Document()

            # Title
            title = doc.add_heading(f"Weekly Report - Week {report['week_number']}", level=1)
            title.alignment = WD_ALIGN_PARAGRAPH.CENTER

            # Info
            info = doc.add_table(rows=4, cols=2)
            info.style = "Light Shading Accent 1"
            data = [
                ("Student", report.get("student_name", "N/A")),
                ("Class", report["class_name"]),
                ("Period", f"{report['start_date']} ~ {report['end_date']}"),
                ("Status", report["status"]),
            ]
            for i, (k, v) in enumerate(data):
                info.rows[i].cells[0].text = k
                info.rows[i].cells[1].text = v

            doc.add_heading("Tasks This Week", level=2)
            if tasks:
                table = doc.add_table(rows=1, cols=5)
                table.style = "Light Grid Accent 1"
                hdr = table.rows[0].cells
                hdr[0].text = "Category"
                hdr[1].text = "Task Name"
                hdr[2].text = "Status"
                hdr[3].text = "Progress"
                hdr[4].text = "Tags"
                for task in tasks:
                    row = table.add_row().cells
                    row[0].text = self.template_service.get_category_label(task.category)
                    row[1].text = task.name
                    row[2].text = self.template_service.get_status_label(task.status)
                    row[3].text = f"{task.progress}%"
                    row[4].text = task.tags or "-"
            else:
                doc.add_paragraph("No tasks recorded.")

            doc.add_heading("Problems & Reflection", level=2)
            if problems:
                for p in problems:
                    ptype = self.template_service.get_problem_type_label(p.problem_type)
                    doc.add_paragraph(f"{p.description}", style="List Bullet")
                    doc.add_paragraph(f"Type: {ptype}, Solution: {p.attempted_solution or 'N/A'}")
            else:
                doc.add_paragraph("No problems recorded.")

            if report.get("highlights"):
                doc.add_paragraph(f"Highlights: {report['highlights']}")

            doc.add_heading("Next Week Plan", level=2)
            if plans:
                for plan in plans:
                    cat = self.template_service.get_category_label(plan.category)
                    doc.add_paragraph(f"[{cat}] {plan.name}", style="List Bullet")
            else:
                doc.add_paragraph("No plans recorded.")

            if comments:
                doc.add_heading("Teacher Comments", level=2)
                for c in comments:
                    p = doc.add_paragraph()
                    run = p.add_run(f"{c.get('teacher_name', 'Teacher')}: ")
                    run.bold = True
                    p.add_run(c["content"])

            doc.save(output_path)
            return True
        except Exception as e:
            print(f"Export DOCX error: {e}")
            return False

    def export_to_pdf(self, report_id: int, output_path: str) -> bool:
        """Export to PDF through a temporary Word document."""
        temp_docx = None
        try:
            fd, temp_docx = tempfile.mkstemp(suffix=".docx")
            os.close(fd)

            if not self.export_to_docx(report_id, temp_docx):
                return False

            try:
                from docx2pdf import convert

                convert(temp_docx, output_path)
                return os.path.exists(output_path)
            except Exception:
                pass

            try:
                import win32com.client

                word = win32com.client.DispatchEx("Word.Application")
                word.Visible = False
                doc = word.Documents.Open(os.path.abspath(temp_docx))
                doc.SaveAs(os.path.abspath(output_path), FileFormat=17)
                doc.Close(False)
                word.Quit()
                return os.path.exists(output_path)
            except Exception as e:
                print(f"Export PDF error: {e}")
                return False
        except Exception as e:
            print(f"Export PDF error: {e}")
            return False
        finally:
            if temp_docx and os.path.exists(temp_docx):
                try:
                    os.remove(temp_docx)
                except OSError:
                    pass

    def export_statistics_to_excel(self, class_name: str, week_numbers: List[int],
                                    output_path: str) -> bool:
        """Export class statistics to Excel."""
        try:
            from openpyxl import Workbook
        except ImportError:
            return False

        try:
            wb = Workbook()
            for week in week_numbers:
                ws = wb.create_sheet(title=f"Week {week}")
                submissions = self.db.get_submission_status(class_name, week)
                ws.append(["Student Name", "Student ID", "Status"])

                for s in submissions:
                    status = s.get("report_status", "Not Submitted") or "Not Submitted"
                    ws.append([s["display_name"], s.get("student_id", ""), status])

                # Summary row
                ws.append([])
                submitted = sum(1 for s in submissions if s.get("report_status"))
                ws.append(["Submitted", submitted])
                ws.append(["Unsubmitted", len(submissions) - submitted])
                ws.append(["Submission Rate", f"{submitted / len(submissions) * 100:.1f}%" if submissions else "0%"])

            # Remove default sheet
            if "Sheet" in wb.sheetnames:
                del wb["Sheet"]

            wb.save(output_path)
            return True
        except Exception as e:
            print(f"Export Excel error: {e}")
            return False

    def export_batch_markdown(self, report_ids: List[int], output_dir: str) -> int:
        """Export multiple reports to Markdown files in a directory."""
        os.makedirs(output_dir, exist_ok=True)
        count = 0
        for rid in report_ids:
            report = self.db.get_report_with_student(rid)
            if report:
                name = report.get("student_name", f"report_{rid}")
                fname = f"{name}_Week{report['week_number']}.md"
                fpath = os.path.join(output_dir, fname)
                if self.export_to_markdown(rid, fpath):
                    count += 1
        return count
