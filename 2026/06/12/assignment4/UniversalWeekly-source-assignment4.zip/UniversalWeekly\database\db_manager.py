"""Database manager - handles all SQLite operations."""

import os
import sqlite3
from datetime import datetime
from typing import List, Optional, Dict, Any
from contextlib import contextmanager

from .models import CREATE_TABLES_SQL, User, WeeklyReport, Task, ProblemRecord, Comment, Template, OperationLog
from .encryption import DataEncryption


class DatabaseManager:
    """Central database access layer for the application."""

    def __init__(self, db_path: str = None):
        if db_path is None:
            db_dir = os.path.dirname(os.path.dirname(__file__))
            db_path = os.path.join(db_dir, "universal_weekly.db")
        self.db_path = db_path
        self.encryption = DataEncryption()
        self._init_database()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    @contextmanager
    def _get_db(self):
        conn = self._get_connection()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_database(self):
        """Create all tables if they don't exist."""
        with self._get_db() as conn:
            conn.executescript(CREATE_TABLES_SQL)

    # ─── User Operations ─────────────────────────────────────────────────────

    def register_user(self, username: str, password: str, role: str,
                      display_name: str, student_id: str = "", class_name: str = "",
                      email: str = "", phone: str = "") -> Optional[User]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT id FROM user_info WHERE username = ?", (username,)
            )
            if cursor.fetchone():
                return None
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            password_hash = self.encryption.encrypt_password(password)
            conn.execute(
                """INSERT INTO user_info (username, password_hash, role, display_name,
                   student_id, class_name, email, phone, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (username, password_hash, role, display_name,
                 student_id, class_name, email, phone, now)
            )
            user_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            row = conn.execute("SELECT * FROM user_info WHERE id = ?", (user_id,)).fetchone()
            return self._row_to_user(row) if row else None

    def authenticate(self, username: str, password: str) -> Optional[User]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT * FROM user_info WHERE username = ? AND is_active = 1",
                (username,)
            )
            row = cursor.fetchone()
            if row is None:
                return None
            stored_hash = row["password_hash"]
            if self.encryption.verify_password(password, stored_hash):
                return self._row_to_user(row)
            return None

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT * FROM user_info WHERE id = ?", (user_id,)
            )
            row = cursor.fetchone()
            return self._row_to_user(row) if row else None

    def get_students_by_class(self, class_name: str) -> List[User]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT * FROM user_info WHERE class_name = ? AND role = 'student' AND is_active = 1",
                (class_name,)
            )
            return [self._row_to_user(row) for row in cursor.fetchall()]

    def get_all_classes(self) -> List[str]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT DISTINCT class_name FROM user_info WHERE class_name != '' ORDER BY class_name"
            )
            return [row["class_name"] for row in cursor.fetchall()]

    def update_user(self, user_id: int, **kwargs) -> bool:
        allowed = {"display_name", "email", "phone", "class_name", "student_id"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [user_id]
        with self._get_db() as conn:
            conn.execute(f"UPDATE user_info SET {set_clause} WHERE id = ?", values)
            return True

    # ─── Weekly Report Operations ────────────────────────────────────────────

    def create_report(self, report: WeeklyReport) -> Optional[int]:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            conn.execute(
                """INSERT INTO weekly_report (user_id, class_name, week_number, start_date, end_date,
                   status, highlights, shortcomings, improvements, next_plan_summary, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (report.user_id, report.class_name, report.week_number,
                 report.start_date, report.end_date, report.status,
                 report.highlights, report.shortcomings, report.improvements,
                 report.next_plan_summary, now, now)
            )
            return conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def update_report(self, report_id: int, **kwargs) -> bool:
        allowed = {"status", "highlights", "shortcomings", "improvements", "next_plan_summary"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        updates["updated_at"] = now
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [report_id]
        with self._get_db() as conn:
            conn.execute(f"UPDATE weekly_report SET {set_clause} WHERE id = ?", values)
            return True

    def get_report(self, report_id: int) -> Optional[WeeklyReport]:
        with self._get_db() as conn:
            cursor = conn.execute("SELECT * FROM weekly_report WHERE id = ?", (report_id,))
            row = cursor.fetchone()
            return self._row_to_report(row) if row else None

    def get_reports_by_user(self, user_id: int) -> List[WeeklyReport]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT * FROM weekly_report WHERE user_id = ? ORDER BY week_number DESC",
                (user_id,)
            )
            return [self._row_to_report(row) for row in cursor.fetchall()]

    def get_reports_by_class_and_week(self, class_name: str, week_number: int = None) -> List[WeeklyReport]:
        with self._get_db() as conn:
            if week_number:
                cursor = conn.execute(
                    """SELECT wr.*, ui.display_name as student_name, ui.student_id as student_number
                       FROM weekly_report wr JOIN user_info ui ON wr.user_id = ui.id
                       WHERE wr.class_name = ? AND wr.week_number = ?
                       ORDER BY ui.display_name""",
                    (class_name, week_number)
                )
            else:
                cursor = conn.execute(
                    """SELECT wr.*, ui.display_name as student_name, ui.student_id as student_number
                       FROM weekly_report wr JOIN user_info ui ON wr.user_id = ui.id
                       WHERE wr.class_name = ?
                       ORDER BY wr.week_number DESC, ui.display_name""",
                    (class_name,)
                )
            return [dict(row) for row in cursor.fetchall()]

    def get_report_with_student(self, report_id: int) -> Optional[Dict]:
        with self._get_db() as conn:
            cursor = conn.execute(
                """SELECT wr.*, ui.display_name as student_name, ui.student_id as student_number
                   FROM weekly_report wr JOIN user_info ui ON wr.user_id = ui.id
                   WHERE wr.id = ?""",
                (report_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_submission_status(self, class_name: str, week_number: int) -> List[Dict]:
        """Get submission status for all students in a class for a given week."""
        with self._get_db() as conn:
            cursor = conn.execute(
                """SELECT ui.id as user_id, ui.display_name, ui.student_id,
                          wr.id as report_id, wr.status as report_status
                   FROM user_info ui
                   LEFT JOIN weekly_report wr ON wr.user_id = ui.id
                       AND wr.week_number = ?
                   WHERE ui.class_name = ? AND ui.role = 'student' AND ui.is_active = 1
                   ORDER BY ui.display_name""",
                (week_number, class_name)
            )
            return [dict(row) for row in cursor.fetchall()]

    def delete_report(self, report_id: int) -> bool:
        with self._get_db() as conn:
            conn.execute("DELETE FROM weekly_report WHERE id = ?", (report_id,))
            return True

    # ─── Task Operations ─────────────────────────────────────────────────────

    def add_task(self, task: Task) -> Optional[int]:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            conn.execute(
                """INSERT INTO task (report_id, category, name, description, start_date, end_date,
                   status, progress, result, attachment_path, tags, is_plan, source_task_id, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (task.report_id, task.category, task.name, task.description,
                 task.start_date, task.end_date, task.status, task.progress,
                 task.result, task.attachment_path, task.tags,
                 1 if task.is_plan else 0, task.source_task_id, now)
            )
            return conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def update_task(self, task_id: int, **kwargs) -> bool:
        allowed = {"category", "name", "description", "status", "progress",
                   "result", "attachment_path", "tags", "end_date"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [task_id]
        with self._get_db() as conn:
            conn.execute(f"UPDATE task SET {set_clause} WHERE id = ?", values)
            return True

    def get_tasks_by_report(self, report_id: int, is_plan: bool = False) -> List[Task]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT * FROM task WHERE report_id = ? AND is_plan = ? ORDER BY created_at",
                (report_id, 1 if is_plan else 0)
            )
            return [self._row_to_task(row) for row in cursor.fetchall()]

    def delete_task(self, task_id: int) -> bool:
        with self._get_db() as conn:
            conn.execute("DELETE FROM task WHERE id = ?", (task_id,))
            return True

    def bulk_update_task_status(self, task_ids: List[int], status: str, progress: int = None) -> bool:
        with self._get_db() as conn:
            for tid in task_ids:
                if progress is not None:
                    conn.execute(
                        "UPDATE task SET status = ?, progress = ? WHERE id = ?",
                        (status, progress, tid)
                    )
                else:
                    conn.execute(
                        "UPDATE task SET status = ? WHERE id = ?",
                        (status, tid)
                    )
            return True

    # ─── Problem Record Operations ───────────────────────────────────────────

    def add_problem(self, problem: ProblemRecord) -> Optional[int]:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            conn.execute(
                """INSERT INTO problem_record (report_id, description, problem_type,
                   attempted_solution, unresolved_reason, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (problem.report_id, problem.description, problem.problem_type,
                 problem.attempted_solution, problem.unresolved_reason, now)
            )
            return conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def update_problem(self, problem_id: int, **kwargs) -> bool:
        allowed = {"description", "problem_type", "attempted_solution", "unresolved_reason"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [problem_id]
        with self._get_db() as conn:
            conn.execute(f"UPDATE problem_record SET {set_clause} WHERE id = ?", values)
            return True

    def get_problems_by_report(self, report_id: int) -> List[ProblemRecord]:
        with self._get_db() as conn:
            cursor = conn.execute(
                "SELECT * FROM problem_record WHERE report_id = ? ORDER BY created_at",
                (report_id,)
            )
            return [self._row_to_problem(row) for row in cursor.fetchall()]

    def delete_problem(self, problem_id: int) -> bool:
        with self._get_db() as conn:
            conn.execute("DELETE FROM problem_record WHERE id = ?", (problem_id,))
            return True

    # ─── Comment Operations ──────────────────────────────────────────────────

    def add_comment(self, comment: Comment) -> Optional[int]:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            conn.execute(
                """INSERT INTO comment (report_id, teacher_id, content, comment_type,
                   is_batch, is_read, student_reply, teacher_reply, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (comment.report_id, comment.teacher_id, comment.content,
                 comment.comment_type, 1 if comment.is_batch else 0,
                 0, comment.student_reply, comment.teacher_reply, now, now)
            )
            return conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def add_batch_comments(self, report_ids: List[int], teacher_id: int,
                           content: str, comment_type: str = "general") -> int:
        count = 0
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            for rid in report_ids:
                conn.execute(
                    """INSERT INTO comment (report_id, teacher_id, content, comment_type,
                       is_batch, is_read, student_reply, teacher_reply, created_at, updated_at)
                       VALUES (?, ?, ?, ?, 1, 0, '', ?, ?, ?)""",
                    (rid, teacher_id, content, comment_type, "", now, now)
                )
                count += 1
            return count

    def get_comments_by_report(self, report_id: int) -> List[Comment]:
        with self._get_db() as conn:
            cursor = conn.execute(
                """SELECT c.*, ui.display_name as teacher_name
                   FROM comment c JOIN user_info ui ON c.teacher_id = ui.id
                   WHERE c.report_id = ? ORDER BY c.created_at DESC""",
                (report_id,)
            )
            return [dict(row) for row in cursor.fetchall()]

    def mark_comment_read(self, comment_id: int) -> bool:
        with self._get_db() as conn:
            conn.execute("UPDATE comment SET is_read = 1 WHERE id = ?", (comment_id,))
            return True

    def reply_to_comment(self, comment_id: int, reply: str, is_teacher: bool = False) -> bool:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            if is_teacher:
                conn.execute(
                    "UPDATE comment SET teacher_reply = ?, updated_at = ? WHERE id = ?",
                    (reply, now, comment_id)
                )
            else:
                conn.execute(
                    "UPDATE comment SET student_reply = ?, updated_at = ? WHERE id = ?",
                    (reply, now, comment_id)
                )
            return True

    def get_unread_comment_count(self, user_id: int) -> int:
        with self._get_db() as conn:
            cursor = conn.execute(
                """SELECT COUNT(*) as cnt FROM comment c
                   JOIN weekly_report wr ON c.report_id = wr.id
                   WHERE wr.user_id = ? AND c.is_read = 0""",
                (user_id,)
            )
            return cursor.fetchone()["cnt"]

    # ─── Template Operations ─────────────────────────────────────────────────

    def add_template(self, template: Template) -> Optional[int]:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            conn.execute(
                """INSERT INTO template (user_id, name, template_type, content, is_shared, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (template.user_id, template.name, template.template_type,
                 template.content, 1 if template.is_shared else 0, now, now)
            )
            return conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    def get_templates(self, user_id: int = None, template_type: str = None) -> List[Template]:
        with self._get_db() as conn:
            query = "SELECT * FROM template WHERE (user_id IS NULL OR user_id = ? OR is_shared = 1)"
            params = [user_id] if user_id else [0]
            if template_type:
                query += " AND template_type = ?"
                params.append(template_type)
            query += " ORDER BY created_at DESC"
            cursor = conn.execute(query, params)
            return [self._row_to_template(row) for row in cursor.fetchall()]

    def delete_template(self, template_id: int) -> bool:
        with self._get_db() as conn:
            cursor = conn.execute("DELETE FROM template WHERE id = ?", (template_id,))
            return cursor.rowcount > 0

    # ─── Operation Log ───────────────────────────────────────────────────────

    def log_operation(self, user_id: int, username: str, op_type: str, description: str = ""):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._get_db() as conn:
            conn.execute(
                "INSERT INTO operation_log (user_id, username, operation_type, description, created_at) VALUES (?, ?, ?, ?, ?)",
                (user_id, username, op_type, description, now)
            )

    def get_operation_logs(self, user_id: int = None, limit: int = 100) -> List[OperationLog]:
        with self._get_db() as conn:
            if user_id:
                cursor = conn.execute(
                    "SELECT * FROM operation_log WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
                    (user_id, limit)
                )
            else:
                cursor = conn.execute(
                    "SELECT * FROM operation_log ORDER BY created_at DESC LIMIT ?",
                    (limit,)
                )
            return [self._row_to_log(row) for row in cursor.fetchall()]

    # ─── Statistics ──────────────────────────────────────────────────────────

    def get_class_weekly_stats(self, class_name: str, week_number: int) -> Dict:
        with self._get_db() as conn:
            total = conn.execute(
                "SELECT COUNT(*) as cnt FROM user_info WHERE class_name = ? AND role = 'student' AND is_active = 1",
                (class_name,)
            ).fetchone()["cnt"]

            submitted = conn.execute(
                "SELECT COUNT(DISTINCT user_id) as cnt FROM weekly_report WHERE class_name = ? AND week_number = ?",
                (class_name, week_number)
            ).fetchone()["cnt"]

            avg_progress = conn.execute(
                """SELECT COALESCE(AVG(t.progress), 0) as avg_p FROM task t
                   JOIN weekly_report wr ON t.report_id = wr.id
                   WHERE wr.class_name = ? AND wr.week_number = ? AND t.is_plan = 0""",
                (class_name, week_number)
            ).fetchone()["avg_p"]

            delayed = conn.execute(
                """SELECT COUNT(*) as cnt FROM task t
                   JOIN weekly_report wr ON t.report_id = wr.id
                   WHERE wr.class_name = ? AND wr.week_number = ? AND t.status = 'delayed'""",
                (class_name, week_number)
            ).fetchone()["cnt"]

            return {
                "total_students": total,
                "submitted": submitted,
                "unsubmitted": total - submitted,
                "avg_progress": round(avg_progress, 1),
                "delayed_tasks": delayed,
            }

    def get_student_progress_history(self, user_id: int) -> List[Dict]:
        with self._get_db() as conn:
            cursor = conn.execute(
                """SELECT wr.week_number, wr.start_date, wr.end_date,
                          COALESCE(AVG(t.progress), 0) as avg_progress
                   FROM weekly_report wr
                   LEFT JOIN task t ON t.report_id = wr.id AND t.is_plan = 0
                   WHERE wr.user_id = ?
                   GROUP BY wr.id ORDER BY wr.week_number""",
                (user_id,)
            )
            return [dict(row) for row in cursor.fetchall()]

    def get_high_frequency_problems(self, class_name: str, week_number: int) -> List[Dict]:
        with self._get_db() as conn:
            cursor = conn.execute(
                """SELECT pr.problem_type, COUNT(*) as cnt, GROUP_CONCAT(pr.description, '|||') as samples
                   FROM problem_record pr
                   JOIN weekly_report wr ON pr.report_id = wr.id
                   WHERE wr.class_name = ? AND wr.week_number = ?
                   GROUP BY pr.problem_type ORDER BY cnt DESC""",
                (class_name, week_number)
            )
            return [dict(row) for row in cursor.fetchall()]

    # ─── Backup & Restore ────────────────────────────────────────────────────

    def backup(self, backup_path: str) -> bool:
        try:
            conn = self._get_connection()
            bconn = sqlite3.connect(backup_path)
            conn.backup(bconn)
            bconn.close()
            conn.close()
            return True
        except Exception:
            return False

    def restore(self, backup_path: str) -> bool:
        if not os.path.exists(backup_path):
            return False
        try:
            bconn = sqlite3.connect(backup_path)
            conn = self._get_connection()
            bconn.backup(conn)
            conn.close()
            bconn.close()
            return True
        except Exception:
            return False

    # ─── Data Cleanup ────────────────────────────────────────────────────────

    def cleanup_old_reports(self, before_date: str) -> int:
        with self._get_db() as conn:
            cursor = conn.execute(
                "DELETE FROM weekly_report WHERE created_at < ?",
                (before_date,)
            )
            return cursor.rowcount

    # ─── Helper Methods ──────────────────────────────────────────────────────

    @staticmethod
    def _row_to_user(row) -> Optional[User]:
        if row is None:
            return None
        return User(
            id=row["id"], username=row["username"],
            password_hash=row["password_hash"], role=row["role"],
            display_name=row["display_name"], student_id=row["student_id"],
            class_name=row["class_name"], email=row["email"],
            phone=row["phone"], created_at=row["created_at"],
            is_active=bool(row["is_active"])
        )

    @staticmethod
    def _row_to_report(row) -> Optional[WeeklyReport]:
        if row is None:
            return None
        return WeeklyReport(
            id=row["id"], user_id=row["user_id"], class_name=row["class_name"],
            week_number=row["week_number"], start_date=row["start_date"],
            end_date=row["end_date"], status=row["status"],
            highlights=row["highlights"], shortcomings=row["shortcomings"],
            improvements=row["improvements"],
            next_plan_summary=row["next_plan_summary"],
            created_at=row["created_at"], updated_at=row["updated_at"]
        )

    @staticmethod
    def _row_to_task(row) -> Optional[Task]:
        if row is None:
            return None
        return Task(
            id=row["id"], report_id=row["report_id"],
            category=row["category"], name=row["name"],
            description=row["description"], start_date=row["start_date"],
            end_date=row["end_date"], status=row["status"],
            progress=row["progress"], result=row["result"],
            attachment_path=row["attachment_path"], tags=row["tags"],
            is_plan=bool(row["is_plan"]),
            source_task_id=row["source_task_id"],
            created_at=row["created_at"]
        )

    @staticmethod
    def _row_to_problem(row) -> Optional[ProblemRecord]:
        if row is None:
            return None
        return ProblemRecord(
            id=row["id"], report_id=row["report_id"],
            description=row["description"],
            problem_type=row["problem_type"],
            attempted_solution=row["attempted_solution"],
            unresolved_reason=row["unresolved_reason"],
            created_at=row["created_at"]
        )

    @staticmethod
    def _row_to_template(row) -> Optional[Template]:
        if row is None:
            return None
        return Template(
            id=row["id"], user_id=row["user_id"], name=row["name"],
            template_type=row["template_type"], content=row["content"],
            is_shared=bool(row["is_shared"]),
            created_at=row["created_at"], updated_at=row["updated_at"]
        )

    @staticmethod
    def _row_to_log(row) -> Optional[OperationLog]:
        if row is None:
            return None
        return OperationLog(
            id=row["id"], user_id=row["user_id"], username=row["username"],
            operation_type=row["operation_type"], description=row["description"],
            created_at=row["created_at"]
        )
