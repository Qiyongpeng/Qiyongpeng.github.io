"""Database model definitions and table schema."""

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Optional


# ─── User Model ──────────────────────────────────────────────────────────────

@dataclass
class User:
    """User account: student or teacher."""
    id: Optional[int] = None
    username: str = ""
    password_hash: str = ""
    role: str = "student"          # "student" or "teacher"
    display_name: str = ""
    student_id: str = ""           # student number / teacher work number
    class_name: str = ""           # class name
    email: str = ""
    phone: str = ""
    created_at: str = ""
    is_active: bool = True


# ─── Weekly Report Model ─────────────────────────────────────────────────────

@dataclass
class WeeklyReport:
    """Weekly report: core document."""
    id: Optional[int] = None
    user_id: int = 0
    class_name: str = ""
    week_number: int = 0
    start_date: str = ""
    end_date: str = ""
    status: str = "draft"          # draft, submitted, reviewed, approved, rejected
    highlights: str = ""           # weekly highlights
    shortcomings: str = ""         # shortcomings
    improvements: str = ""         # improvement measures
    next_plan_summary: str = ""    # next week plan summary
    created_at: str = ""
    updated_at: str = ""


# ─── Task Model ──────────────────────────────────────────────────────────────

@dataclass
class Task:
    """Individual task within a weekly report."""
    id: Optional[int] = None
    report_id: int = 0
    category: str = "study"        # study, homework, project, club, personal, other
    name: str = ""
    description: str = ""
    start_date: str = ""
    end_date: str = ""
    status: str = "not_started"    # not_started, in_progress, completed, delayed
    progress: int = 0              # 0-100
    result: str = ""
    attachment_path: str = ""
    tags: str = ""                 # comma-separated tags
    is_plan: bool = False          # True for next-week planning tasks
    source_task_id: Optional[int] = None  # link to carried-over task
    created_at: str = ""


# ─── Problem Record Model ────────────────────────────────────────────────────

@dataclass
class ProblemRecord:
    """Problem record within a weekly report."""
    id: Optional[int] = None
    report_id: int = 0
    description: str = ""
    problem_type: str = "time_management"  # time_management, difficulty, resource, other
    attempted_solution: str = ""
    unresolved_reason: str = ""
    created_at: str = ""


# ─── Comment Model ───────────────────────────────────────────────────────────

@dataclass
class Comment:
    """Teacher comment on a weekly report."""
    id: Optional[int] = None
    report_id: int = 0
    teacher_id: int = 0
    content: str = ""
    comment_type: str = "general"  # general, task_specific, problem_specific, plan_specific
    is_batch: bool = False
    is_read: bool = False
    student_reply: str = ""
    teacher_reply: str = ""
    created_at: str = ""
    updated_at: str = ""


# ─── Template Model ──────────────────────────────────────────────────────────

@dataclass
class Template:
    """Report template or comment template."""
    id: Optional[int] = None
    user_id: Optional[int] = None  # None = system built-in
    name: str = ""
    template_type: str = "report"  # report, comment, statistic
    content: str = ""              # JSON configuration
    is_shared: bool = False
    created_at: str = ""
    updated_at: str = ""


# ─── Operation Log Model ─────────────────────────────────────────────────────

@dataclass
class OperationLog:
    """Audit log for user operations."""
    id: Optional[int] = None
    user_id: int = 0
    username: str = ""
    operation_type: str = ""       # login, create_report, edit_report, comment, export, etc.
    description: str = ""
    created_at: str = ""


# ─── Table Schema SQL ────────────────────────────────────────────────────────

CREATE_TABLES_SQL = """
CREATE TABLE IF NOT EXISTS user_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('student', 'teacher')),
    display_name TEXT NOT NULL,
    student_id TEXT DEFAULT '',
    class_name TEXT DEFAULT '',
    email TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    is_active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS weekly_report (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    class_name TEXT DEFAULT '',
    week_number INTEGER NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    status TEXT DEFAULT 'draft' CHECK(status IN ('draft','submitted','reviewed','approved','rejected')),
    highlights TEXT DEFAULT '',
    shortcomings TEXT DEFAULT '',
    improvements TEXT DEFAULT '',
    next_plan_summary TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_info(id)
);

CREATE TABLE IF NOT EXISTS task (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id INTEGER NOT NULL,
    category TEXT NOT NULL DEFAULT 'study',
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    start_date TEXT DEFAULT '',
    end_date TEXT DEFAULT '',
    status TEXT DEFAULT 'not_started' CHECK(status IN ('not_started','in_progress','completed','delayed')),
    progress INTEGER DEFAULT 0 CHECK(progress >= 0 AND progress <= 100),
    result TEXT DEFAULT '',
    attachment_path TEXT DEFAULT '',
    tags TEXT DEFAULT '',
    is_plan INTEGER DEFAULT 0,
    source_task_id INTEGER DEFAULT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (report_id) REFERENCES weekly_report(id) ON DELETE CASCADE,
    FOREIGN KEY (source_task_id) REFERENCES task(id)
);

CREATE TABLE IF NOT EXISTS problem_record (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    problem_type TEXT DEFAULT 'other' CHECK(problem_type IN ('time_management','difficulty','resource','other')),
    attempted_solution TEXT DEFAULT '',
    unresolved_reason TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (report_id) REFERENCES weekly_report(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS comment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id INTEGER NOT NULL,
    teacher_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    comment_type TEXT DEFAULT 'general',
    is_batch INTEGER DEFAULT 0,
    is_read INTEGER DEFAULT 0,
    student_reply TEXT DEFAULT '',
    teacher_reply TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (report_id) REFERENCES weekly_report(id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES user_info(id)
);

CREATE TABLE IF NOT EXISTS template (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER DEFAULT NULL,
    name TEXT NOT NULL,
    template_type TEXT NOT NULL CHECK(template_type IN ('report','comment','statistic')),
    content TEXT NOT NULL,
    is_shared INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_info(id)
);

CREATE TABLE IF NOT EXISTS operation_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT DEFAULT '',
    operation_type TEXT NOT NULL,
    description TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user_info(id)
);
"""
