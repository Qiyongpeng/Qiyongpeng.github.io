"""AI model call history dialog."""

from PyQt6.QtWidgets import QDialog, QHBoxLayout, QLabel, QVBoxLayout

from database.db_manager import DatabaseManager
from ui.common_widgets import ReadOnlyTable, StyledButton


class AICallHistoryDialog(QDialog):
    """Show AI-related operation logs."""

    def __init__(self, db: DatabaseManager, user_id: int | None = None, parent=None):
        super().__init__(parent)
        self.db = db
        self.user_id = user_id
        self._init_ui()
        self._load_logs()

    def _init_ui(self):
        self.setWindowTitle("AI Call History")
        self.setMinimumSize(860, 480)
        self.setStyleSheet("""
            QDialog { background-color: #F5F7FA; }
            QLabel { color: #2C3E50; }
        """)

        layout = QVBoxLayout()
        title = QLabel("AI Model Call History")
        title.setStyleSheet("font-size: 18px; font-weight: bold; padding: 4px;")
        layout.addWidget(title)

        hint = QLabel(
            "This list records weekly-report AI generation calls, including provider, model, language, "
            "fill mode, engine, and input notes summary."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #7F8C8D; padding: 4px;")
        layout.addWidget(hint)

        self.table = ReadOnlyTable(["Time", "User", "Action", "Details"])
        layout.addWidget(self.table, 1)

        self.empty_label = QLabel("")
        self.empty_label.setStyleSheet("color: #7F8C8D; padding: 4px;")
        layout.addWidget(self.empty_label)

        btn_row = QHBoxLayout()
        refresh_btn = StyledButton("Refresh", "default")
        refresh_btn.clicked.connect(self._load_logs)
        close_btn = StyledButton("Close", "primary")
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(refresh_btn)
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

        self.setLayout(layout)

    def _load_logs(self):
        self.table.clear_all()
        logs = self.db.get_operation_logs(user_id=self.user_id, limit=200)
        ai_logs = [log for log in logs if str(log.operation_type).startswith("ai_")]
        for log in ai_logs:
            self.table.add_row([
                log.created_at,
                log.username or "-",
                log.operation_type,
                log.description,
            ])
        self.empty_label.setText("" if ai_logs else "No AI model call history yet.")
