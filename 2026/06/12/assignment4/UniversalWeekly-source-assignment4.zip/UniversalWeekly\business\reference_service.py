"""Reference formatting service."""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class ReferenceItem:
    """Structured bibliographic data for one reference."""

    authors: str = ""
    title: str = ""
    venue: str = ""
    year: str = ""
    volume: str = ""
    issue: str = ""
    pages: str = ""
    doi: str = ""


class ReferenceFormatter:
    """Convert bibliographic fields into common academic citation formats."""

    @staticmethod
    def format_all(item: ReferenceItem) -> dict[str, str]:
        return {
            "APA 7th": ReferenceFormatter.to_apa(item),
            "IEEE": ReferenceFormatter.to_ieee(item),
            "GB/T 7714": ReferenceFormatter.to_gbt7714(item),
            "BibTeX": ReferenceFormatter.to_bibtex(item),
        }

    @staticmethod
    def to_apa(item: ReferenceItem) -> str:
        authors = ReferenceFormatter._apa_authors(item.authors)
        title = ReferenceFormatter._sentence_case(item.title)
        venue = ReferenceFormatter._clean(item.venue)
        year = item.year.strip() or "n.d."
        volume_issue = ReferenceFormatter._volume_issue(item.volume, item.issue)
        pages = ReferenceFormatter._clean(item.pages)
        doi = ReferenceFormatter._doi_url(item.doi)

        parts = [f"{authors} ({year}).", f"{title}.", f"{venue}{volume_issue}"]
        if pages:
            parts[-1] += f", {pages}"
        parts[-1] += "."
        if doi:
            parts.append(doi)
        return " ".join(p for p in parts if p.strip())

    @staticmethod
    def to_ieee(item: ReferenceItem) -> str:
        authors = ReferenceFormatter._ieee_authors(item.authors)
        venue = ReferenceFormatter._clean(item.venue)
        title = ReferenceFormatter._clean(item.title)
        details = []
        if item.volume.strip():
            details.append(f"vol. {item.volume.strip()}")
        if item.issue.strip():
            details.append(f"no. {item.issue.strip()}")
        if item.pages.strip():
            details.append(f"pp. {item.pages.strip()}")
        if item.year.strip():
            details.append(item.year.strip())
        detail_text = ", ".join(details)
        doi = f", doi: {ReferenceFormatter._clean(item.doi)}" if item.doi.strip() else ""
        suffix = f", {detail_text}" if detail_text else ""
        return f'[1] {authors}, "{title}," {venue}{suffix}{doi}.'

    @staticmethod
    def to_gbt7714(item: ReferenceItem) -> str:
        authors = ReferenceFormatter._gbt_authors(item.authors)
        title = ReferenceFormatter._clean(item.title)
        venue = ReferenceFormatter._clean(item.venue)
        year = ReferenceFormatter._clean(item.year)
        volume = ReferenceFormatter._clean(item.volume)
        issue = ReferenceFormatter._clean(item.issue)
        pages = ReferenceFormatter._clean(item.pages)
        doi = ReferenceFormatter._clean(item.doi)

        source = f"{venue}, {year}" if year else venue
        if volume:
            source += f", {volume}"
        if issue:
            source += f"({issue})"
        if pages:
            source += f": {pages}"
        result = f"{authors}. {title}[J]. {source}."
        if doi:
            result += f" DOI: {doi}."
        return result

    @staticmethod
    def to_bibtex(item: ReferenceItem) -> str:
        key = ReferenceFormatter._bibtex_key(item)
        lines = [
            f"@article{{{key},",
            f"  author = {{{ReferenceFormatter._clean(item.authors)}}},",
            f"  title = {{{ReferenceFormatter._clean(item.title)}}},",
            f"  journal = {{{ReferenceFormatter._clean(item.venue)}}},",
        ]
        optional = {
            "year": item.year,
            "volume": item.volume,
            "number": item.issue,
            "pages": item.pages,
            "doi": item.doi,
        }
        for field, value in optional.items():
            value = ReferenceFormatter._clean(value)
            if value:
                lines.append(f"  {field} = {{{value}}},")
        if lines[-1].endswith(","):
            lines[-1] = lines[-1][:-1]
        lines.append("}")
        return "\n".join(lines)

    @staticmethod
    def _split_authors(authors: str) -> list[str]:
        text = authors.strip()
        if not text:
            return ["Unknown Author"]
        if ";" in text:
            parts = text.split(";")
        elif " and " in text.lower():
            parts = re.split(r"\s+and\s+", text, flags=re.I)
        else:
            parts = text.split(",")
        return [p.strip() for p in parts if p.strip()]

    @staticmethod
    def _apa_authors(authors: str) -> str:
        parts = [ReferenceFormatter._apa_single_author(a) for a in ReferenceFormatter._split_authors(authors)]
        if len(parts) == 1:
            return parts[0]
        if len(parts) == 2:
            return f"{parts[0]} & {parts[1]}"
        return ", ".join(parts[:-1]) + f", & {parts[-1]}"

    @staticmethod
    def _apa_single_author(author: str) -> str:
        words = author.replace(".", "").split()
        if len(words) <= 1:
            return author.strip()
        family = words[-1]
        initials = " ".join(f"{w[0].upper()}." for w in words[:-1] if w)
        return f"{family}, {initials}"

    @staticmethod
    def _ieee_authors(authors: str) -> str:
        parts = [ReferenceFormatter._initials_first(a) for a in ReferenceFormatter._split_authors(authors)]
        if len(parts) == 1:
            return parts[0]
        if len(parts) == 2:
            return f"{parts[0]} and {parts[1]}"
        return ", ".join(parts[:-1]) + f", and {parts[-1]}"

    @staticmethod
    def _gbt_authors(authors: str) -> str:
        return ", ".join(ReferenceFormatter._split_authors(authors))

    @staticmethod
    def _initials_first(author: str) -> str:
        words = author.replace(".", "").split()
        if len(words) <= 1:
            return author.strip()
        initials = " ".join(f"{w[0].upper()}." for w in words[:-1] if w)
        return f"{initials} {words[-1]}"

    @staticmethod
    def _sentence_case(title: str) -> str:
        clean = ReferenceFormatter._clean(title)
        if not clean:
            return ""
        return clean[0].upper() + clean[1:]

    @staticmethod
    def _volume_issue(volume: str, issue: str) -> str:
        volume = ReferenceFormatter._clean(volume)
        issue = ReferenceFormatter._clean(issue)
        if volume and issue:
            return f", {volume}({issue})"
        if volume:
            return f", {volume}"
        return ""

    @staticmethod
    def _doi_url(doi: str) -> str:
        clean = ReferenceFormatter._clean(doi)
        if not clean:
            return ""
        if clean.startswith("http"):
            return clean
        return f"https://doi.org/{clean}"

    @staticmethod
    def _bibtex_key(item: ReferenceItem) -> str:
        authors = ReferenceFormatter._split_authors(item.authors)
        family = re.sub(r"[^A-Za-z0-9]", "", authors[0].split()[-1].lower()) or "ref"
        year = re.sub(r"[^0-9]", "", item.year) or "nodate"
        title_word = next((w for w in re.findall(r"[A-Za-z0-9]+", item.title.lower()) if len(w) > 3), "paper")
        return f"{family}{year}{title_word}"

    @staticmethod
    def _clean(value: str) -> str:
        return " ".join((value or "").strip().split())
