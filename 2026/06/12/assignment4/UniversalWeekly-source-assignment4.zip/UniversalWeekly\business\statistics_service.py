"""Statistics and data analysis service."""

from typing import List, Dict, Optional
from database.db_manager import DatabaseManager


class StatisticsService:
    """Compute statistics for teachers and students."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    def get_class_summary(self, class_name: str, week_number: int) -> Dict:
        return self.db.get_class_weekly_stats(class_name, week_number)

    def get_student_progress(self, user_id: int) -> List[Dict]:
        return self.db.get_student_progress_history(user_id)

    def get_problem_analysis(self, class_name: str, week_number: int) -> List[Dict]:
        return self.db.get_high_frequency_problems(class_name, week_number)

    def get_category_distribution(self, report_id: int) -> Dict[str, int]:
        """Count tasks by category for a report."""
        tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
        distribution = {}
        for task in tasks:
            distribution[task.category] = distribution.get(task.category, 0) + 1
        return distribution

    def get_status_distribution(self, report_id: int) -> Dict[str, int]:
        """Count tasks by status for a report."""
        tasks = self.db.get_tasks_by_report(report_id, is_plan=False)
        distribution = {}
        for task in tasks:
            distribution[task.status] = distribution.get(task.status, 0) + 1
        return distribution

    def get_student_avg_progress_by_week(self, user_id: int) -> List[Dict]:
        """Get average progress per week for a student."""
        return self.db.get_student_progress_history(user_id)

    def get_class_attendance(self, class_name: str, week_number: int) -> Dict:
        """Students who have submitted vs not submitted."""
        submissions = self.db.get_submission_status(class_name, week_number)
        submitted = sum(1 for s in submissions if s["report_status"] is not None)
        total = len(submissions)
        return {
            "total": total,
            "submitted": submitted,
            "unsubmitted": total - submitted,
            "submission_rate": round(submitted / total * 100, 1) if total > 0 else 0,
            "details": submissions,
        }

    def get_flagged_students(self, class_name: str, threshold: int = 50) -> List[Dict]:
        """Flag students with consistently low progress (below threshold)."""
        students = self.db.get_students_by_class(class_name)
        flagged = []
        for student in students:
            history = self.db.get_student_progress_history(student.id)
            if len(history) >= 2:
                recent = history[-2:]
                if all(h["avg_progress"] < threshold for h in recent):
                    flagged.append({
                        "user_id": student.id,
                        "name": student.display_name,
                        "avg_progress": recent[-1]["avg_progress"],
                        "consecutive_low": 2,
                    })
        return flagged

    def get_teacher_all_classes_summary(self, teacher_class: str, current_week: int) -> Dict:
        """Overall summary for a teacher's class."""
        summary = self.get_class_summary(teacher_class, current_week)
        problems = self.get_problem_analysis(teacher_class, current_week)
        flagged = self.get_flagged_students(teacher_class)

        # Group problem types
        problem_summary = []
        for p in problems:
            samples = p.get("samples", "").split("|||")[:3]
            problem_summary.append({
                "type": p["problem_type"],
                "count": p["cnt"],
                "samples": samples,
            })

        return {
            "class_summary": summary,
            "problem_summary": problem_summary,
            "flagged_students": flagged,
        }
