"""Local LLM integration for weekly report generation."""

from __future__ import annotations

import json
import os
import re
from typing import Any

import requests


class LocalLLMService:
    """Generate weekly report sections from keywords using a local model."""

    DEFAULT_OLLAMA_URL = "http://localhost:11434"
    DEFAULT_OPENAI_COMPAT_URL = "http://localhost:1234/v1"
    DEFAULT_MODEL = "qwen2.5:7b"
    MODEL_OPTIONS = [
        "qwen2.5:7b",
        "qwen2.5:3b",
        "llama3.2:3b",
        "gemma3:4b",
        "deepseek-r1:1.5b",
    ]

    @classmethod
    def model_options(cls) -> list[str]:
        return list(cls.MODEL_OPTIONS)

    @classmethod
    def generate_weekly_report(
        cls,
        keywords: str,
        context: dict[str, Any],
        provider: str = "Ollama",
        endpoint: str = "",
        model: str = "",
        output_language: str = "English",
    ) -> dict[str, Any]:
        keywords = keywords.strip()
        if not keywords:
            raise ValueError("Please enter keywords or short notes first.")
        phrases = cls._split_keywords(keywords)

        if provider == "Offline Template":
            return cls._offline_generate(keywords, context, output_language)

        prompt = cls._build_prompt(keywords, context, output_language)
        try:
            if provider == "Ollama":
                text = cls._call_ollama(endpoint or cls.DEFAULT_OLLAMA_URL, model or cls.DEFAULT_MODEL, prompt)
            elif provider == "OpenAI-compatible":
                text = cls._call_openai_compatible(
                    endpoint or cls.DEFAULT_OPENAI_COMPAT_URL,
                    model or os.getenv("LOCAL_LLM_MODEL", "local-model"),
                    prompt,
                )
            else:
                return cls._offline_generate(keywords, context, output_language)
            parsed = cls._parse_model_output(text)
            parsed = cls._ground_result_to_keywords(parsed, phrases, context, output_language)
            parsed["engine"] = f"{provider} / {model or cls.DEFAULT_MODEL} (keyword grounded)"
            return parsed
        except Exception as exc:
            fallback = cls._offline_generate(keywords, context, output_language)
            fallback["engine"] = f"Offline Template fallback ({provider} unavailable: {exc})"
            return fallback

    @classmethod
    def generate_section(
        cls,
        section: str,
        keywords: str,
        context: dict[str, Any],
        provider: str = "Ollama",
        endpoint: str = "",
        model: str = "",
        output_language: str = "English",
    ) -> dict[str, str]:
        keywords = keywords.strip()
        if not keywords:
            raise ValueError("Please enter keywords or short notes first.")

        if provider == "Offline Template":
            return cls._offline_generate_section(section, keywords, context, output_language)

        prompt = cls._build_section_prompt(section, keywords, context, output_language)
        try:
            if provider == "Ollama":
                text = cls._call_ollama(endpoint or cls.DEFAULT_OLLAMA_URL, model or cls.DEFAULT_MODEL, prompt)
            elif provider == "OpenAI-compatible":
                text = cls._call_openai_compatible(
                    endpoint or cls.DEFAULT_OPENAI_COMPAT_URL,
                    model or os.getenv("LOCAL_LLM_MODEL", "local-model"),
                    prompt,
                )
            else:
                return cls._offline_generate_section(section, keywords, context, output_language)
            parsed = cls._parse_section_output(text)
            parsed["engine"] = f"{provider} / {model or cls.DEFAULT_MODEL}"
            return parsed
        except Exception as exc:
            fallback = cls._offline_generate_section(section, keywords, context, output_language)
            fallback["engine"] = f"Offline Template fallback ({provider} unavailable: {exc})"
            return fallback

    @classmethod
    def test_connection(cls, provider: str, endpoint: str = "", model: str = "") -> tuple[bool, str]:
        try:
            if provider == "Ollama":
                base = (endpoint or cls.DEFAULT_OLLAMA_URL).rstrip("/")
                response = requests.get(f"{base}/api/tags", timeout=5)
                response.raise_for_status()
                models = [m.get("name", "") for m in response.json().get("models", [])]
                if models:
                    return True, "Ollama is available. Models: " + ", ".join(models[:8])
                return True, "Ollama is available, but no model list was returned."
            if provider == "OpenAI-compatible":
                base = (endpoint or cls.DEFAULT_OPENAI_COMPAT_URL).rstrip("/")
                payload = {
                    "model": model or os.getenv("LOCAL_LLM_MODEL", "local-model"),
                    "messages": [{"role": "user", "content": "Reply with OK."}],
                    "temperature": 0,
                    "max_tokens": 12,
                }
                response = requests.post(f"{base}/chat/completions", json=payload, timeout=12)
                response.raise_for_status()
                return True, "OpenAI-compatible local endpoint is available."
            return True, "Offline Template is always available."
        except Exception as exc:
            return False, f"Connection failed: {exc}"

    @classmethod
    def _call_ollama(cls, endpoint: str, model: str, prompt: str) -> str:
        base = endpoint.rstrip("/")
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.15,
                "num_ctx": 4096,
            },
        }
        response = requests.post(f"{base}/api/generate", json=payload, timeout=120)
        response.raise_for_status()
        return response.json().get("response", "")

    @classmethod
    def _call_openai_compatible(cls, endpoint: str, model: str, prompt: str) -> str:
        base = endpoint.rstrip("/")
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "You are a concise weekly report writing assistant."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.15,
            "max_tokens": 1200,
        }
        response = requests.post(f"{base}/chat/completions", json=payload, timeout=120)
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]

    @classmethod
    def _build_prompt(cls, keywords: str, context: dict[str, Any], output_language: str) -> str:
        phrases = cls._split_keywords(keywords)
        ai_inputs = context.get("ai_inputs") or {}
        structured_notes = ""
        if any(str(value).strip() for value in ai_inputs.values()):
            structured_notes = f"""
Structured weekly-report input:
- Completed work notes: {ai_inputs.get("completed", "")}
- Problems / reflection notes: {ai_inputs.get("problems", "")}
- Next-week plan notes: {ai_inputs.get("next_plan", "")}

SECTION MAPPING RULES:
1. Completed work notes must be used for highlights and completed task rows.
2. Problems / reflection notes must be used for shortcomings, improvement measures, and problem records.
3. Next-week plan notes must be used for next_plan_summary and plan rows.
4. Do not move a problem into completed tasks, and do not write next-week plans as finished work.
5. If a structured input field has multiple items, generate one table row for each meaningful item.
""".strip()
        return f"""
Generate a weekly report from the user's exact keywords and current report context.

Output language: {output_language}
Return JSON only. Do not include Markdown fences.

WRITING REQUIREMENTS:
1. Write complete weekly-report content, not a keyword list and not a fixed template.
2. Expand keywords into specific actions, progress, results, problems, and next steps.
3. Each summary field should contain coherent sentences that can be submitted directly.
4. You may infer reasonable learning/work process details only when they clearly follow the user's keywords.
5. Do not simply paste keywords into generic sentences.
6. The generated table rows should be practical records for the Tasks, Problems & Reflection, and Next Week Plan tabs.

STRICT KEYWORD CONTROL:
1. You must only write content related to these exact keywords/notes.
2. You must not invent unrelated topics, courses, projects, or achievements.
3. Use every keyword at least once across highlights, shortcomings, improvements, tasks, plans, or next_plan_summary.
4. Task names, problem records, and plan names should be directly derived from the user's notes.
5. If a keyword is vague, turn it into a concrete weekly-report sentence, but keep the original meaning.

Exact keyword list:
{json.dumps(phrases, ensure_ascii=False, indent=2)}

{structured_notes}

Required JSON schema:
{{
  "highlights": "string",
  "shortcomings": "string",
  "improvements": "string",
  "next_plan_summary": "string",
  "tasks": [
    {{"category": "study|homework|project|club|personal|other", "name": "string", "description": "string", "status": "completed|in_progress|not_started|delayed", "progress": 0}}
  ],
  "problems": [
    {{"description": "string", "problem_type": "time_management|difficulty|resource|other", "attempted_solution": "string", "unresolved_reason": "string"}}
  ],
  "plans": [
    {{"category": "study|homework|project|club|personal|other", "name": "string", "description": "string"}}
  ]
}}

Raw keywords / notes:
{keywords}

Current report context:
{json.dumps(context, ensure_ascii=False, indent=2)}
""".strip()

    @classmethod
    def _build_section_prompt(cls, section: str, keywords: str, context: dict[str, Any], output_language: str) -> str:
        section_names = {
            "highlights": "weekly highlights / completed work",
            "shortcomings": "shortcomings and problems",
            "improvements": "improvement measures",
            "next_plan_summary": "next-week plan summary",
        }
        return f"""
Generate only one weekly-report field.

Section: {section_names.get(section, section)}
Output language: {output_language}
Return JSON only: {{"text": "string"}}

Writing requirements:
1. Use the user's keywords as source facts and expand them into complete, submit-ready weekly-report prose.
2. Do not merely insert the keywords into a fixed sentence.
3. Keep the content consistent with the selected section.
4. Do not invent unrelated courses, projects, achievements, or personal information.
5. Write 2 to 4 concise sentences.

User keywords / notes:
{keywords}

Current report context:
{json.dumps(context, ensure_ascii=False, indent=2)}
""".strip()

    @classmethod
    def _parse_model_output(cls, text: str) -> dict[str, Any]:
        text = (text or "").strip()
        match = re.search(r"\{.*\}", text, flags=re.S)
        if not match:
            raise ValueError("Local model did not return JSON.")
        data = json.loads(match.group(0))
        return cls._normalize_result(data)

    @classmethod
    def _parse_section_output(cls, text: str) -> dict[str, str]:
        text = (text or "").strip()
        match = re.search(r"\{.*\}", text, flags=re.S)
        if match:
            data = json.loads(match.group(0))
            content = str(data.get("text", "")).strip()
            if content:
                return {"text": content, "engine": "Local LLM"}
        if text:
            return {"text": text.strip(), "engine": "Local LLM"}
        raise ValueError("Local model did not return content.")

    @classmethod
    def _normalize_result(cls, data: dict[str, Any]) -> dict[str, Any]:
        tasks = data.get("tasks") or []
        problems = data.get("problems") or []
        plans = data.get("plans") or []
        return {
            "highlights": str(data.get("highlights", "")).strip(),
            "shortcomings": str(data.get("shortcomings", "")).strip(),
            "improvements": str(data.get("improvements", "")).strip(),
            "next_plan_summary": str(data.get("next_plan_summary", "")).strip(),
            "tasks": [cls._normalize_task(item) for item in tasks[:8] if isinstance(item, dict)],
            "problems": [cls._normalize_problem(item) for item in problems[:8] if isinstance(item, dict)],
            "plans": [cls._normalize_plan(item) for item in plans[:8] if isinstance(item, dict)],
            "engine": data.get("engine", "Local LLM"),
        }

    @classmethod
    def _normalize_task(cls, item: dict[str, Any]) -> dict[str, Any]:
        category = item.get("category", "other")
        if category not in {"study", "homework", "project", "club", "personal", "other"}:
            category = "other"
        status = item.get("status", "completed")
        if status not in {"completed", "in_progress", "not_started", "delayed"}:
            status = "completed"
        try:
            progress = int(item.get("progress", 100 if status == "completed" else 50))
        except Exception:
            progress = 100 if status == "completed" else 50
        return {
            "category": category,
            "name": str(item.get("name", "Generated task")).strip()[:80],
            "description": str(item.get("description", "")).strip(),
            "status": status,
            "progress": max(0, min(progress, 100)),
        }

    @classmethod
    def _normalize_problem(cls, item: dict[str, Any]) -> dict[str, Any]:
        problem_type = item.get("problem_type", "other")
        if problem_type not in {"time_management", "difficulty", "resource", "other"}:
            problem_type = "other"
        return {
            "description": str(item.get("description", "")).strip()[:200],
            "problem_type": problem_type,
            "attempted_solution": str(item.get("attempted_solution", "")).strip(),
            "unresolved_reason": str(item.get("unresolved_reason", "")).strip(),
        }

    @classmethod
    def _normalize_plan(cls, item: dict[str, Any]) -> dict[str, Any]:
        category = item.get("category", "study")
        if category not in {"study", "homework", "project", "club", "personal", "other"}:
            category = "study"
        return {
            "category": category,
            "name": str(item.get("name", "Generated plan")).strip()[:80],
            "description": str(item.get("description", "")).strip(),
        }

    @classmethod
    def _ground_result_to_keywords(
        cls,
        result: dict[str, Any],
        phrases: list[str],
        context: dict[str, Any],
        output_language: str,
    ) -> dict[str, Any]:
        """Keep the model output only when it clearly follows user keywords."""
        ai_inputs = context.get("ai_inputs") or {}
        has_structured_inputs = any(str(value).strip() for value in ai_inputs.values())
        completed_phrases = cls._split_keywords(str(ai_inputs.get("completed", "")))
        problem_phrases = cls._split_keywords(str(ai_inputs.get("problems", "")))
        next_plan_phrases = cls._split_keywords(str(ai_inputs.get("next_plan", "")))
        coverage_phrases = (
            completed_phrases + problem_phrases + next_plan_phrases
            if has_structured_inputs
            else phrases
        )

        if not coverage_phrases:
            return result

        joined = " ".join(
            str(result.get(key, ""))
            for key in ["highlights", "shortcomings", "improvements", "next_plan_summary"]
        )
        joined += " " + " ".join(str(task.get("name", "")) + " " + str(task.get("description", "")) for task in result.get("tasks", []))
        joined += " " + " ".join(
            str(problem.get("description", "")) + " " +
            str(problem.get("attempted_solution", "")) + " " +
            str(problem.get("unresolved_reason", ""))
            for problem in result.get("problems", [])
        )
        joined += " " + " ".join(str(plan.get("name", "")) + " " + str(plan.get("description", "")) for plan in result.get("plans", []))
        covered = [phrase for phrase in coverage_phrases if cls._mentions_phrase(joined, phrase)]
        min_required = max(1, min(len(coverage_phrases), round(len(coverage_phrases) * 0.6)))

        if len(covered) < min_required:
            grounded = cls._offline_generate(", ".join(coverage_phrases), context, output_language)
            grounded["engine"] = "Strict Keyword Template fallback"
            return grounded

        missing = [phrase for phrase in coverage_phrases if phrase not in covered]
        if missing:
            missing_completed = [phrase for phrase in missing if phrase in completed_phrases]
            missing_problems = [phrase for phrase in missing if phrase in problem_phrases]
            missing_plans = [phrase for phrase in missing if phrase in next_plan_phrases]
            if output_language == "Chinese":
                if missing_completed:
                    result["highlights"] = cls._append_sentence(
                        result.get("highlights", ""),
                        "本周完成内容还包括：" + "、".join(missing_completed) + "。"
                    )
                if missing_problems:
                    result["shortcomings"] = cls._append_sentence(
                        result.get("shortcomings", ""),
                        "需要重点反思的问题包括：" + "、".join(missing_problems) + "。"
                    )
                    result["improvements"] = cls._append_sentence(
                        result.get("improvements", ""),
                        "后续将针对以下问题制定改进措施：" + "、".join(missing_problems) + "。"
                    )
                if missing_plans:
                    result["next_plan_summary"] = cls._append_sentence(
                        result.get("next_plan_summary", ""),
                        "下周将继续跟进：" + "、".join(missing_plans[:3]) + "。"
                    )
                if not has_structured_inputs:
                    result["highlights"] = cls._append_sentence(
                        result.get("highlights", ""),
                        "本周内容已围绕以下关键词展开：" + "、".join(missing) + "。"
                    )
                    result["next_plan_summary"] = cls._append_sentence(
                        result.get("next_plan_summary", ""),
                        "下周将继续跟进：" + "、".join(missing[:3]) + "。"
                    )
            else:
                if missing_completed:
                    result["highlights"] = cls._append_sentence(
                        result.get("highlights", ""),
                        "This week's completed work also included: " + ", ".join(missing_completed) + "."
                    )
                if missing_problems:
                    result["shortcomings"] = cls._append_sentence(
                        result.get("shortcomings", ""),
                        "The key problems to reflect on include: " + ", ".join(missing_problems) + "."
                    )
                    result["improvements"] = cls._append_sentence(
                        result.get("improvements", ""),
                        "I will improve the following issues: " + ", ".join(missing_problems) + "."
                    )
                if missing_plans:
                    result["next_plan_summary"] = cls._append_sentence(
                        result.get("next_plan_summary", ""),
                        "Next week, I will continue: " + ", ".join(missing_plans[:3]) + "."
                    )
                if not has_structured_inputs:
                    result["highlights"] = cls._append_sentence(
                        result.get("highlights", ""),
                        "This week's work also covered: " + ", ".join(missing) + "."
                    )
                    result["next_plan_summary"] = cls._append_sentence(
                        result.get("next_plan_summary", ""),
                        "Next week, I will continue: " + ", ".join(missing[:3]) + "."
                    )

        if has_structured_inputs:
            result["tasks"] = cls._ground_tasks(result.get("tasks", []), completed_phrases, output_language) if completed_phrases else []
            result["problems"] = cls._ground_problems(result.get("problems", []), problem_phrases, output_language) if problem_phrases else []
            result["plans"] = cls._ground_plans(result.get("plans", []), next_plan_phrases, output_language) if next_plan_phrases else []
        else:
            result["tasks"] = cls._ground_tasks(result.get("tasks", []), phrases, output_language)
            result["problems"] = cls._ground_problems(result.get("problems", []), phrases, output_language)
            result["plans"] = cls._ground_plans(result.get("plans", []), phrases, output_language)
        return result

    @classmethod
    def _ground_tasks(cls, tasks: list[dict[str, Any]], phrases: list[str], output_language: str) -> list[dict[str, Any]]:
        grounded = []
        used = set()
        for task in tasks:
            name = str(task.get("name", ""))
            phrase = next((p for p in phrases if cls._mentions_phrase(name, p)), "")
            if phrase:
                used.add(phrase)
                grounded.append(task)
        for phrase in phrases[:4]:
            if phrase in used:
                continue
            desc = f"围绕“{phrase}”完成本周学习、整理或实验推进。" if output_language == "Chinese" else f"Completed weekly work related to {phrase}."
            grounded.append({
                "category": cls._guess_category(phrase),
                "name": phrase[:80],
                "description": desc,
                "status": "completed",
                "progress": 100,
            })
        return grounded[:8]

    @classmethod
    def _ground_problems(cls, problems: list[dict[str, Any]], phrases: list[str], output_language: str) -> list[dict[str, Any]]:
        problem_phrases = phrases[:4]
        grounded = []
        used = set()
        for problem in problems:
            description = str(problem.get("description", ""))
            phrase = next((p for p in problem_phrases if cls._mentions_phrase(description, p)), "")
            if phrase:
                used.add(phrase)
                grounded.append(problem)
        for phrase in problem_phrases:
            if phrase in used:
                continue
            if output_language == "Chinese":
                attempted = f"已对“{phrase}”进行初步梳理，并尝试通过拆分任务和补充资料来推进。"
                reason = "仍需要进一步积累过程证据并形成更稳定的复盘方法。"
            else:
                attempted = f"Made an initial review of {phrase} and tried to move it forward by breaking the task down and adding supporting materials."
                reason = "More process evidence and a clearer review method are still needed."
            grounded.append({
                "description": phrase[:200],
                "problem_type": cls._guess_problem_type(phrase),
                "attempted_solution": attempted,
                "unresolved_reason": reason,
            })
        return grounded[:8]

    @classmethod
    def _ground_plans(cls, plans: list[dict[str, Any]], phrases: list[str], output_language: str) -> list[dict[str, Any]]:
        plan_phrases = phrases[4:7] or phrases[:3]
        grounded = []
        used = set()
        for plan in plans:
            name = str(plan.get("name", ""))
            phrase = next((p for p in plan_phrases if cls._mentions_phrase(name, p)), "")
            if phrase:
                used.add(phrase)
                grounded.append(plan)
        for phrase in plan_phrases:
            if phrase in used:
                continue
            desc = f"继续推进“{phrase}”，形成可检查的阶段成果。" if output_language == "Chinese" else f"Continue {phrase} and produce checkable results."
            grounded.append({
                "category": cls._guess_category(phrase),
                "name": phrase[:80],
                "description": desc,
            })
        return grounded[:8]

    @staticmethod
    def _append_sentence(text: str, sentence: str) -> str:
        text = (text or "").strip()
        if not text:
            return sentence
        if sentence in text:
            return text
        return text + ("\n" if "\n" in text else " ") + sentence

    @staticmethod
    def _mentions_phrase(text: str, phrase: str) -> bool:
        text_norm = re.sub(r"\s+", "", text.lower())
        phrase_norm = re.sub(r"\s+", "", phrase.lower().strip())
        if not phrase_norm:
            return False
        if phrase_norm in text_norm:
            return True
        tokens = [token for token in re.split(r"[\s,，;；、/|_-]+", phrase.lower()) if len(token) >= 2]
        if not tokens:
            return False
        hits = sum(1 for token in tokens if token in text.lower())
        return hits >= max(1, round(len(tokens) * 0.6))

    @staticmethod
    def _guess_category(phrase: str) -> str:
        low = phrase.lower()
        if any(k in low for k in ["作业", "homework", "assignment", "课程", "course"]):
            return "homework"
        if any(k in low for k in ["实验", "experiment", "python", "代码", "coding"]):
            return "project"
        if any(k in low for k in ["论文", "文献", "paper", "literature", "阅读", "read"]):
            return "study"
        if any(k in low for k in ["会议", "meeting", "组会"]):
            return "club"
        return "study"

    @staticmethod
    def _guess_problem_type(phrase: str) -> str:
        low = phrase.lower()
        if any(k in low for k in ["时间", "拖延", "进度", "deadline", "time", "schedule"]):
            return "time_management"
        if any(k in low for k in ["资料", "数据", "资源", "文献不足", "resource", "data"]):
            return "resource"
        if any(k in low for k in ["困难", "不会", "不足", "薄弱", "weak", "difficult", "problem"]):
            return "difficulty"
        return "other"

    @classmethod
    def _expand_completed_phrase(cls, phrase: str, output_language: str) -> str:
        low = phrase.lower()
        if output_language == "Chinese":
            if any(k in low for k in ["论文", "文献", "paper", "read", "literature", "阅读"]):
                return f"对“{phrase}”相关资料进行了阅读和归纳，整理了核心观点、方法思路以及后续可引用的内容。"
            if any(k in low for k in ["实验", "python", "代码", "数据", "experiment", "coding"]):
                return f"围绕“{phrase}”完成了数据整理、代码调试和结果检查，为后续分析提供了基础。"
            if any(k in low for k in ["模型", "训练", "model", "training"]):
                return f"围绕“{phrase}”梳理了模型配置、训练流程和关键参数，并对阶段性结果进行了检查。"
            if any(k in low for k in ["结果", "分析", "图表", "result", "analysis", "chart"]):
                return f"对“{phrase}”进行了整理和分析，初步归纳了结果变化、存在问题和后续优化方向。"
            if any(k in low for k in ["作业", "homework", "assignment"]):
                return f"完成了“{phrase}”相关学习任务，并对关键知识点进行了复盘。"
            return f"推进了“{phrase}”相关工作，明确了当前进展、阶段成果和后续需要完善的环节。"
        if any(k in low for k in ["paper", "literature", "read"]):
            return f"Reviewed materials related to {phrase}, summarized the main ideas, methods, and useful points for later writing."
        if any(k in low for k in ["experiment", "python", "code", "data"]):
            return f"Worked on {phrase}, including data preparation, code adjustment, and result checking."
        if any(k in low for k in ["model", "training"]):
            return f"Reviewed the setup, training process, and key parameters for {phrase}, then checked the interim results."
        if any(k in low for k in ["result", "analysis", "chart"]):
            return f"Organized and analyzed {phrase}, summarizing result changes, remaining issues, and possible optimization directions."
        if any(k in low for k in ["homework", "assignment"]):
            return f"Completed the work related to {phrase} and reviewed the key knowledge points."
        return f"Moved forward with {phrase}, clarifying the current progress, interim output, and follow-up work."

    @classmethod
    def _expand_plan_phrase(cls, phrase: str, output_language: str) -> str:
        if output_language == "Chinese":
            return f"继续推进“{phrase}”，明确阶段目标，形成可检查的过程记录和阶段成果。"
        return f"Continue {phrase}, define clear milestones, and produce checkable progress records."

    @classmethod
    def _offline_generate_section(cls, section: str, keywords: str, context: dict[str, Any], output_language: str) -> dict[str, str]:
        phrases = cls._split_keywords(keywords)
        if not phrases:
            phrases = [keywords]
        if output_language == "Chinese":
            if section == "highlights":
                text = "".join(cls._expand_completed_phrase(phrase, output_language) for phrase in phrases[:4])
                text += "整体来看，本周工作已从简单推进转向有记录、有整理、有结果的阶段。"
            elif section == "shortcomings":
                text = "本周暴露出的主要问题包括：" + "、".join(phrases[:4]) + "。这些问题说明当前在过程记录、结果支撑和阶段复盘方面仍不够充分，部分工作还停留在完成任务层面，缺少进一步提炼和验证。"
            elif section == "improvements":
                text = "后续将针对" + "、".join(phrases[:4]) + "逐项制定改进措施：先把任务拆分为可检查的小目标，再补充必要资料和过程证据，并在每次完成后及时记录问题、原因和调整方法。"
            else:
                text = "".join(cls._expand_plan_phrase(phrase, output_language) for phrase in phrases[:4])
                text += "同时将结合本周问题进行复盘，确保下周计划更具体、更可执行。"
        else:
            if section == "highlights":
                text = " ".join(cls._expand_completed_phrase(phrase, output_language) for phrase in phrases[:4])
                text += " Overall, this week's work produced clearer records, more concrete outputs, and a better foundation for the next stage."
            elif section == "shortcomings":
                text = f"The main shortcomings this week were related to {', '.join(phrases[:4])}. These issues show that the current work still needs stronger evidence, clearer process records, and deeper reflection beyond simply finishing tasks."
            elif section == "improvements":
                text = f"Next, I will address {', '.join(phrases[:4])} by breaking the work into smaller milestones, adding supporting materials, recording problems in time, and reviewing each completed item more carefully."
            else:
                text = " ".join(cls._expand_plan_phrase(phrase, output_language) for phrase in phrases[:4])
                text += " I will also use this week's reflection to make the next plan more specific and executable."
        return {"text": text, "engine": "Offline Template"}

    @classmethod
    def _offline_generate(cls, keywords: str, context: dict[str, Any], output_language: str) -> dict[str, Any]:
        phrases = cls._split_keywords(keywords)
        ai_inputs = context.get("ai_inputs") or {}
        has_structured_inputs = any(str(value).strip() for value in ai_inputs.values())
        completed_phrases = cls._split_keywords(str(ai_inputs.get("completed", "")))
        problem_phrases = cls._split_keywords(str(ai_inputs.get("problems", "")))
        next_plan_phrases = cls._split_keywords(str(ai_inputs.get("next_plan", "")))

        if has_structured_inputs:
            task_names = completed_phrases
            plan_names = next_plan_phrases
            problem_names = problem_phrases
        else:
            task_names = phrases[:4] or ["weekly study and research tasks"]
            plan_names = phrases[4:7] or phrases[:3] or ["continue unfinished work", "prepare next week's study plan"]
            problem_names = []

        if output_language == "Chinese":
            if task_names:
                highlights = "".join(cls._expand_completed_phrase(name, output_language) for name in task_names[:4])
                highlights += "总体来看，本周工作形成了较明确的阶段进展，也为后续继续深化提供了基础。"
            else:
                highlights = "本周对已有工作进行了梳理和复盘，重点明确了当前进展、存在问题以及后续推进方向。"
            if problem_names:
                shortcomings = "本周主要问题集中在“{}”等方面，反映出当前在资料整理、过程记录、结果支撑或时间安排上仍有不足。部分工作虽然已经推进，但总结深度和可验证成果还需要继续加强。".format("、".join(problem_names[:4]))
                improvements = "后续将针对“{}”逐项拆分改进措施：明确每项任务的完成标准，补充过程证据和资料来源，并在完成后及时复盘原因、结果和下一步调整方向。".format("、".join(problem_names[:4]))
            else:
                shortcomings = "当前仍存在时间安排不够细化、部分任务总结不够深入、后续计划颗粒度不足等问题，需要在下一阶段进一步改进。"
                improvements = "后续将按优先级拆分任务，明确每项工作的完成标准，及时记录过程问题，并在每周末进行复盘。"
            if plan_names:
                next_plan = "".join(cls._expand_plan_phrase(name, output_language) for name in plan_names[:4])
                next_plan += "同时结合本周问题补充资料整理、结果归纳和阶段总结，使下周工作更加具体可检查。"
            else:
                next_plan = "下周将结合本周问题继续完善学习与工作安排，形成更加明确的阶段目标和可检查成果。"
            tasks = [
                {"category": cls._guess_category(name), "name": name[:60], "description": cls._expand_completed_phrase(name, output_language), "status": "completed", "progress": 100}
                for name in task_names
            ]
            problems = [
                {
                    "description": name[:200],
                    "problem_type": cls._guess_problem_type(name),
                    "attempted_solution": f"已围绕“{name}”进行初步梳理，并尝试通过补充资料、拆分任务和记录过程来改进。",
                    "unresolved_reason": "仍需要进一步积累过程证据，形成更系统的总结和复盘方法。",
                }
                for name in problem_names
            ]
            plans = [
                {"category": cls._guess_category(name), "name": name[:60], "description": cls._expand_plan_phrase(name, output_language)}
                for name in plan_names
            ]
        else:
            if task_names:
                highlights = " ".join(cls._expand_completed_phrase(name, output_language) for name in task_names[:4])
                highlights += " Overall, this week's work produced clearer progress records and a stronger foundation for the next stage."
            else:
                highlights = "This week, I reviewed the current progress, clarified existing problems, and prepared the direction for the next stage."
            if problem_names:
                shortcomings = f"The main problems were related to {', '.join(problem_names[:4])}. These issues show that the current work still needs stronger evidence, clearer process records, and deeper reflection."
                improvements = f"Next, I will address {', '.join(problem_names[:4])} by defining clearer completion standards, adding supporting materials, recording process problems, and reviewing the results after each task."
            else:
                shortcomings = "Some tasks still need deeper reflection, clearer evidence, and more detailed time planning."
                improvements = "Next, I will break tasks into smaller milestones, record problems in time, and review progress at the end of each week."
            if plan_names:
                next_plan = " ".join(cls._expand_plan_phrase(name, output_language) for name in plan_names[:4])
                next_plan += " I will also use this week's reflection to make the next plan more specific and checkable."
            else:
                next_plan = "Next week, I will improve the work arrangement based on this week's reflection and define more checkable milestones."
            tasks = [
                {"category": cls._guess_category(name), "name": name[:60], "description": cls._expand_completed_phrase(name, output_language), "status": "completed", "progress": 100}
                for name in task_names
            ]
            problems = [
                {
                    "description": name[:200],
                    "problem_type": cls._guess_problem_type(name),
                    "attempted_solution": f"Made an initial review of {name} and tried to improve it by adding materials, breaking down the task, and recording the process.",
                    "unresolved_reason": "More process evidence and a more systematic review method are still needed.",
                }
                for name in problem_names
            ]
            plans = [
                {"category": cls._guess_category(name), "name": name[:60], "description": cls._expand_plan_phrase(name, output_language)}
                for name in plan_names
            ]

        return {
            "highlights": highlights,
            "shortcomings": shortcomings,
            "improvements": improvements,
            "next_plan_summary": next_plan,
            "tasks": tasks,
            "problems": problems,
            "plans": plans,
            "engine": "Offline Template",
        }

    @staticmethod
    def _split_keywords(keywords: str) -> list[str]:
        parts = re.split(r"[,，;；\n]+", keywords)
        cleaned = [part.strip(" .。") for part in parts if part.strip(" .。")]
        if len(cleaned) == 1:
            cleaned = [p.strip() for p in re.split(r"\s{2,}|、", cleaned[0]) if p.strip()]
        return cleaned
