"""AI paper reading card generation service."""

from __future__ import annotations

import re

from business.local_llm_service import LocalLLMService


PAPER_CARD_ENGINE_OPTIONS = [
    "Local LLM (Ollama)",
    "Local LLM (OpenAI-compatible)",
    "Offline Template",
]


class PaperCardService:
    """Generate structured English paper reading cards from a title and abstract."""

    @classmethod
    def generate_card(
        cls,
        title: str,
        abstract: str,
        engine_label: str = "Local LLM (Ollama)",
        endpoint: str = "",
        model: str = "",
    ) -> tuple[bool, str, str]:
        title = title.strip()
        abstract = abstract.strip()
        if not title and not abstract:
            return False, "Please enter a paper title or abstract first.", "none"

        if engine_label == "Offline Template":
            return True, cls._offline_card(title, abstract), "Offline Template"

        provider = "Ollama" if engine_label == "Local LLM (Ollama)" else "OpenAI-compatible"
        prompt = cls._build_prompt(title, abstract)
        try:
            if provider == "Ollama":
                text = LocalLLMService._call_ollama(
                    endpoint or LocalLLMService.DEFAULT_OLLAMA_URL,
                    model or LocalLLMService.DEFAULT_MODEL,
                    prompt,
                )
                engine = f"Ollama / {model or LocalLLMService.DEFAULT_MODEL}"
            else:
                text = LocalLLMService._call_openai_compatible(
                    endpoint or LocalLLMService.DEFAULT_OPENAI_COMPAT_URL,
                    model or "local-model",
                    prompt,
                )
                engine = f"OpenAI-compatible / {model or 'local-model'}"
            return True, cls._normalize_card(text, title, abstract), engine
        except Exception as exc:
            fallback = cls._offline_card(title, abstract)
            fallback += f"\n\nNote: Local LLM generation failed, so the offline template was used.\nReason: {exc}"
            return True, fallback, "Offline Template fallback"

    @staticmethod
    def _build_prompt(title: str, abstract: str) -> str:
        return f"""
You are a rigorous academic paper reading assistant. Generate an English paper reading card based on the provided title and abstract.

Requirements:
1. Only use information from the title and abstract. Do not invent unsupported details.
2. If a field is not clearly stated in the abstract, write "Not explicitly stated in the abstract; full-text reading is required."
3. Output must be in English.
4. Use exactly the seven fields below. Do not add extra headings, numbering, or Markdown tables.
5. Be specific. Do not merely repeat the title; extract the research meaning, method clues, and citation value.

Fixed output format:
Research Problem:
Research Method:
Experimental Object:
Main Conclusions:
Innovation:
Limitations:
Citation Value:

Paper title:
{title}

Paper abstract:
{abstract}
""".strip()

    @classmethod
    def _normalize_card(cls, text: str, title: str, abstract: str) -> str:
        text = (text or "").strip()
        text = re.sub(r"^```[a-zA-Z]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        text = re.sub(r"^#+\s*.*\n+", "", text)

        fields = [
            "Research Problem",
            "Research Method",
            "Experimental Object",
            "Main Conclusions",
            "Innovation",
            "Limitations",
            "Citation Value",
        ]
        if all(f"{field}：" in text or f"{field}:" in text for field in fields):
            lines = []
            lookahead = "|".join(re.escape(field) for field in fields)
            for field in fields:
                pattern = rf"{re.escape(field)}[：:]\s*(.*?)(?=\n\s*(?:{lookahead})[：:]|$)"
                match = re.search(pattern, text, flags=re.S)
                value = match.group(1).strip() if match else "Not explicitly stated in the abstract; full-text reading is required."
                lines.append(f"{field}: {value}")
            return "\n\n".join(lines)
        return cls._offline_card(title, abstract)

    @classmethod
    def _offline_card(cls, title: str, abstract: str) -> str:
        source = f"{title}\n{abstract}".strip()
        problem = cls._infer_problem(title, abstract)
        method = cls._infer_method(title, abstract)
        obj = cls._infer_object(source)
        conclusion = cls._infer_conclusion(abstract)
        innovation = cls._infer_innovation(title, abstract)
        limitation = cls._infer_limitation(abstract)
        citation_value = cls._infer_citation_value(title, abstract)
        return "\n\n".join([
            f"Research Problem: {problem}",
            f"Research Method: {method}",
            f"Experimental Object: {obj}",
            f"Main Conclusions: {conclusion}",
            f"Innovation: {innovation}",
            f"Limitations: {limitation}",
            f"Citation Value: {citation_value}",
        ])

    @staticmethod
    def _infer_problem(title: str, abstract: str) -> str:
        text = abstract.strip()
        match = re.search(r"(However|Nevertheless|Although|Existing|Current)[^.。！？]*[.。！？]", text, flags=re.I)
        if match:
            return match.group(0).strip()
        if title:
            return f"The paper addresses the research topic related to \"{title}\", focusing on method development, application, or performance improvement."
        return "Not explicitly stated in the abstract; full-text reading is required."

    @staticmethod
    def _infer_method(title: str, abstract: str) -> str:
        text = f"{title}. {abstract}"
        match = re.search(r"(proposes?|presents?|develops?|introduces?)\s+([^.;。！？]+)", text, flags=re.I)
        if match:
            return match.group(0).strip()
        match = re.search(r"(method|framework|model|algorithm|approach)[^.;。！？]*", text, flags=re.I)
        if match:
            return match.group(0).strip()
        return "Not explicitly stated in the abstract; full-text reading is required."

    @staticmethod
    def _infer_object(text: str) -> str:
        object_hints = [
            ("rolling bearing", "rolling bearings"),
            ("rolling bearings", "rolling bearings"),
            ("bearing", "bearings"),
            ("bearings", "bearings"),
            ("rotating machinery", "rotating machinery"),
            ("aircraft", "aircraft"),
            ("flight", "flight operation data"),
            ("dataset", "experimental dataset"),
        ]
        low = text.lower()
        for key, value in object_hints:
            if key in low:
                return value
        return "Not explicitly stated in the abstract; full-text reading is required."

    @staticmethod
    def _infer_conclusion(abstract: str) -> str:
        match = re.search(r"((Experimental results|Results|The results|Experiments)[^.。！？]*[.。！？])", abstract, flags=re.I)
        if match:
            return match.group(1).strip()
        return "Not explicitly stated in the abstract; full-text reading is required."

    @staticmethod
    def _infer_innovation(title: str, abstract: str) -> str:
        text = f"{title}. {abstract}".strip()
        if re.search(r"digital twin", text, flags=re.I):
            return "It integrates the digital twin concept with the target task to enhance modeling, diagnosis, prediction, or decision-making capability."
        if re.search(r"proposes?|novel|new|innovative", text, flags=re.I):
            return "It proposes a new method, model, or framework with potential methodological improvement value."
        return "Not explicitly stated in the abstract; full-text reading is required."

    @staticmethod
    def _infer_limitation(abstract: str) -> str:
        match = re.search(r"(However|Limitation|Although|still|remain)[^.。！？]*[.。！？]", abstract, flags=re.I)
        if match:
            return match.group(0).strip()
        return "Not explicitly stated in the abstract; full-text reading is required."

    @staticmethod
    def _infer_citation_value(title: str, abstract: str) -> str:
        source = f"{title} {abstract}".lower()
        values = []
        if "digital twin" in source:
            values.append("background or method review on digital twin research")
        if "fault diagnosis" in source:
            values.append("comparison of fault diagnosis methods")
        if "machine learning" in source or "deep learning" in source:
            values.append("machine learning or deep learning application discussion")
        if "result" in source or "accuracy" in source:
            values.append("evidence for experimental performance or accuracy improvement")
        return "; ".join(values) + "." if values else "It can be cited as related work for research background, method comparison, or motivation."
